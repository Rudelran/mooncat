# -*- coding: utf-8 -*-
"""맵 바탕(바닥·벽·풀·길·강·광장 돌바닥)을 '도트 타일'로 한 번 그려 두는 모듈.
절반 해상도에서 그린 뒤 2배 최근접 확대 → 종이 UI와 같은 도트 굵기.
처음 그 장면에 들어갈 때 한 번만 만들고 캐시해요."""
import math
import random
import pygame as pg
import assets as A

_cache = {}


def _up(s):
    return pg.transform.scale(s, (s.get_width() * 2, s.get_height() * 2))


def _speckle_tile(rng, size, base, dots, tufts=()):
    t = pg.Surface((size, size))
    t.fill(base)
    for col, n in dots:
        for _ in range(n):
            t.set_at((rng.randrange(size), rng.randrange(size)), col)
    for col, n in tufts:                     # 풀잎 'v' 모양
        for _ in range(n):
            x, y = rng.randrange(1, size - 2), rng.randrange(2, size - 1)
            t.set_at((x, y), col); t.set_at((x + 2, y), col); t.set_at((x + 1, y + 1), col)
    return t


def _tile_fill(surf, rect, tiles, rng):
    x0, y0, w, h = rect
    ts = tiles[0].get_width()
    clip = surf.get_clip()
    surf.set_clip(pg.Rect(rect))
    for y in range(y0, y0 + h, ts):
        for x in range(x0, x0 + w, ts):
            surf.blit(tiles[rng.randrange(len(tiles))], (x, y))
    surf.set_clip(clip)


def _flower(s, x, y, col):
    s.set_at((x, y - 1), col); s.set_at((x - 1, y), col); s.set_at((x + 1, y), col); s.set_at((x, y + 1), col)
    s.set_at((x, y), (255, 236, 150))


# ═══════════════ 바깥 ═══════════════
def outdoor(om):
    if "outdoor" in _cache:
        return _cache["outdoor"]
    rng = random.Random(11)
    W2, H2 = om.size[0] // 2, om.size[1] // 2
    s = pg.Surface((W2, H2))
    grass = [_speckle_tile(rng, 16, (104, 150, 84), [((96, 140, 78), 14), ((116, 162, 92), 10)], [((84, 128, 70), 2)]) for _ in range(4)]
    forest = [_speckle_tile(rng, 16, (72, 118, 72), [((64, 106, 66), 16), ((84, 130, 80), 8), ((120, 96, 60), 2)], [((56, 96, 60), 2)]) for _ in range(4)]
    fx = om.FOREST_X // 2
    _tile_fill(s, (0, 0, fx, H2), grass, rng)
    _tile_fill(s, (fx, 0, W2 - fx, H2), forest, rng)
    # 숲 가장자리 흐리게 섞기
    for y in range(0, H2, 2):
        for k in range(10):
            x = fx - 10 + rng.randrange(20)
            s.set_at((x, y), forest[0].get_at((0, 0)) if x < fx else grass[0].get_at((0, 0)))
    # v1.2: 풀밭 색 얼룩 (밝은/어두운 2~3톤) — 단조로운 반복 무늬 줄이기
    for _ in range(70):
        cx, cy, rad = rng.randrange(W2), rng.randrange(H2), rng.randrange(14, 40)
        inf = cx > fx
        col = rng.choice([(96, 140, 78), (114, 160, 90), (108, 152, 82)] if not inf else [(64, 106, 66), (80, 126, 76), (70, 114, 68)])
        for yy in range(cy - rad, cy + rad, 1):
            for xx in range(cx - rad, cx + rad, 1):
                if not (0 <= xx < W2 and 0 <= yy < H2) or (xx > fx) != inf:
                    continue
                d = ((xx - cx) ** 2 + (yy - cy) ** 2) / (rad * rad)
                if d < 1 and rng.random() < 0.55 * (1 - d) ** 0.7 and (xx + yy) % 2 == 0:
                    s.set_at((xx, yy), col)
    # 숲 낙엽
    for _ in range(900):
        x, y = rng.randrange(fx, W2), rng.randrange(H2)
        s.set_at((x, y), rng.choice([(176, 120, 60), (196, 150, 70), (140, 90, 50)]))
    # 들꽃
    for _ in range(130):                           # v0.8: 420 → 130, 흰 꽃 빼기
        x, y = rng.randrange(4, fx - 4), rng.randrange(4, H2 - 4)
        _flower(s, x, y, rng.choice([(250, 200, 220), (200, 180, 250), (255, 230, 120)]))
    # 길 (흙 + 자갈 + 들쭉날쭉한 가장자리)
    dirt, dirt_d, dirt_l, pebble = (206, 180, 132), (184, 156, 110), (222, 200, 156), (150, 130, 110)
    for r in om.PATHS:
        rr = pg.Rect(r.x // 2, r.y // 2, r.w // 2, r.h // 2)
        pg.draw.rect(s, dirt_d, rr.inflate(2, 2))
        pg.draw.rect(s, dirt, rr)
        for _ in range(rr.w * rr.h // 40):
            x, y = rng.randrange(rr.x, rr.right), rng.randrange(rr.y, rr.bottom)
            s.set_at((x, y), rng.choice([dirt_d, dirt_l, pebble]))
        # v1.2: 들쭉날쭉한 풀 가장자리 (직선으로 잘린 느낌 줄이기)
        gcol = lambda x: (72, 118, 72) if x > fx else (104, 150, 84)
        gdark = lambda x: (64, 106, 66) if x > fx else (88, 132, 72)
        for x in range(rr.x, rr.right):
            for top, sign in ((rr.y, 1), (rr.bottom - 1, -1)):
                depth = int(1.5 + 1.5 * math.sin(x * 0.45 + top) + rng.random() * 2)
                for d in range(depth):
                    s.set_at((x, top + sign * d), gcol(x))
                s.set_at((x, top + sign * depth), dirt_d)
                if rng.random() < 0.12:                      # 풀잎이 길 위로 삐죽
                    s.set_at((x, top + sign * (depth + 1)), gdark(x))
        for y in range(rr.y, rr.bottom):
            for left, sign in ((rr.x, 1), (rr.right - 1, -1)):
                if rr.h < 60:
                    break
                depth = int(1.5 + 1.5 * math.sin(y * 0.45 + left) + rng.random() * 2)
                for d in range(depth):
                    s.set_at((left + sign * d, y), gcol(left))
                s.set_at((left + sign * depth, y), dirt_d)
    # 강 (가운데 깊은 물 · 가장자리 모래)
    rv = pg.Rect(om.RIVER.x // 2, 0, om.RIVER.w // 2, H2)
    pg.draw.rect(s, (214, 196, 150), rv.inflate(8, 0))
    pg.draw.rect(s, (74, 140, 190), rv)
    pg.draw.rect(s, (60, 120, 176), rv.inflate(-24, 0))
    pg.draw.rect(s, (110, 176, 214), (rv.x, 0, 3, H2))
    pg.draw.rect(s, (110, 176, 214), (rv.right - 3, 0, 3, H2))
    for _ in range(500):
        x, y = rng.randrange(rv.x + 3, rv.right - 3), rng.randrange(H2)
        pg.draw.line(s, (96, 160, 206), (x, y), (x + 3, y))
    for y in range(H2):                            # v1.2: 들쭉날쭉한 모래톱
        for side, sign in ((rv.x - 4, -1), (rv.right + 4, 1)):
            w = int(2 + 2 * math.sin(y * 0.09 + side) + 1.5 * math.sin(y * 0.31) + rng.random())
            for d in range(max(0, w)):
                s.set_at((side + sign * d, y), (214, 196, 150) if d < w - 1 else (190, 172, 128))
    for _ in range(160):                           # 강가 조약돌
        side = rng.choice([rv.x - 4, rv.right + 1])
        s.set_at((side + rng.randrange(3), rng.randrange(H2)), (170, 160, 150))
    # 다리
    b = pg.Rect(om.BRIDGE.x // 2, om.BRIDGE.y // 2, om.BRIDGE.w // 2, om.BRIDGE.h // 2)
    pg.draw.rect(s, (92, 60, 40), b.inflate(0, 6))
    pg.draw.rect(s, (150, 104, 64), b)
    for x in range(b.x, b.right, 6):
        pg.draw.line(s, (112, 74, 46), (x, b.y), (x, b.bottom - 1))
        s.set_at((x + 3, b.y + 3), (176, 128, 84))
    pg.draw.rect(s, (84, 56, 38), (b.x, b.y - 3, b.w, 3))
    pg.draw.rect(s, (84, 56, 38), (b.x, b.bottom, b.w, 3))
    for x in range(b.x, b.right, 12):
        pg.draw.rect(s, (70, 46, 32), (x, b.y - 5, 2, 5))
        pg.draw.rect(s, (70, 46, 32), (x, b.bottom, 2, 5))
    # 텃밭 울타리 (아래 가운데 입구)
    fr = pg.Rect(om.FARM.x // 2, om.FARM.y // 2, om.FARM.w // 2, om.FARM.h // 2)
    post, rail = (120, 82, 52), (160, 116, 74)
    for (x1, y1, x2, y2) in [(fr.x, fr.y, fr.right, fr.y), (fr.x, fr.y, fr.x, fr.bottom), (fr.right, fr.y, fr.right, fr.bottom),
                             (fr.x, fr.bottom, fr.centerx - 18, fr.bottom), (fr.centerx + 18, fr.bottom, fr.right, fr.bottom)]:
        horiz = y1 == y2                           # v1.2: 나무 말뚝 울타리 (가로대 2줄 + 말뚝 머리)
        if horiz:
            pg.draw.line(s, (96, 64, 40), (x1, y1 - 3), (x2, y2 - 3), 1)
            pg.draw.line(s, rail, (x1, y1 - 4), (x2, y2 - 4), 1)
            pg.draw.line(s, (96, 64, 40), (x1, y1), (x2, y2), 1)
            pg.draw.line(s, rail, (x1, y1 - 1), (x2, y2 - 1), 1)
        else:
            pg.draw.line(s, (96, 64, 40), (x1 + 1, y1), (x2 + 1, y2), 1)
            pg.draw.line(s, rail, (x1, y1), (x2, y2), 1)
    def _post(x, y):
        pg.draw.rect(s, (86, 58, 38), (x - 2, y - 7, 4, 9))
        pg.draw.rect(s, post, (x - 1, y - 7, 2, 8))
        pg.draw.rect(s, (182, 136, 90), (x - 1, y - 8, 2, 1))
    for x in list(range(fr.x, fr.right + 1, 10)):
        for y in (fr.y, fr.bottom):
            if y == fr.bottom and abs(x - fr.centerx) < 18:
                continue
            _post(x, y)
    for y in range(fr.y, fr.bottom + 1, 10):
        for x in (fr.x, fr.right):
            _post(x, y)
    # v1.2: NPC 거처 앞 흙바닥 (건물이 풀밭에 떠 보이지 않게)
    for hx, hy, hh in getattr(om, "HOMES", {}).values():
        cx, cy, rw, rh = hx // 2 + 8, hy // 2 + 2, 62, 16
        for yy in range(cy - rh, cy + rh):
            for xx in range(cx - rw, cx + rw):
                d = ((xx - cx) / rw) ** 2 + ((yy - cy) / rh) ** 2
                if d < 1 and (d < 0.6 or rng.random() < (1 - d) * 2.2):
                    inf = xx > fx
                    s.set_at((xx, yy), rng.choice([(176, 150, 104), (190, 164, 118), (168, 140, 96)]) if not inf else rng.choice([(120, 100, 70), (132, 110, 78)]))
    # 저택 앞마당 (돌 판)
    yard = pg.Rect(om.YARD.x // 2, om.YARD.y // 2, om.YARD.w // 2, om.YARD.h // 2)
    for y in range(yard.y, yard.bottom, 6):
        for x in range(yard.x + (3 if (y // 6) % 2 else 0), yard.right, 8):
            c = rng.choice([(196, 188, 176), (184, 176, 166), (206, 198, 186)])
            pg.draw.rect(s, (150, 142, 134), (x, y, 8, 6))
            pg.draw.rect(s, c, (x, y, 7, 5))
    out = _up(s)
    _cache["outdoor"] = out
    return out


# ═══════════════ 가게 (저택 1층) ═══════════════
def _planks(s, rect, rng, tones, seam, knot, h=13):
    x0, y0, w, hh = rect
    for y in range(y0, y0 + hh, h):
        x = x0 - rng.randrange(40)
        while x < x0 + w:
            L = rng.randrange(36, 72)
            c = rng.choice(tones)
            pg.draw.rect(s, c, (max(x, x0), y, min(L, x0 + w - max(x, x0)), h))
            if x >= x0:
                pg.draw.line(s, seam, (x, y), (x, y + h - 1))
            for _ in range(3):   # 나뭇결
                gx = rng.randrange(max(x, x0), min(x + L, x0 + w)) if min(x + L, x0 + w) > max(x, x0) else x0
                gy = y + rng.randrange(2, h - 2)
                pg.draw.line(s, tuple(max(0, v - 12) for v in c), (gx, gy), (min(gx + 8, x0 + w - 1), gy))
            if rng.random() < 0.15 and x0 <= x + 10 < x0 + w:
                s.set_at((x + 10, y + h // 2), knot)
            x += L
        pg.draw.line(s, seam, (x0, y), (x0 + w - 1, y))


def shop(sm):
    if "shop" in _cache:
        return _cache["shop"]
    rng = random.Random(5)
    s = pg.Surface((640, 400))
    s.fill((58, 40, 36))
    wb = sm.WALL_BOTTOM // 2
    # 가게 바닥 (밝은 원목)
    _planks(s, (20, wb, 600, 392 - wb), rng, [(196, 146, 96), (188, 138, 90), (204, 154, 102)], (150, 104, 66), (130, 88, 56))
    # 작업실 (짙은 원목)
    _planks(s, (446, wb, 174, 124), rng, [(124, 86, 58), (116, 80, 54), (132, 92, 62)], (90, 60, 40), (80, 52, 36), h=11)
    # 리라의 방 (라벤더 카펫 + 무늬)
    room = pg.Rect(451, 241, 169, 150)
    pg.draw.rect(s, (150, 112, 132), room)
    for y in range(room.y, room.bottom, 8):
        for x in range(room.x + (4 if (y // 8) % 2 else 0), room.right, 8):
            s.set_at((x, y), (168, 130, 150)); s.set_at((x + 1, y + 1), (168, 130, 150))
    rug = pg.Rect(475, 270, 125, 100)
    pg.draw.rect(s, (96, 66, 120), rug.inflate(4, 4))
    pg.draw.rect(s, (128, 92, 150), rug)
    pg.draw.rect(s, (196, 170, 226), rug.inflate(-6, -6), 1)
    for y in range(rug.y + 10, rug.bottom - 8, 12):
        for x in range(rug.x + 10, rug.right - 8, 12):
            pg.draw.polygon(s, (178, 150, 200), [(x, y - 3), (x + 3, y), (x, y + 3), (x - 3, y)])
    # 가게 가운데 러그 (별 무늬)
    rug = pg.Rect(190, 215, 90, 125)
    pg.draw.rect(s, (80, 56, 112), rug.inflate(4, 4))
    pg.draw.rect(s, (112, 84, 150), rug)
    pg.draw.rect(s, (196, 170, 226), rug.inflate(-6, -6), 1)
    for i in range(0, rug.w, 4):                 # 술
        pg.draw.line(s, (220, 200, 236), (rug.x + i, rug.y - 4), (rug.x + i, rug.y - 2))
        pg.draw.line(s, (220, 200, 236), (rug.x + i, rug.bottom + 2), (rug.x + i, rug.bottom + 4))
    for y in range(rug.y + 12, rug.bottom - 10, 18):
        for x in range(rug.x + 14, rug.right - 10, 20):
            c = (240, 214, 130)
            s.set_at((x, y), c); s.set_at((x - 1, y), c); s.set_at((x + 1, y), c); s.set_at((x, y - 1), c); s.set_at((x, y + 1), c)
    # 뒷벽: 벽지 (세로 줄 + 달·별 무늬)
    pg.draw.rect(s, (212, 196, 226), (0, 0, 640, 75))
    for x in range(0, 640, 14):
        pg.draw.line(s, (202, 184, 218), (x, 0), (x, 75))
    for y in range(12, 70, 20):
        for x in range(7 + (7 if (y // 20) % 2 else 0), 640, 28):
            if (x // 28 + y // 20) % 2:
                pg.draw.circle(s, (232, 220, 244), (x, y), 2)
                s.set_at((x + 1, y - 1), (212, 196, 226))
            else:
                s.set_at((x, y), (236, 214, 150)); s.set_at((x - 1, y), (236, 214, 150)); s.set_at((x + 1, y), (236, 214, 150))
                s.set_at((x, y - 1), (236, 214, 150)); s.set_at((x, y + 1), (236, 214, 150))
    pg.draw.rect(s, (80, 52, 36), (0, 0, 640, 5))
    # 징두리 판자
    pg.draw.rect(s, (106, 70, 48), (0, 75, 640, 4))
    pg.draw.rect(s, (150, 102, 66), (0, 79, 640, 23))
    for x in range(0, 640, 32):
        pan = pg.Rect(x + 3, 82, 26, 17)
        pg.draw.rect(s, (130, 88, 58), pan)
        pg.draw.rect(s, (164, 114, 74), (pan.x + 1, pan.y + 1, pan.w - 2, pan.h - 2))
        pg.draw.line(s, (178, 128, 86), (pan.x + 1, pan.y + 1), (pan.right - 2, pan.y + 1))
    pg.draw.rect(s, (86, 56, 38), (0, 102, 640, 4))
    # 옆벽 · 앞벽 (세로 나뭇결)
    for rr in [(0, wb, 20, 400 - wb), (620, wb, 20, 400 - wb), (0, 391, 215, 9), (255, 391, 385, 9)]:
        pg.draw.rect(s, (96, 64, 46), rr)
        for _ in range(rr[2] * rr[3] // 10):
            s.set_at((rr[0] + rng.randrange(rr[2]), rr[1] + rng.randrange(rr[3])), (84, 56, 40))
    pg.draw.rect(s, (160, 110, 70), (215, 392, 40, 8))   # 문턱
    # 문 앞 발깔개
    pg.draw.rect(s, (150, 70, 80), (220, 372, 30, 14))
    pg.draw.rect(s, (200, 120, 120), (222, 374, 26, 10), 1)
    out = _up(s)
    _cache["shop"] = out
    return out


# ═══════════════ 장터 광장 (돌바닥) ═══════════════
def plaza():
    if "plaza" in _cache:
        return _cache["plaza"]
    rng = random.Random(3)
    s = pg.Surface((640, 400))
    s.fill((62, 56, 78))
    for y in range(30, 400, 9):
        x = -rng.randrange(8)
        while x < 640:
            w = rng.randrange(9, 16)
            c = rng.choice([(96, 88, 112), (104, 96, 120), (90, 82, 106), (110, 100, 124)])
            pg.draw.rect(s, c, (x + 1, y + 1, w - 1, 8))
            pg.draw.line(s, (124, 114, 138), (x + 1, y + 1), (x + w - 2, y + 1))
            x += w
    # 가운데 원형 무늬 (분수 주변)
    for r in (70, 64):
        pg.draw.circle(s, (130, 120, 146), (320, 125), r, 2)
    # 가장자리 화단
    for x in list(range(10, 250, 40)) + list(range(400, 640, 40)):
        pg.draw.rect(s, (110, 74, 50), (x, 380, 30, 12))
        pg.draw.rect(s, (80, 130, 76), (x + 2, 376, 26, 6))
        for k in range(4):
            _flower(s, x + 5 + k * 6, 377, rng.choice([(250, 200, 220), (255, 230, 120), (200, 180, 250)]))
    pg.draw.rect(s, (48, 42, 60), (0, 0, 640, 30))
    out = _up(s)
    _cache["plaza"] = out
    return out

# -*- coding: utf-8 -*-
"""달빛 고양이 상점 — 리라의 유산 (클로드 수정판 v0.4)
모든 수치·텍스트 데이터. 기획서 v1.3 + v0.3 플레이리뷰 수정안 기준."""

GOAL_REVENUE = 2_000_000
HOUR_SECONDS = 30          # 게임 속 1시간 = 실제 30초
DAY_START = 7.0            # 기상 시각
SHOP_OPEN, SHOP_CLOSE = 9.0, 18.0
BASE_ENERGY = 16

# 장 해금 누적 매출 (v0.8: 최종 목표 200만 원에 맞춰 다시 배치 · 하룻밤에 한 장씩)
CHAPTERS = [
    (1, "유산", 0),
    (2, "할머니의 텃밭", 50_000),
    (3, "강가의 작은 손님", 150_000),
    (4, "숲과 달의 돌", 300_000),
    (5, "은빛 탑의 제안", 550_000),
    (6, "달빛 장터", 1_000_000),
    (7, "이백만 원의 밤", 2_000_000),     # v0.8: 달빛 장터를 마쳐야 열림
]

CATS = {
    "potion": ("물약", (122, 190, 110)),
    "bath": ("입욕제", (238, 150, 190)),
    "goods": ("고양이 굿즈", (240, 190, 90)),
    "stone": ("마도석", (130, 170, 240)),
    "magic": ("마법 소품", (180, 140, 240)),
}
CAT_ORDER = ["potion", "bath", "goods", "stone", "magic"]

# 재료 18종: id -> (이름, 지역, 해금 장, 색)
MATS = {
    "herb":       ("달빛 허브", "farm", 1, (120, 170, 110)),
    "starflower": ("별꽃", "farm", 1, (240, 230, 160)),
    "sunflower":  ("햇살 해바라기", "farm", 1, (250, 200, 60)),
    "cotton":     ("폭신 목화", "farm", 1, (245, 245, 240)),
    "rose":       ("장미", "farm", 2, (220, 70, 100)),
    "moonherb":   ("월광초", "farm", 5, (190, 180, 250)),
    "waterweed":  ("물풀", "river", 1, (80, 170, 130)),
    "scale":      ("은빛 비늘", "river", 1, (190, 210, 230)),
    "jelly":      ("달빛 해파리", "river", 3, (140, 160, 250)),
    "clay":       ("강가 점토", "river", 3, (170, 120, 90)),
    "shell":      ("무지개 조개", "river", 4, (250, 190, 220)),
    "berry":      ("숲딸기", "forest", 1, (230, 60, 80)),
    "wool":       ("구름 털실", "forest", 1, (230, 230, 250)),
    "crystal":    ("마력 조각", "forest", 1, (170, 120, 240)),
    "wax":        ("벌꿀 밀랍", "forest", 4, (240, 180, 70)),
    "firefly":    ("반딧불 가루", "forest", 4, (250, 240, 150)),
    "bottle":     ("유리병", "shop", 1, (180, 220, 230)),
    "salt":       ("굵은 소금", "shop", 1, (235, 235, 235)),
}
MAT_ORDER = list(MATS.keys())
REGION_NAME = {"farm": "텃밭", "river": "강가", "forest": "숲", "shop": "잡화"}

# 한스네 수레: 가격, 하루 수량
HANS = {
    "bottle": (300, 10), "salt": (200, 10),
    "herb": (500, 10), "starflower": (500, 10), "sunflower": (550, 10),      # v0.8: 약초 값 인상
    "cotton": (650, 5), "rose": (800, 5), "moonherb": (3800, 2),
    "waterweed": (300, 10), "scale": (700, 5), "clay": (900, 5),
    "jelly": (1500, 5), "shell": (5000, 2),
    "berry": (600, 10), "wax": (700, 5), "wool": (1200, 5),
    "firefly": (1200, 5), "crystal": (2500, 2),
}

# 제품 30종. unlock: 장 번호(int) 또는 "quest:npc" / "luna60"
PRODUCTS = [
    # id, 이름, 분류, 가격, 레시피, 해금, 설명
    ("p_sun", "햇살 물약", "potion", 1500, {"sunflower": 2, "herb": 1, "bottle": 1}, 1, "아침에 마시면 하루 종일 기운이 나요"),
    ("p_moon", "달빛 물약", "potion", 3000, {"herb": 2, "jelly": 1, "bottle": 1}, 3, "베개 옆에 두면 포근하게 잠들어요"),
    ("p_star", "별빛 물약", "potion", 3500, {"starflower": 2, "firefly": 1, "bottle": 1}, 4, "한 모금에 눈앞이 반짝반짝"),
    ("p_berry", "두근두근 딸기 물약", "potion", 5000, {"berry": 2, "rose": 1, "bottle": 1}, 4, "고백 전에 마시는 용기 한 방울"),
    ("p_cloud", "구름 둥실 물약", "potion", 6500, {"wool": 1, "waterweed": 2, "firefly": 1, "bottle": 1}, 5, "몸이 깃털처럼 가벼워져요"),
    ("p_rainbow", "무지개 물약", "potion", 12000, {"shell": 1, "sunflower": 1, "starflower": 1, "moonherb": 1, "bottle": 1}, 6, "오늘 하루 운이 조금 좋아져요"),
    ("b_starflower", "별꽃 거품 입욕제", "bath", 2000, {"starflower": 2, "salt": 1}, 2, "작은 별 모양 거품이 퐁퐁"),
    ("b_herb", "초록 허브 입욕제", "bath", 2000, {"herb": 2, "salt": 1}, 1, "숲속 향기로 피로를 풀어 줘요"),
    ("b_milk", "딸기우유 입욕제", "bath", 3500, {"berry": 2, "cotton": 1, "salt": 1}, 2, "분홍빛 우유 목욕, 아이들 최애"),
    ("b_rose", "장미 입욕 볼", "bath", 4000, {"rose": 2, "wax": 1, "salt": 1}, 4, "꽃잎이 동동 떠오르는 목욕"),
    ("b_fish", "물고기 뽀글 입욕제", "bath", 4500, {"scale": 1, "waterweed": 1, "starflower": 1, "salt": 1}, "quest:momo", "물속에서 물고기 거품이 헤엄쳐요"),
    ("b_galaxy", "은하수 입욕제", "bath", 7000, {"moonherb": 1, "firefly": 2, "salt": 1}, 6, "물 위에 별자리가 떠올라요"),
    ("b_rosemoon", "장미 달빛 입욕 볼", "bath", 15000, {"rose": 2, "moonherb": 1, "wax": 1, "salt": 1}, "quest:rosemary", "할머니의 비밀 레시피 (한정)"),
    ("g_muffler", "고양이 발바닥 머플러", "goods", 4500, {"wool": 3, "cotton": 1}, 1, "끝자락에 분홍 젤리 자수"),
    ("g_pencil", "검은 고양이 필통", "goods", 5500, {"cotton": 2, "wax": 1}, 4, "지퍼 손잡이가 꼬리 모양"),
    ("g_keyring", "고양이 방울 키링", "goods", 5000, {"scale": 1, "crystal": 1}, 2, "흔들면 루나 목방울 소리"),
    ("g_cup", "달고양이 찻잔", "goods", 6000, {"clay": 2, "starflower": 1}, 3, "바닥에 초승달 고양이가 떠요"),
    ("g_cushion", "식빵 고양이 쿠션", "goods", 6500, {"cotton": 3, "wool": 1}, 5, "웅크린 고양이 모양, 말랑말랑"),
    ("g_luna", "루나 인형", "goods", 12000, {"wool": 2, "cotton": 2, "firefly": 1}, "luna60", "루나 본인 허락(?)을 받은 공식 인형"),
    ("s_sun", "햇빛 마도석", "stone", 8000, {"crystal": 2, "sunflower": 2}, 1, "손에 쥐면 따뜻해요"),
    ("s_water", "물빛 마도석", "stone", 9000, {"crystal": 2, "jelly": 1}, 3, "잔잔한 물결 소리가 나요"),
    ("s_star", "별빛 마도석", "stone", 12000, {"crystal": 2, "firefly": 1, "starflower": 1}, 5, "밤이 되면 작은 별처럼 빛나요"),
    ("s_wish", "소원을 품은 마도석", "stone", 15000, {"crystal": 3, "scale": 2}, 5, "소원을 속삭이면 반짝 대답해요"),
    ("s_moon", "월광 마도석", "stone", 22000, {"crystal": 3, "moonherb": 2}, 6, "보름달 빛을 가득 담은 최고급"),
    ("m_bookmark", "속삭이는 책갈피", "magic", 4000, {"herb": 1, "cotton": 1, "crystal": 1}, 1, "읽던 쪽을 조그맣게 알려 줘요"),
    ("m_candle", "떠다니는 양초", "magic", 6000, {"wax": 2, "firefly": 1}, 4, "공중에 둥실, 흘러내리지 않아요"),
    ("m_rosecandle", "장미 꿀 향초", "magic", 8000, {"wax": 2, "rose": 1, "herb": 1}, 5, "장미와 꿀 향이 은은하게"),
    ("m_charm", "은비늘 부적", "magic", 9000, {"scale": 2, "crystal": 1}, 3, "물가의 액운을 막아 주는 부적"),
    ("m_chime", "무지개 풍경", "magic", 11000, {"shell": 2, "clay": 1, "crystal": 1}, 6, "바람이 불면 일곱 빛깔 소리"),
    ("m_lamp", "수정구 램프", "magic", 20000, {"crystal": 3, "wax": 1, "firefly": 2}, 6, "방 안에 작은 밤하늘을 띄워요"),
]
PROD = {p[0]: dict(id=p[0], name=p[1], cat=p[2], price=p[3], recipe=p[4], unlock=p[5], desc=p[6]) for p in PRODUCTS}
PROD_ORDER = [p[0] for p in PRODUCTS]

# 진열대 종류: id -> (이름, 분류, 용량, 가격, 이미지)
SHELF_TYPES = {
    "potion":  ("물약 선반", "potion", 10, 0, "props/shelf_potion"),
    "bath":    ("입욕제 바구니 테이블", "bath", 10, 0, "props/shelf_bath"),
    "goods":   ("고양이 굿즈 테이블", "goods", 10, 30_000, "props/shelf_goods"),
    "stone":   ("마도석 쇼케이스", "stone", 8, 50_000, "props/shelf_stone"),
    "magic":   ("마법 소품장", "magic", 8, 80_000, "props/shelf_magic"),
    "potion2": ("큰 약장", "potion", 16, 120_000, "props/shelf_potion_big"),
}
# 매장 진열대 자리 6곳 (발밑 좌표)
SHELF_SLOTS = [(170, 380), (320, 380), (660, 380), (800, 380), (170, 600), (800, 600)]

# 장식 11종: id -> (이름, 종류 wall/floor, 명성, 효과설명, 가격(0=비매품), 이미지)
DECO = {
    "pebble":  ("반짝 조약돌 병", "floor", 5, "낚시 20% 확률로 획득량 2배", 0, "props/deco_pebble"),
    "sword":   ("모험가의 녹슨 검", "wall", 5, "사냥 20% 확률로 획득량 2배", 0, "props/deco_sword"),
    "teaset":  ("장미 정원 티세트", "floor", 5, "모든 판매 팁 +10%", 0, "props/deco_teaset"),
    "orrery":  ("천체 모형", "floor", 5, "제작 15% 확률로 1개 추가", 0, "props/deco_orrery"),
    "pawsign": ("발바닥 도장 간판", "wall", 5, "굿즈 판매가 +10%, 하루 손님 +1", 0, "props/deco_pawsign"),
    "wheat":   ("황금 밀 다발", "floor", 5, "텃밭 수확 20% 확률로 2배", 0, "props/deco_wheat"),
    "lunastatue": ("달빛 창가의 루나", "floor", 5, "하루 1번 행운 손님(구매액 2배)", 0, "props/deco_lunastatue"),
    "plaque":  ("마을 추천 상점 명패", "wall", 10, "명성 +10", 0, "props/deco_plaque"),
    "vase":    ("라벤더 꽃 화병", "floor", 10, "명성 +10", 15_000, "props/deco_vase"),
    "tapestry": ("달무늬 태피스트리", "wall", 15, "명성 +15", 40_000, "props/deco_tapestry"),
    "portrait": ("단골들의 단체 초상화", "wall", 10, "명성 +10", 0, "props/deco_portrait"),
}
WALL_SLOTS = [(210, 118), (395, 118), (560, 118), (735, 118), (822, 118), (1010, 118)]

# 노엘의 영구 기력 물약
TONICS = [
    ("tonic1", "새싹 기력 물약", 1, 2_000, 1),
    ("tonic2", "햇살 기력 물약", 2, 5_000, 2),
    ("tonic3", "달빛 기력 물약", 3, 15_000, 3),
    ("tonic4", "별빛 기력 물약", 3, 40_000, 5),
    ("tonic5", "무지개 기력 엘릭서", 3, 90_000, 6),
]

# 텃밭 작물: id -> (성장 일수, 수확량)
CROPS = {"herb": (1, 3), "starflower": (1, 3), "sunflower": (1, 3), "cotton": (2, 3), "rose": (2, 3), "moonherb": (3, 2)}

# 일반 손님 6유형: 이름, 선호(분류: 가중치), 예산, 최대 구매 수, 옷색, 모자
CUSTOMER_TYPES = [
    ("마을 아이", {"bath": 3, "goods": 3, "potion": 1, "magic": 1}, 6_000, 1, (110, 170, 230), "cap"),
    ("모험가", {"potion": 4, "stone": 3, "magic": 1}, 18_000, 2, (95, 140, 75), "band"),
    ("귀부인", {"bath": 3, "magic": 3, "goods": 2, "stone": 1}, 40_000, 3, (212, 110, 160), "bonnet"),
    ("마법학도", {"stone": 4, "magic": 3, "potion": 2}, 20_000, 2, (74, 79, 154), "hood"),
    ("고양이 애호가", {"goods": 6, "bath": 1, "magic": 1}, 15_000, 2, (242, 193, 78), "ears"),
    ("농부", {"potion": 4, "bath": 2}, 9_000, 1, (160, 112, 58), "straw"),
]

# 단골 6명
NPCS = {
    "hans":     dict(name="한스 밀러", met=2, likes=["potion", "bath"], budget=12_000, home=(700, 640), quest_ch=5),
    "momo":     dict(name="모모", met=3, likes=["bath", "goods"], budget=8_000, home=(1335, 1158), quest_ch=3),
    "mignon":   dict(name="미뇽", met=3, likes=["goods"], budget=22_000, home=(1030, 930), quest_ch=4),
    "kai":      dict(name="카이 브론", met=4, likes=["potion", "stone"], budget=20_000, home=(1880, 975), quest_ch=4),
    "theo":     dict(name="테오 윈슬로", met=4, likes=["stone", "magic", "potion"], budget=24_000, home=(1395, 925), quest_ch=4),
    "rosemary": dict(name="로즈메리", met=5, likes=["bath", "magic"], budget=40_000, home=(225, 668), quest_ch=5),
}
NPC_ORDER = ["hans", "momo", "mignon", "kai", "theo", "rosemary"]
SPECIAL = {"cecilia": "세실리아 베일", "noel": "노엘 브라이어", "bram": "브람 코퍼"}
SPEAKER = {"lira": "리라", "luna": "루나", "mom": "엄마", "dad": "아빠", "grandma": "할머니", "ursula": "우르술라", "narr": "",
           **{k: v["name"] for k, v in NPCS.items()}, **SPECIAL}

# 단골 부탁
QUESTS = {
    "momo": dict(title="거품 괴물을 무찔러라", text="동생이 목욕을 무서워해요. 물고기 뽀글 입욕제를 만들어 주세요! (레시피가 열려요)",
                 need={"b_fish": 1}, deco="pebble"),
    "kai": dict(title="숲의 주인", text="숲 북동쪽에 거대 슬라임이 나타났어! 같이 잡고, 원정용 햇살 물약 5개도 부탁해.",
                need={"p_sun": 5}, boss=True, deco="sword"),
    "rosemary": dict(title="그 장미 향", text="할머니 초상화 뒤에 레시피 노트의 찢어진 쪽이 있을 거란다. 그 향을 다시 만들어 주렴.",
                     need={"b_rosemoon": 1}, page=True, deco="teaset"),
    "theo": dict(title="교과서에 없는 마법", text="밤 8시 이후 남쪽 강가에서 '달빛 이슬'을 모아 줘. 소원을 품은 마도석 1개와 같이. (레시피가 열려요)",
                 need={"s_wish": 1}, dew=True, deco="orrery"),
    "mignon": dict(title="찻집 개업 대작전", text="개업 날 쓸 달고양이 찻잔 4개와 고양이 발바닥 머플러 2개를 부탁해요!",
                   need={"g_cup": 4, "g_muffler": 2}, deco="pawsign"),
    "hans": dict(title="가뭄의 여름", text="밭이 말라 간다. 월광초 2개와 달빛 허브 3개로 성장 물약을 같이 만들자.",
                 need_mats={"moonherb": 2, "herb": 3}, need={}, deco="wheat"),
}

# 장 목표: (설명, 조건키, 목표값)
GOALS = {
    1: [("햇살 물약 만들기", "craft:p_sun", 1), ("제품 5개 팔기", "sold", 5), ("가게 밖 지역 한 곳 가 보기", "visited", 1)],
    2: [("텃밭에서 수확하기", "harvests", 1), ("별꽃 거품 입욕제 만들기", "craft:b_starflower", 1), ("한스네 수레에서 사 보기", "hans_buys", 1)],
    3: [("낚시로 은빛 비늘 5개 모으기", "fish_scale", 5), ("달고양이 찻잔 만들기", "craft:g_cup", 1), ("고양이 굿즈 3개 팔기", "sold_cat:goods", 3)],
    4: [("슬라임 5마리 잡기", "kills", 5), ("마도석 만들기", "craft_cat:stone", 1), ("단골 부탁 1개 완료", "quests_done", 1)],
    5: [("의뢰 2건 납품", "orders_done", 2), ("로즈메리의 부탁 완료", "quest:rosemary", 1), ("물약 말고 다른 제품 20개 팔기", "sold_nonpotion", 20)],
    6: [("명성 30 달성", "rep", 30), ("단골 3명 호감도 50 이상", "friends50", 3), ("달빛 장터 참가", "market_done", 1)],
}
GOAL_REWARD = {1: ("고양이 굿즈 테이블 + 10,000원", 10_000), 2: ("텃밭 2칸 + 15,000원", 15_000),
               3: ("낚시 토템 + 20,000원", 20_000), 4: ("마도석 쇼케이스 + 20,000원", 20_000),
               5: ("30,000원", 30_000), 6: ("달무늬 태피스트리", 0)}

ROOMS = {
    "workshop": ("2층 공방", 150_000, {"crystal": 10}, "잠든 사이 지정 제품을 1번 자동 제작해요"),
    "greenhouse": ("유리 온실", 200_000, {"herb": 20}, "텃밭 2칸 추가, 월광초 성장 1일 단축"),
    "terrace": ("테라스 찻집", 250_000, {}, "매일 허브·별꽃 1개씩 써서 음료 매출 6,000원 (미뇽 호감도 100 필요)"),
    "library": ("할머니의 서재", 0, {}, "모든 방을 복원하면 열려요. 할머니의 마지막 편지"),
}


# ═══════════ 요리 (v0.7) ═══════════
# 요리 재료: 제작 재료와 겹치지 않음. 제작 재료를 얻을 때 '덤'으로 함께 얻는다.
FOODS = {
    "potato":   ("텃밭 감자", "텃밭에서 수확할 때 덤"),
    "carrot":   ("꼬마 당근", "텃밭에서 수확할 때 덤"),
    "wheat":    ("황금 밀", "텃밭에서 수확할 때 덤"),
    "fish":     ("강 송어", "낚시에 성공할 때 덤"),
    "mushroom": ("숲 버섯", "숲딸기·반딧불·슬라임, 버섯돌이"),
    "milk":     ("신선 우유", "한스네 수레에서 살 때 덤 · 아침 선물"),
}
FOOD_ORDER = list(FOODS.keys())
# 요리: 이름, 재료, 기력 회복, 설명
DISHES = [
    ("d_skewer",  "버섯 꼬치",   {"mushroom": 2},                                  3, "숲 냄새가 솔솔. 한 입에 쏙"),
    ("d_fish",    "송어 구이",   {"fish": 2},                                      4, "껍질은 바삭, 속은 촉촉"),
    ("d_soup",    "감자 수프",   {"potato": 2, "carrot": 1},                       4, "할머니 레시피 노트 첫 장의 수프"),
    ("d_pancake", "달빛 팬케이크", {"wheat": 2, "milk": 1},                        5, "루나가 제일 좋아하는 아침"),
    ("d_cake",    "당근 케이크", {"carrot": 2, "wheat": 1, "milk": 1},             7, "크림 위에 별꽃 장식 하나"),
    ("d_stew",    "숲속 스튜",   {"potato": 1, "carrot": 1, "mushroom": 1, "fish": 1}, 10, "먹으면 기운이 가득!"),
]
DISH = {d[0]: dict(name=d[1], need=d[2], energy=d[3], desc=d[4]) for d in DISHES}
DISH_ORDER = [d[0] for d in DISHES]
EAT_PER_DAY = 3


# ═══════════ v0.8 ═══════════
# 선물로 좋아하는 요리
DISH_LIKES = {
    "hans": ["d_soup", "d_stew"], "momo": ["d_pancake", "d_cake"], "mignon": ["d_cake", "d_pancake"],
    "kai": ["d_skewer", "d_stew"], "theo": ["d_fish", "d_soup"], "rosemary": ["d_cake", "d_soup"],
    "cecilia": ["d_fish", "d_cake"], "noel": ["d_stew", "d_skewer"], "bram": ["d_stew", "d_fish"],
}
# 대화 호감도: 기본 +5, 선택지 등급 보너스 (등급 1·2·3 → +5 · +7 · +10)
TALK_BASE = 5
AFF_TALK = {1: 5, 2: 7, 3: 10}
# 선물 호감도
GIFT_AFF = {"prod_like": 8, "prod": 3, "dish_like": 12, "dish": 6}
# 호감도 40 이상 단골이 대화 뒤 가끔 건네는 재료 (획득처 추가)
NPC_GIVES = {
    "hans": ["herb", "starflower", "sunflower", "cotton"], "momo": ["waterweed", "scale", "shell"],
    "mignon": ["cotton", "rose", "starflower"], "kai": ["wool", "crystal", "berry"],
    "theo": ["crystal", "firefly", "jelly"], "rosemary": ["rose", "moonherb", "herb"],
    "cecilia": ["bottle", "salt", "shell"], "noel": ["moonherb", "firefly"], "bram": ["clay", "crystal", "scale"],
}

# 채집 자리 (매일 아침 몇 곳이 새로 돋아나요. 기력 0)
GATHER_SPOTS = {
    "herb": [(180, 800), (260, 1020), (520, 1180), (820, 1060), (1000, 1050), (1180, 560), (900, 200), (560, 170),
             (1320, 380), (1250, 1250), (150, 1350), (1400, 1000), (1180, 980), (700, 1300)],
    "fherb": [(1820, 250), (2000, 500), (2250, 850), (1850, 1300), (1920, 1380), (2280, 100), (2120, 820), (2240, 500),
              (2200, 1140), (1760, 1090), (1960, 890)],
    "reed": [(1476, 560), (1476, 960), (1684, 300), (1684, 1250), (1476, 1350), (1684, 560)],
    "hive": [(2330, 1080), (1780, 600)],
    "ore": [(2120, 540), (2160, 1060), (1960, 1300)],
}
GATHER_PER_DAY = {"herb": 5, "fherb": 4, "reed": 2, "hive": 1, "ore": 1}
GATHER_CH = {"herb": 1, "fherb": 1, "reed": 1, "hive": 4, "ore": 1}
GATHER_LABEL = {"herb": "들풀 캐기", "fherb": "숲 약초 캐기", "reed": "강가 모래 뒤지기", "hive": "야생 벌집 · 밀랍 떼기", "ore": "마력 바위 · 조각 줍기"}
# (재료, 가중치, 해금 장)
GATHER_TABLE = {
    "herb": [("herb", 4, 1), ("starflower", 3, 1), ("sunflower", 3, 1), ("cotton", 2, 1), ("rose", 1, 2)],
    "fherb": [("herb", 3, 1), ("starflower", 2, 1), ("rose", 2, 2), ("cotton", 1, 1), ("moonherb", 1, 5)],
    "reed": [("waterweed", 4, 1), ("clay", 3, 3), ("shell", 1, 4)],
    "hive": [("wax", 1, 4)],
    "ore": [("crystal", 1, 1)],
}

# 루나 레벨 → 마법 단계 (루나 호감도 10마다 1레벨, 최대 10)
MAGIC_TIERS = [  # (필요 루나 레벨, 이름, 몬스터를 쓰러뜨리는 데 필요한 타수, 색)
    (1, "반짝 별탄", 10, (200, 170, 255)),
    (3, "푸른 별탄", 7, (140, 200, 255)),
    (5, "쌍둥이 금별탄", 5, (255, 214, 110)),
    (10, "보름달 일격", 1, (255, 250, 220)),
]
MONSTER_HP = 70          # 일반 몬스터 체력 (70 = 10·7·5·1타로 나누어떨어짐)
BOSS_HP = 210            # 거대 슬라임 (1레벨 30타 · 10레벨 3타)

# 버들골 소포 (누적 매출 50만 원부터 우편함)
NEIGHBOR_AT = 500_000
PACK_SHAPES = {          # 분류별 상자 모양 (칸 좌표)
    "potion": [(0, 0), (0, 1)],                       # 세로 2칸 병
    "bath":   [(0, 0), (1, 0), (0, 1), (1, 1)],       # 2x2 상자
    "goods":  [(0, 0), (0, 1), (1, 1)],               # ㄴ자
    "stone":  [(0, 0)],                               # 1칸
    "magic":  [(0, 0), (1, 0), (2, 0), (1, 1)],       # ㅗ자
}
PACK_REWARD = 1.35       # 단가의 135%
LETTER_EVERY = 3         # 부모님 편지 간격 (일)

# 가방에 보이는 얻는 곳 (v0.8)
MAT_SOURCES = {
    "herb": "텃밭 · 들풀 · 숲 약초 · 한스", "starflower": "텃밭 · 들풀 · 숲 약초 · 한스", "sunflower": "텃밭 · 들풀 · 한스",
    "cotton": "텃밭 · 들풀 · 숲 약초 · 한스", "rose": "텃밭 · 들풀 · 숲 약초 · 한스", "moonherb": "텃밭 · 숲 약초 · 로즈메리",
    "waterweed": "낚시 · 강가 모래 · 모모", "scale": "낚시 · 모모 · 한스", "jelly": "낚시 · 테오 · 한스",
    "clay": "낚시 · 강가 모래 · 한스", "shell": "낚시 · 강가 모래 · 한스", "berry": "숲딸기 덤불 · 카이 · 한스",
    "wool": "털뭉치 슬라임 · 카이 · 한스", "crystal": "슬라임 · 마력 바위 · 한스", "wax": "꿀벌 슬라임 · 야생 벌집 · 한스",
    "firefly": "반딧불 · 버섯돌이 · 벌집 · 한스", "bottle": "한스네 수레", "salt": "한스네 수레",
}


# ═══════════ v1.0 ═══════════
# 단골이 아닌 인물의 좋아하는 제품 분류 (선물용)
SPECIAL_LIKES = {"bram": ["stone", "magic"], "noel": ["potion"], "cecilia": ["potion", "magic"]}


def likes_of(k):
    return NPCS.get(k, {}).get("likes") or SPECIAL_LIKES.get(k, [])


# 진열장 레벨 (브람 공방): 레벨 → 추가 칸, 올리는 값
SHELF_LV_BONUS = {1: 0, 2: 4, 3: 8}
SHELF_UP_COST = {2: (30_000, {}), 3: (80_000, {"crystal": 2})}

# 브람 공방 상품: id -> (이름, 가격, 열리는 장, 설명, 선행 상품)
BRAM_SHOP = {
    "trap":      ("통발", 3_000, 2, "강가 통발 자리에 놓고 다음 날 걷어요. 한 번 쓰면 없어져요.", None),
    "trap_iron": ("튼튼한 통발", 150_000, 3, "걷어도 없어지지 않는 쇠 통발. 한 번 더 뒤져서 더 많이 나와요. (최대 3개)", None),
    "totem1":    ("낚시 토템", 50_000, 2, "강가 토템 자리에 세우면 그 낚시터의 노란 영역 +25%.", None),
    "totem2":    ("달빛 낚시 토템", 150_000, 4, "토템을 강화해요. 노란 영역 +45%, 입질이 빨라져요.", "totem1"),
    "pot":       ("구리 냄비", 60_000, 2, "요리할 때 금색 구간이 40% 넓어져요.", None),
    "board6":    ("세공대 넓히기 6×6", 80_000, 3, "마도석 세공대 판이 6×6이 돼요.", None),
    "board7":    ("세공대 넓히기 7×7", 200_000, 5, "마도석 세공대 판이 7×7이 돼요.", "board6"),
    "hammer":    ("세공 망치", 120_000, 4, "합칠 때 10% 확률로 한 단계를 더 올려요.", None),
}
BRAM_TABS = [("shelf", "진열장 강화", ["shelf"]), ("fish", "낚시 용품", ["trap", "trap_iron", "totem1", "totem2"]),
             ("tool", "공방 도구", ["pot", "board6", "board7", "hammer"])]
TRAP_IRON_MAX = 3
# 통발에서 나오는 것: (재료, 가중치, 해금 장)
TRAP_LOOT = [("scale", 4, 1), ("waterweed", 4, 1), ("clay", 3, 3), ("jelly", 2, 3), ("shell", 1, 4)]
TOTEM_BONUS = {0: 1.0, 1: 1.25, 2: 1.45}

# 마법 기력: 마력 3칸이 비면 기력 1로 다시 채워요. 거대 슬라임 앞에서는 1발마다 기력 1.
MANA_PER_ENERGY = 3

# 요리 품질 (냄비 젓기): 번호 → (이름, 기력 배수, 선물 호감 보너스, 표시)
COOK_Q = {1: ("보통", 1.0, 0, ""), 2: ("좋음", 1.3, 2, "◆"), 3: ("최고", 1.6, 5, "★")}

# 마도석 세공대 (머지): 단계 → (이름, 색, 꺼내면 (종류, id, 개수))
MERGE_TIERS = {
    1: ("마력 부스러기", (196, 176, 255), None),
    2: ("마력 조각", (170, 120, 240), ("mat", "crystal", 1)),
    3: ("햇빛 원석", (250, 200, 80), ("prod", "s_sun", 1)),
    4: ("물빛 원석", (110, 180, 250), ("prod", "s_water", 2)),
    5: ("별빛 원석", (250, 236, 150), ("prod", "s_star", 3)),
    6: ("소원 원석", (255, 150, 200), ("prod", "s_wish", 5)),
    7: ("보름달 원석", (236, 232, 255), ("prod", "s_moon", 6)),
}
MERGE_MAX = 7
# 마력 부스러기 얻는 곳
SHARD_DROP = {"normal": (1, 2), "crystal": (2, 3), "boss": (12, 12), "ore": (2, 2)}

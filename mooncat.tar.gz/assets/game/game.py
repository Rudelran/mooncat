# -*- coding: utf-8 -*-
"""게임 본체: 이동, 시간, 손님, 채집, 장터, 화면 그리기."""
import math, random, sys
import pygame as pg
import assets as A
import data as D
import story as S
import ui as U
from state import State
from world import ShopMap, OutdoorMap, PlazaMap, W, H
import menus as M
import touch as T

WEB = T.WEB

V = pg.Vector2
DIRS = {"down": (0, 1), "up": (0, -1), "left": (-1, 0), "right": (1, 0)}


class Game:
    def __init__(self, headless=False):
        pg.init()
        flags = 0 if WEB else pg.RESIZABLE        # 웹: 1280x800 그대로 두고 브라우저가 화면에 맞춰 늘리고 줄여요
        self.window = pg.display.set_mode((W, H), flags)
        pg.display.set_caption("달빛 고양이 상점 · 리라의 유산 (클로드 수정판 v1.6)")
        self.canvas = pg.Surface((W, H))
        self.clock = pg.time.Clock()
        self.ui = U.UI()
        self.maps = {"shop": ShopMap(), "outdoor": OutdoorMap(), "plaza": PlazaMap()}
        self.rng = random.Random()
        self.s = None
        self.mode = "title"
        self.menu = None
        self.queue = []
        self.messages = []
        self.floaters = []
        self.particles = []
        self.t = 0.0
        self.hint_t = 14.0
        self.show_help = False
        self.fullscreen = False
        self.running = True
        self.save_timer = 0
        self.mouse = (0, 0)
        self.dt_last = 0.016
        self.fade = 0.0          # 0 = 투명, 1 = 까맣게
        self.fade_dir = 0
        self.fade_fn = None
        self.tracker_open = True
        self.last_level = None
        self.last_gold = None
        self.villagers = []
        self.ambient = []
        self.bird_t = 6.0
        import audio
        self.audio = audio.Audio()
        self.ui.sound = self.sfx
        self.reset_runtime()
        sh = pg.Surface((30, 10), pg.SRCALPHA)       # 발밑 그림자 (주민 · 동물 · 몬스터 공용)
        pg.draw.ellipse(sh, (0, 0, 0, 70), sh.get_rect())
        A._cache["shadow"] = sh
        self.touch = T.Touch(self)
        self.title = M.Title(self)
        self.audio.music("title")

    # ═══════════════════ 시작 · 초기화 ═══════════════════
    def reset_runtime(self):
        self.villagers, self.ambient = [], []
        self.scene = "shop"
        self.p = V(470, 560)
        self.face = "down"
        self.moving = False
        self.cam = V(0, 0)
        self.luna = V(430, 600)
        self.customers = []
        self.slimes = []
        self.shots = []
        self.shot_cd = 0
        self.shop_open = False
        self.schedule = []
        self.sched_day = 0
        self.day_flags = {}
        self.placing = None
        self.market_slots = [None] * 6
        self.market_stock = {}
        self.market = None

    def new_game(self):
        self.s = State()
        self.last_level = self.last_gold = None
        self.reset_runtime()
        self.mode = "play"
        self.start_day(first=True)
        self.push_story(1)
        self.queue.append(lambda: self.toast("솥 앞에서 [사용]: 햇살 물약 만들기 · [영업]: 가게 열기" if self.touch.enabled else "E: 솥에서 햇살 물약 만들기 · O: 영업 시작 · J: 장 목표"))

    def continue_game(self):
        s = State.load()
        if not s:
            return self.new_game()
        self.s = s
        self.last_level = self.last_gold = None
        self.reset_runtime()
        self.mode = "play"
        self.start_day()
        self.toast(f"{s.day}일째 아침이에요. 이어서 해 볼까요?")

    def start_day(self, first=False):
        s = self.s
        self.day_flags = {}
        self.customers = []
        self.shop_open = False
        self.schedule = []
        self.sched_day = 0
        s.refresh_hans()
        s.refresh_orders(self.rng)
        s.refresh_parcels(self.rng)
        self.pick_gather()
        self.spawn_slimes()
        self.plan_regulars()

    def pick_gather(self):
        """오늘 돋아난 채집 자리 (들풀 · 숲 약초 · 강가 모래 · 벌집 · 마력 바위)."""
        s = self.s
        om = self.maps["outdoor"]
        r = random.Random(s.day * 7919 + 13)
        self.gather = []
        i = 0
        for kind, spots in D.GATHER_SPOTS.items():
            if s.chapter < D.GATHER_CH[kind]:
                continue
            ok = [p for p in spots if all(math.hypot(p[0] - tx, p[1] - ty) > 60 for tx, ty in om.trees)]
            for pos in r.sample(ok, min(len(ok), D.GATHER_PER_DAY[kind])):
                self.gather.append(dict(i=i, kind=kind, pos=pos))
                i += 1

    def do_gather(self, gs):
        s = self.s
        table = [(m, w) for m, w, ch in D.GATHER_TABLE[gs["kind"]] if s.chapter >= ch]
        names = [m for m, w in table for _ in range(w)]
        m = self.rng.choice(names)
        n = 1 if m in ("moonherb", "shell", "crystal") else self.rng.randint(1, 2)
        if gs["kind"] == "ore" and self.rng.random() < 0.25:
            n += 1
        self.day_flags[f"gather{gs['i']}"] = True
        s.add_mat(m, n)
        s.stat("gathered", n)
        self.sfx("pop")
        pos = V(gs["pos"])
        self.floater(pos + V(0, -60), f"{D.MATS[m][0]} +{n}", U.CREAM, icon=m)
        self.sparkle(pos + V(0, -20), (220, 255, 200), 10)
        if gs["kind"] == "ore":                     # v1.0: 마력 바위 → 부스러기
            lo, hi = D.SHARD_DROP["ore"]
            k = self.rng.randint(lo, hi)
            s.shards += k
            self.floater(pos + V(0, -94), f"마력 부스러기 +{k}", (220, 200, 255), icon="crystal")
        if gs["kind"] == "hive" and self.rng.random() < 0.3:
            s.add_mat("firefly", 1)
            self.floater(pos + V(0, -94), "반딧불 가루 +1", U.CREAM, icon="firefly")
        elif gs["kind"] == "fherb":
            self.food_bonus(pos + V(0, -94), "mushroom", 0.25)
        elif gs["kind"] == "herb":
            self.food_bonus(pos + V(0, -94), self.rng.choice(["potato", "carrot"]), 0.15)

    # ═══════════════════ 소리 · 화면 전환 ═══════════════════
    def sfx(self, name, gap=0.05):
        self.audio.play(name, gap)

    def fade_to(self, fn):
        """화면을 어둡게 → fn 실행 → 다시 밝게."""
        if self.fade_dir:
            return
        self.fade_dir = 1
        self.fade_fn = fn

    def update_fade(self, dt):
        if self.fade_dir > 0:
            self.fade = min(1, self.fade + dt * 3.2)
            if self.fade >= 1:
                fn, self.fade_fn = self.fade_fn, None
                if fn:
                    fn()
                self.fade_dir = -1
        elif self.fade_dir < 0:
            self.fade = max(0, self.fade - dt * 2.4)
            if self.fade <= 0:
                self.fade_dir = 0

    def pick_music(self):
        if self.mode == "title":
            self.audio.music("title")
        elif self.scene == "plaza":
            self.audio.music("market")
        elif self.s and self.s.hour >= 18:
            self.audio.music("night")
        else:
            self.audio.music("shop_day")

    def food_bonus(self, pos, f, chance, n=1):
        """제작 재료를 얻을 때 덤으로 요리 재료."""
        if self.rng.random() >= chance:
            return
        first = sum(self.s.food.values()) == 0
        self.s.add_food(f, n)
        self.floater(V(pos), f"덤! {D.FOODS[f][0]} +{n}", (255, 236, 170), icon="food:" + f)
        if first:
            self.queue.append(lambda: self.toast("요리 재료를 얻었어요! 작업실 부엌(화덕)에서 요리해 먹으면 기력이 차요.", 5))

    # ═══════════════════ 메시지 · 이펙트 ═══════════════════
    def toast(self, text, t=3.6):
        self.messages.append([text, t])
        self.messages = self.messages[-3:]

    def floater(self, pos, text, color=U.GOLD, icon=None):
        """떠오르는 글씨. icon: 재료 id 또는 'coin' → 글씨 왼쪽에 아이콘."""
        self.floaters.append([V(pos), text, 1.6, color, icon])

    def hearts(self, pos, n=5):
        self.sfx("heart", 0.2)
        for _ in range(n):
            self.particles.append(dict(p=V(pos) + V(self.rng.uniform(-20, 20), -60), v=V(self.rng.uniform(-20, 20), -60), t=1.2, kind="heart"))

    def sparkle(self, pos, col=(255, 230, 150), n=10):
        self.sfx("sparkle", 0.15)
        for _ in range(n):
            a = self.rng.uniform(0, 6.28)
            self.particles.append(dict(p=V(pos), v=V(math.cos(a), math.sin(a)) * self.rng.uniform(40, 110), t=0.7, kind="dot", col=col))

    def open_menu(self, m):
        if not isinstance(m, M.Dialogue):
            self.sfx("open", 0.1)
        self.menu = m

    def close_menu(self):
        if self.menu is not None and not isinstance(self.menu, M.Dialogue):
            self.sfx("close", 0.1)
        self.menu = None

    TOUCH_WORDS = [("초록 칸에서 스페이스!", "초록 칸에서 화면을 톡!"), ("스페이스로 마법을 쏴서", "마법 버튼을 꾹 눌러")]

    def push_lines(self, lines, on_done=None, title=None):
        if self.touch.enabled:        # 터치 조작일 땐 키보드 설명을 버튼 설명으로
            fixed = []
            for ln in lines:
                if isinstance(ln, tuple) and len(ln) >= 2 and isinstance(ln[1], str):
                    t = ln[1]
                    for a, b in self.TOUCH_WORDS:
                        t = t.replace(a, b)
                    ln = (ln[0], t) + tuple(ln[2:])
                fixed.append(ln)
            lines = fixed
        self.queue.append(lambda: self.open_menu(M.Dialogue(self, lines, on_done=on_done, title=title)))

    def push_story(self, ch):
        s = self.s
        if ch in s.story_seen:
            return
        title = f"제 {ch}장 · {D.CHAPTERS[ch - 1][1]}"

        def done():
            s.story_seen.append(ch)
            for k, v in D.NPCS.items():
                if v["met"] <= ch:
                    s.npc[k]["met"] = True
            if ch >= 5:
                s.npc["cecilia"]["met"] = True
            if ch == 5:
                s.competition_until = s.day + 5
                s.refresh_orders(self.rng)
            if ch == 7:
                self.run_ending()
            s.save()
        if A.exists(f"story/chapter_{ch}"):
            self.queue.append(lambda: self.open_menu(M.ChapterCard(self, ch)))
        self.push_lines(S.CHAPTER_SCRIPT[ch], on_done=done, title=title)

    def run_ending(self):
        s = self.s
        warm = s.stats.get("quests_done", 0) >= 4
        moon = s.luna >= 100
        lines = list(S.ENDING["basic"])
        if warm:
            lines += S.ENDING["warm"]
            if "portrait" not in s.deco_owned:
                s.deco_owned.append("portrait")
        if moon:
            lines += S.ENDING["moon"]
        lines += S.CECILIA_EPILOGUE + S.ENDING["free"]
        s.ending = "moon" if moon else "warm" if warm else "basic"

        def fin():
            s.free = True
            self.toast(f"엔딩: {'달빛' if moon else '따뜻한' if warm else '기본'} 엔딩 · 자유 경영 모드가 열렸어요")
            s.save()
        self.push_lines(lines, on_done=fin, title="에필로그")

    # ═══════════════════ 시간 ═══════════════════
    def hhmm(self):
        h = int(self.s.hour)
        m = int((self.s.hour - h) * 60) // 10 * 10
        return f"{h:02d}:{m:02d}"

    def advance_time(self, dt):
        s = self.s
        before = s.hour
        s.hour += dt / D.HOUR_SECONDS
        if self.scene == "plaza":
            self.update_market_events(before, s.hour)
            if s.hour >= 24:
                self.finish_market()
            return
        if self.shop_open and s.hour >= D.SHOP_CLOSE:
            self.set_shop(False, auto=True)
        if self.market_today() and before < 17.5 <= s.hour:
            self.toast("달빛 장터가 곧 열려요! 6시에 광장으로 출발합니다.")
        if self.market_today() and s.hour >= 18 and self.scene != "plaza":
            self.go_market()
        if before < 18 <= s.hour and s.noel_here():
            self.toast("저택 앞 등불 아래에 노엘이 왔어요.")
        if s.hour >= 24:
            s.hour = 24
            self.toast("리라는 너무 졸려서 그대로 잠들었어요…")
            self.begin_sleep(force=True)

    # ═══════════════════ 가게 영업 ═══════════════════
    def set_shop(self, open_, auto=False):
        s = self.s
        if open_:
            if self.market_today() and s.hour >= 17:
                self.toast("오늘 저녁은 달빛 장터예요.")
                return
            if s.hour < D.SHOP_OPEN:
                self.toast("가게는 9시부터 열 수 있어요.")
                return
            if s.hour >= D.SHOP_CLOSE:
                self.toast("오늘 영업 시간이 끝났어요.")
                return
            if not any(s.shelf_count(i) for i in range(6) if s.shelves[i]):
                self.toast("진열대가 비어 있어요. 그래도 문을 열었어요.")
            self.shop_open = True
            if self.sched_day != s.day:
                self.build_schedule()
            if self.scene != "shop":
                self.toast("루나가 가게를 봐 줄 거예요. 판매 알림이 올라와요.")
            else:
                self.toast("영업 시작! 등불이 켜졌어요.")
        else:
            self.shop_open = False
            self.toast("영업 마감." if not auto else "오후 6시, 영업이 끝났어요.")

    def build_schedule(self):
        s = self.s
        self.sched_day = s.day
        n = s.customers_today()
        start = max(D.SHOP_OPEN, s.hour)
        times = []
        for _ in range(n):
            # 점심·저녁 붐비는 시간
            r = self.rng.random()
            if r < 0.3:
                t = self.rng.uniform(12, 13.5)
            elif r < 0.55:
                t = self.rng.uniform(16, 17.6)
            else:
                t = self.rng.uniform(10, 17.6)
            if t >= start:
                times.append(("gen", t))
        for k, t in self.today_regulars:
            if t >= start:
                times.append(("npc:" + k, t))
        self.schedule = sorted(times, key=lambda x: x[1])

    def plan_regulars(self):
        s = self.s
        met = s.met_npcs()
        self.rng.shuffle(met)
        pick = []
        for k in met:
            chance = 0.35 + s.npc[k]["aff"] / 200
            if s.npc[k]["quest"] == "active":
                chance = 1
            if self.rng.random() < chance:
                pick.append(k)
        pick = pick[:4]
        self.today_regulars = [(k, self.rng.uniform(10.5, 17.2)) for k in pick]

    def spawn_customer(self, kind):
        s = self.s
        sm = self.maps["shop"]
        if kind == "gen":
            ti = self.rng.randrange(len(D.CUSTOMER_TYPES))
            name, likes, budget, maxn, col, hat = D.CUSTOMER_TYPES[ti]
            likes = dict(likes)
            c = dict(kind="gen", ti=ti, name=name, likes=likes, budget=budget * self.rng.uniform(0.7, 1.3), maxn=maxn, col=col, hat=hat)
        else:
            k = kind[4:]
            likes = {cat: 5 for cat in D.NPCS[k]["likes"]}
            for cat in D.CAT_ORDER:
                likes.setdefault(cat, 1)
            c = dict(kind="npc", npc=k, name=D.NPCS[k]["name"], likes=likes, budget=D.NPCS[k]["budget"], maxn=4)
        if s.competition_until >= s.day and "potion" in c["likes"]:
            c["likes"]["potion"] *= 0.7
        # 둘러볼 진열대 2~4곳 (좋아하는 분류 먼저)
        shelves = [i for i in range(6) if s.shelves[i]]
        shelves.sort(key=lambda i: -c["likes"].get(D.SHELF_TYPES[s.shelves[i]["type"]][1], 0.3) - self.rng.random() * 2)
        visit = shelves[: self.rng.randint(2, 4)]
        top = max(c["likes"], key=c["likes"].get)
        c.update(pos=V(sm.DOOR[0] + self.rng.uniform(-10, 10), 800), items=[], visit=visit, top=top,
                 reason=None, wait=0, bubble=None, bubble_t=0, seed=self.rng.random() * 9, liked=0)
        path = [V(470, 700)]
        for i in visit:
            x, y = D.SHELF_SLOTS[i]
            path.append(V(x + self.rng.uniform(-20, 20), y + 52))
        path += [V(sm.PAY[0] + self.rng.uniform(-12, 12), sm.PAY[1] + 10), V(470, 700), V(470, 820)]
        c["path"] = path
        c["stops"] = {id(p): ("shelf", i) for p, i in zip(path[1:], visit)}
        c["stops"][id(path[-3])] = ("pay", None)
        c["stage"] = 0
        if not any(D.SHELF_TYPES[s.shelves[i]["type"]][1] == top for i in shelves):
            c["reason"] = "noshelf"
        self.customers.append(c)
        s.log["visitors"] += 1
        if self.scene == "shop":
            self.sfx("doorbell", 0.4)

    def buy_chance(self, c, pid):
        base = 0.8 if D.PROD[pid]["cat"] in [k for k, v in c["likes"].items() if v >= 3] else 0.3
        base *= {90: 1.15, 100: 1.0, 120: 0.8}.get(self.s.price_mode, 1)
        return base

    def at_shelf(self, c, i):
        s = self.s
        sh = s.shelves[i]
        if not sh:
            return
        avail = [p for p, n in sh["stock"].items() if n > 0]
        if not avail:
            if D.SHELF_TYPES[sh["type"]][1] == c["top"] and not c["reason"]:
                c["reason"] = "empty"
            c["bubble"], c["bubble_t"] = "…", 1.2
            return
        self.rng.shuffle(avail)
        for pid in avail:
            if len(c["items"]) >= c["maxn"]:
                break
            price = s.sale_price(pid)
            if price > c["budget"]:
                if not c["reason"]:
                    c["reason"] = "expensive"
                continue
            if self.rng.random() < self.buy_chance(c, pid):
                sh["stock"][pid] -= 1
                if sh["stock"][pid] <= 0:
                    del sh["stock"][pid]
                c["items"].append(pid)
                c["budget"] -= price
                if D.PROD[pid]["cat"] in D.NPCS.get(c.get("npc"), {}).get("likes", []):
                    c["liked"] += 1
                c["bubble"], c["bubble_t"] = "♥", 1.0
                break

    def at_pay(self, c):
        s = self.s
        if c["items"]:
            lucky = s.placed("lunastatue") and s.lucky_day != s.day
            if lucky:
                s.lucky_day = s.day
            total = s.record_sale(c["items"], lucky=lucky)
            self.floater(c["pos"] + V(0, -110), f"+{total:,}원" + (" 행운!" if lucky else ""), icon="coin")
            if self.scene != "shop":
                self.toast(f"루나: {c['name']} 손님이 {len(c['items'])}개 샀어 +{total:,}원", 2.6)
            if c["kind"] == "npc":
                k = c["npc"]
                gain = min(6, c["liked"] * 2)
                if gain:
                    s.add_aff(k, gain)
                    self.hearts(c["pos"], 3)
                s.log["regulars"].append((k, len(c["items"]), gain))
            if self.rng.random() < 0.2:
                self.floater(self.luna + V(0, -50), "냥", U.CREAM)
        else:
            s.miss(c["top"], c["reason"] or "browse")
            c["bubble"], c["bubble_t"] = "💧", 1.4
            if c["kind"] == "npc":
                s.log["regulars"].append((c["npc"], 0, 0))

    def update_customers(self, dt):
        s = self.s
        if self.shop_open:
            while self.schedule and self.schedule[0][1] <= s.hour:
                kind, _ = self.schedule.pop(0)
                if any(s.shelves):
                    self.spawn_customer(kind)
        for c in list(self.customers):
            if c["bubble_t"] > 0:
                c["bubble_t"] -= dt
            if c["wait"] > 0:
                c["wait"] -= dt
                continue
            if c["stage"] >= len(c["path"]):
                self.customers.remove(c)
                continue
            if not self.shop_open and c["stage"] < len(c["path"]) - 3:
                # 마감: 남은 진열대는 건너뛰고 계산대로
                c["stage"] = len(c["path"]) - 3
            tgt = c["path"][c["stage"]]
            d = tgt - c["pos"]
            speed = 120 * dt
            if d.length() > speed:
                c["pos"] += d.normalize() * speed
                c["moving"] = True
                continue
            c["pos"] = V(tgt)
            c["moving"] = False
            stop = c["stops"].get(id(tgt))
            if stop:
                if stop[0] == "shelf":
                    self.at_shelf(c, stop[1])
                    c["wait"] = 0.9
                else:
                    self.at_pay(c)
                    c["wait"] = 0.6
            c["stage"] += 1

    # ═══════════════════ 채집: 슬라임 · 낚시 · 텃밭 ═══════════════════
    def spawn_slimes(self):
        s = self.s
        self.slimes = []
        rng = self.rng
        kinds = ["wool"] * 6 + ["mush"] * 4 + (["crystal"] * 3 + ["bee"] * 3 if s.chapter >= 4 else [])
        for k in kinds:
            self.slimes.append(dict(kind=k, p=V(rng.uniform(1780, 2330), rng.uniform(120, 1400)), hp=D.MONSTER_HP, v=V(), t=0, hurt=0, hop=0))
        if s.npc["kai"]["quest"] == "active" and not s.flags.get("boss_down"):
            self.slimes.append(dict(kind="boss", p=V(2250, 300), hp=D.BOSS_HP, v=V(), t=0, hurt=0))

    def slime_drop(self, sl):
        s = self.s
        dbl = 2 if s.placed("sword") and self.rng.random() < 0.2 else 1
        got = []
        if sl["kind"] == "wool":
            got.append(("wool", 2 * dbl))
            if self.rng.random() < 0.3:
                got.append(("crystal", 1 * dbl))
        elif sl["kind"] == "crystal":
            got.append(("crystal", self.rng.randint(1, 2) * dbl))
        elif sl["kind"] == "bee":
            got.append(("wax", 2 * dbl))
        elif sl["kind"] == "mush":
            if self.rng.random() < 0.5:
                got.append(("firefly", 1 * dbl))
            self.food_bonus(sl["p"] + V(0, -90), "mushroom", 1.0, self.rng.randint(1, 2))
        elif sl["kind"] == "boss":
            got.append(("crystal", 3))
            s.flags["boss_down"] = True
            self.push_lines([("kai", "해냈다! 거대 슬라임이 쓰러졌어! 가게에 가서 부탁 전달해 줘!")])
        if sl["kind"] in ("wool", "crystal", "bee"):
            self.food_bonus(sl["p"] + V(0, -90), "mushroom", 0.3)
        for m, n in got:
            s.add_mat(m, n)
        s.stat("kills")
        # v1.0: 모든 슬라임이 마력 부스러기를 떨어뜨려요 (세공대에서 합쳐 마도석으로)
        lo, hi = D.SHARD_DROP.get(sl["kind"] if sl["kind"] in ("crystal", "boss") else "normal")
        k = self.rng.randint(lo, hi) * dbl
        s.shards += k
        s.stat("shards_got", k)
        if got:
            self.floater(sl["p"] + V(0, -60), " ".join(f"{D.MATS[m][0]}+{n}" for m, n in got), U.CREAM, icon=got[0][0])
        self.floater(sl["p"] + V(0, -88), f"마력 부스러기 +{k}", (220, 200, 255), icon="crystal")
        self.sparkle(sl["p"], (220, 255, 220))

    def update_forest(self, dt):
        s = self.s
        om = self.maps["outdoor"]
        for sl in self.slimes:
            if sl["hp"] <= 0:
                continue
            sl["t"] -= dt
            if sl["t"] <= 0:
                sl["t"] = self.rng.uniform(1, 3)
                a = self.rng.uniform(0, 6.28)
                sl["v"] = V(math.cos(a), math.sin(a)) * (30 if sl["kind"] == "boss" else 45)
            if sl["kind"] == "mush":   # 뛰어오를 때만 움직임
                sl["hop"] = sl.get("hop", 0) + dt * 5
                sl["p"] += sl["v"] * dt * (1.6 if math.sin(sl["hop"]) > 0 else 0)
            else:
                sl["p"] += sl["v"] * dt
            sl["p"].x = max(om.FOREST_X + 40, min(2360, sl["p"].x))
            sl["p"].y = max(60, min(1450, sl["p"].y))
            if sl["hurt"] > 0:
                sl["hurt"] -= dt
            if sl["p"].distance_to(self.p) < (70 if sl["kind"] == "boss" else 36):
                push = (self.p - sl["p"])
                if push.length() > 0:
                    self.p += push.normalize() * 24
        self.shot_cd -= dt
        for sh in list(self.shots):
            sh["p"] += sh["v"] * dt
            sh["t"] -= dt
            hit = None
            for sl in self.slimes:
                body = sl["p"] + V(0, -50 if sl["kind"] == "boss" else -22)     # 발밑이 아니라 몸통 기준
                if sl["hp"] > 0 and body.distance_to(sh["p"]) < (74 if sl["kind"] == "boss" else 36):
                    hit = sl
                    break
            if hit:
                hit["hp"] -= sh.get("dmg", s.shot_damage())
                hit["hurt"] = 0.2
                self.sparkle(sh["p"], D.MAGIC_TIERS[sh.get("tier", 0)][3], 6 + sh.get("tier", 0) * 5)
                if hit["hp"] <= 0:
                    self.slime_drop(hit)
                self.shots.remove(sh)
            elif sh["t"] <= 0:
                self.shots.remove(sh)

    def boss_near(self):
        return any(sl["kind"] == "boss" and sl["hp"] > 0 and sl["p"].distance_to(self.p) < 650 for sl in self.slimes)

    def shoot(self):
        if self.shot_cd > 0:
            return
        # v1.0: 마법은 기력을 써요 (마력 3칸 = 기력 1 · 거대 슬라임 앞에선 1발 = 기력 1)
        if not self.s.pay_shot(boss=self.boss_near()):
            self.shot_cd = 0.6
            if getattr(self, "_nomana_t", -9) < self.t - 3:
                self._nomana_t = self.t
                self.toast("기력이 없어서 마법이 안 나가요… 요리를 먹고 오자! (루나: 배고파…)")
                self.sfx("error")
            return
        self.shot_cd = 0.32
        self.sfx("magic")
        d = V(DIRS[self.face])
        tier = self.s.magic_tier
        self.shots.append(dict(p=self.p + V(0, -40) + d * 20, v=d * (560 + tier * 60), t=0.6, tier=tier, dmg=self.s.shot_damage()))

    def plant_or_tend(self, i):
        s = self.s
        p = s.plots[i]
        if not p["crop"]:
            self.open_menu(M.SeedMenu(self, i))
            return
        need, yld = D.CROPS[p["crop"]]
        if p["days"] >= need:
            n = yld * (2 if s.placed("wheat") and self.rng.random() < 0.2 else 1)
            s.add_mat(p["crop"], n)
            self.sfx("pop")
            s.stat("harvests")
            self.floater(self.maps["outdoor"].plot_rect(i).center, f"{D.MATS[p['crop']][0]} +{n}", U.CREAM, icon=p["crop"])
            self.food_bonus(V(self.maps["outdoor"].plot_rect(i).center) + V(0, -34), self.rng.choice(["potato", "potato", "carrot", "wheat"]), 0.6)
            self.sparkle(self.maps["outdoor"].plot_rect(i).center)
            s.plots[i] = {"crop": None, "days": 0, "watered": False}
        elif not p["watered"]:
            if s.energy < 1:
                self.toast("기력이 부족해요. 한스네 수레에서 재료를 살 수도 있어요.")
                return
            s.energy -= 1
            p["watered"] = True
            self.sparkle(self.maps["outdoor"].plot_rect(i).center, (140, 200, 255))
            self.toast(f"물을 줬어요. 자고 나면 자라요. ({p['days'] + 1}/{need}일)")
        else:
            self.toast("오늘은 이미 물을 줬어요.")

    # ═══════════════════ 장터 ═══════════════════
    def market_today(self):
        m = self.s.market
        return m["signed"] and not m["done"] and m["day"] == self.s.day

    def go_market(self):
        s = self.s
        self.shop_open = False
        self.customers = []
        self.scene = "plaza"
        s.hour = 18.0
        self.p = V(640, 620)
        self.luna = V(600, 640)
        cart = s.market.get("cart", {})
        self.market_slots = [None] * 6
        self.market_stock = {}
        for i, (pid, n) in enumerate(list(cart.items())[:6]):
            self.market_slots[i] = pid
            self.market_stock[pid] = n
        helpers = s.market.get("helpers", [])
        self.market = dict(lira=0, rivals={"은빛 탑 상회": 0, "빵집 보리": 0, "꽃집 라일락": 0, "사탕 가게": 0},
                           spawn=0, events=set(), helpers=helpers, cec_stop=False, shared=None, restocked=False)
        self.push_lines(S.MARKET_LINES["open"])

    def update_market(self, dt):
        s = self.s
        mk = self.market
        if not mk:
            return
        hours = dt / D.HOUR_SECONDS
        rates = {"은빛 탑 상회": 42000, "빵집 보리": 16000, "꽃집 라일락": 13000, "사탕 가게": 11000}
        for k, r in rates.items():
            if k == "은빛 탑 상회" and mk["cec_stop"]:
                continue
            mk["rivals"][k] += r * hours * self.rng.uniform(0.6, 1.4)
        rate = 18 * (1.2 if "momo" in mk["helpers"] else 1)
        if 21 <= s.hour < 21.6:
            rate *= 2.4 if "theo" in mk["helpers"] else 1.6
        mk["spawn"] += rate * hours
        while mk["spawn"] >= 1:
            mk["spawn"] -= 1
            self.spawn_market_customer()
        for c in list(self.customers):
            if c["wait"] > 0:
                c["wait"] -= dt
                continue
            tgt = c["path"][c["stage"]]
            d = tgt - c["pos"]
            sp = 140 * dt * (1.5 if "kai" in mk["helpers"] else 1)
            if d.length() > sp:
                c["pos"] += d.normalize() * sp
                c["moving"] = True
                continue
            c["pos"] = V(tgt)
            c["moving"] = False
            if c["stage"] == 1:
                self.market_buy(c)
                c["wait"] = 0.8
            c["stage"] += 1
            if c["stage"] >= len(c["path"]):
                self.customers.remove(c)
            if c.get("bubble_t", 0) > 0:
                c["bubble_t"] -= dt

    def spawn_market_customer(self, rich=False):
        ti = self.rng.randrange(len(D.CUSTOMER_TYPES))
        name, likes, budget, maxn, col, hat = D.CUSTOMER_TYPES[ti if not rich else 2]
        side = self.rng.choice([(-20, self.rng.uniform(300, 760)), (1300, self.rng.uniform(300, 760)), (self.rng.uniform(200, 1080), 820)])
        start = V(side)
        stand = V(self.rng.uniform(530, 750), self.rng.uniform(510, 560))
        c = dict(kind="gen", ti=ti, name=name, likes=dict(likes), budget=budget * (2 if rich else 1), maxn=maxn + (1 if rich else 0),
                 col=col, hat=hat, pos=start, path=[start, stand, V(self.rng.choice([-40, 1320]), self.rng.uniform(300, 760))],
                 stage=1, wait=0, items=[], seed=self.rng.random() * 9, bubble=None, bubble_t=0, moving=True)
        if self.rng.random() < 0.35:   # 다른 노점 손님
            c["path"][1] = V(self.rng.choice([250, 1030]), self.rng.choice([380, 690]))
            c["other"] = True
        self.customers.append(c)

    def market_buy(self, c):
        if c.get("other"):
            return
        s = self.s
        mk = self.market
        items = []
        avail = [p for p in self.market_slots if p and self.market_stock.get(p, 0) > 0]
        self.rng.shuffle(avail)
        for pid in avail:
            if len(items) >= c["maxn"]:
                break
            liked = D.PROD[pid]["cat"] in [k for k, v in c["likes"].items() if v >= 2]
            if self.rng.random() < (0.75 if liked else 0.35) and s.sale_price(pid) <= c["budget"]:
                self.market_stock[pid] -= 1
                items.append(pid)
                c["budget"] -= s.sale_price(pid)
        if items:
            base = sum(s.sale_price(p) * (1.2 if "mignon" in mk["helpers"] and D.PROD[p]["cat"] == "goods" else 1) for p in items)
            tip = 1.1 if "rosemary" in mk["helpers"] else 1
            total = int(base * s.tip_mult() * tip / 10) * 10
            s.gold += total
            s.total_revenue += total
            s.log["revenue"] += total
            for p in items:
                s.log["sold"][p] = s.log["sold"].get(p, 0) + 1
                s.stat("sold")
            s.add_xp(int(base / 250))
            mk["lira"] += total
            self.floater(c["pos"] + V(0, -110), f"+{total:,}원", icon="coin")
            c["bubble"], c["bubble_t"] = "♥", 1.2
        else:
            c["bubble"], c["bubble_t"] = "…", 1.2

    def update_market_events(self, before, now):
        mk = self.market
        if not mk:
            return
        s = self.s
        if before < 19 <= now and "e19" not in mk["events"]:
            mk["events"].add("e19")
            self.push_lines(S.MARKET_LINES["e19"])
            for _ in range(6 if "rosemary" in mk["helpers"] else 3):
                self.spawn_market_customer(rich=True)
        if before < 21 <= now and "e21" not in mk["events"]:
            mk["events"].add("e21")
            self.push_lines(S.MARKET_LINES["e21"])
            if "hans" in mk["helpers"] and self.market_slots[0]:
                pid = self.market_slots[0]
                n = min(5, s.products[pid])
                s.products[pid] -= n
                self.market_stock[pid] = self.market_stock.get(pid, 0) + n
                if n:
                    self.toast(f"한스: 수레에서 {D.PROD[pid]['name']} {n}개 보충했다.")
        if before < 22 <= now and "e22" not in mk["events"]:
            mk["events"].add("e22")
            mk["cec_stop"] = True
            self.queue.append(lambda: self.open_menu(M.Dialogue(self, S.MARKET_LINES["e22"], on_done=self.ask_share)))

    def ask_share(self):
        s = self.s
        potions = [p for p in D.PROD_ORDER if D.PROD[p]["cat"] == "potion" and (s.products[p] + self.market_stock.get(p, 0)) > 0]
        can = sum(s.products[p] + self.market_stock.get(p, 0) for p in potions) >= 3

        def share():
            left = 3
            for p in potions:
                for pool in ("mk", "inv"):   # 장터 진열분부터, 모자라면 창고에서
                    if left <= 0:
                        break
                    have = max(0, s.products.get(p, 0) if pool == "inv" else self.market_stock.get(p, 0))
                    take = min(left, have)
                    if take <= 0:
                        continue
                    if pool == "inv":
                        s.products[p] -= take
                    else:
                        self.market_stock[p] = self.market_stock.get(p, 0) - take
                    left -= take
            self.market["cec_stop"] = False
            self.market["shared"] = True
            s.market["shared"] = True
            s.add_aff("cecilia", 20)
            self.push_lines(S.MARKET_LINES["share"])

        def keep():
            self.market["shared"] = False
            s.market["shared"] = False
            self.push_lines(S.MARKET_LINES["noshare"])
        opts = [("물약 3개를 나눠 준다", share, can), ("우리 부스에 집중한다", keep, True)]
        self.open_menu(M.Choice(self, "cecilia", "세실리아의 부스에 물약이 하나도 없어요. 어떻게 할까요?", opts))

    def finish_market(self):
        s = self.s
        mk = self.market
        win = mk["lira"] > mk["rivals"]["은빛 탑 상회"]
        s.market["done"] = True
        s.market["rank"] = 1 if win else 2
        s.stat("market_done")
        if win and "plaque" not in s.deco_owned:
            s.deco_owned.append("plaque")
        # 남은 장터 재고는 창고로
        for pid, n in self.market_stock.items():
            s.products[pid] += max(0, n)
        self.market_stock = {}
        lines = list(S.MARKET_LINES["win" if win else "lose"]) + S.MARKET_LINES["after"]
        s.hour = 24

        def back():
            self.scene = "shop"
            self.p = V(1040, 724)
            self.customers = []
            self.market = None
            self.begin_sleep(force=True)
        self.queue.append(lambda: self.open_menu(M.Dialogue(self, lines, on_done=back, title="달빛 장터 결과")))
        self.menu = None

    # ═══════════════════ 잠 ═══════════════════
    def begin_sleep(self, force=False):
        if not force and self.s.hour < 18:
            self.open_menu(M.Confirm(self, "아직 오후 6시 전이에요. 벌써 하루를 마칠까요?", lambda: self.open_menu(M.Report(self))))
            return
        self.menu = None
        self.queue.append(lambda: self.open_menu(M.Report(self)))

    def do_sleep(self):
        s = self.s
        self.shop_open = False
        self.messages = []
        msgs = s.sleep(self.rng)
        self.scene = "shop"
        self.cam = V(0, 0)
        self.floaters, self.particles = [], []
        self.p = V(1040, 724)
        self.luna = V(1060, 720)
        self.start_day()
        for m in msgs:
            self.toast(m, 4)
        # 장 진행 (v0.8: 하룻밤에 한 장씩 · 마지막 장은 장터를 마친 뒤)
        nxt = s.next_chapter_due()
        if nxt:
            s.chapter = nxt
            self.push_story(nxt)
            if nxt < 7:
                self.queue.append(lambda n=nxt: self.toast(f"제 {n}장이 열렸어요! 새 레시피와 재료를 확인해 보세요 (J)", 5))
        elif s.chapter == 6 and s.total_revenue >= D.CHAPTERS[6][2] and not s.market["done"]:
            self.queue.append(lambda: self.toast("누적 매출은 충분해요! 달빛 장터를 마치면 마지막 장이 열려요 (게시판).", 5))
        # 편지는 이제 우편함으로 (sleep()에서 도착)
        # 장터 준비
        if s.market["signed"] and not s.market["done"] and s.market["day"] == s.day:
            self.queue.append(lambda: self.open_menu(M.MarketPrep(self)))
        s.save()

    # ═══════════════════ 상호작용 ═══════════════════
    def npcs_here(self):
        """지금 화면에 서 있는 말 걸 수 있는 인물: (id, pos)."""
        s = self.s
        out = []
        if self.scene == "outdoor":
            visiting = {c["npc"] for c in self.customers if c["kind"] == "npc"}
            if 8 <= s.hour < 19:
                for k in s.met_npcs():
                    if k not in visiting:
                        out.append((k, V(D.NPCS[k]["home"])))
                if s.npc["cecilia"]["met"] and 9 <= s.hour < 18:
                    out.append(("cecilia", V(720, 925)))
        elif self.scene == "shop":
            for c in self.customers:
                if c["kind"] == "npc":
                    out.append((c["npc"], c["pos"]))
        return out

    def interactables(self):
        mp = self.maps[self.scene]
        items = [dict(o, kind="obj") for o in mp.objects(self)]
        for k, pos in self.npcs_here():
            items.append(dict(id="npc:" + k, pos=pos, label=f"{D.SPEAKER[k]} · 말 걸기", kind="npc"))
        return items

    def nearest(self):
        best, bd = None, 1e9
        for o in self.interactables():
            d = self.p.distance_to(V(o["pos"])) + (45 if o["kind"] == "luna" else 0)
            if d < o.get("radius", 78) + (45 if o["kind"] == "luna" else 0) and d < bd:
                best, bd = o, d
        return best

    def interact(self):
        o = self.nearest()
        if not o:
            return
        s = self.s
        oid = o["id"]
        if o["kind"] == "npc":
            self.open_menu(M.NPCMenu(self, oid[4:]))
            return
        if o["kind"] == "luna":
            self.pet_luna()
            return
        if oid == "cauldron":
            self.open_menu(M.CraftMenu(self))
        elif oid == "stove":
            self.open_menu(M.CookMenu(self))
        elif oid.startswith("shelf"):
            self.open_menu(M.ShelfMenu(self, int(oid[5:])))
        elif oid == "counter":
            self.open_menu(M.CounterMenu(self))
        elif oid == "board":
            self.open_menu(M.BoardMenu(self))
        elif oid == "bed":
            self.begin_sleep()
        elif oid == "door":
            self.go_outdoor()
        elif oid == "house":
            self.go_shop()
        elif oid == "locked":
            if s.free:
                self.open_menu(M.RoomsMenu(self))
            else:
                self.push_lines([("luna", "할머니가 잠가 둔 문이야. 열쇠는… 가게가 네 것이 되면 찾게 될 거야.")])
        elif oid == "portrait":
            if s.npc["rosemary"]["quest"] == "active" and not s.flags.get("page_found"):
                s.flags["page_found"] = True
                self.push_lines([("narr", "초상화 액자 뒤에서 누렇게 바랜 종이 한 장이 떨어졌다."),
                                 ("lira", "레시피 노트의 찢어진 쪽…! '장미 달빛 입욕 볼'이라고 적혀 있어."),
                                 ("luna", "이제 솥에서 만들 수 있어. 월광초가 필요하지만.")])
            else:
                self.push_lines([("narr", "은발을 틀어 올린 할머니가 액자 속에서 웃고 있다."),
                                 ("lira", "할머니, 오늘도 잘 부탁해요.")])
        elif oid.startswith("plot"):
            self.plant_or_tend(int(oid[4:]))
        elif oid.startswith("fish"):
            if s.energy < 2:
                self.toast("기력이 부족해요 (낚시는 기력 2).")
            else:
                s.energy -= 2
                self.sfx("splash")
                self.open_menu(M.Fishing(self, spot=0 if oid == "fish_n" else 1))
        elif oid == "bench":
            if not s.flags.get("bench"):
                self.push_lines([("narr", "먼지 쌓인 낡은 세공대. 할머니가 마도석을 다듬던 자리다."),
                                 ("luna", "망치 자루가 부러졌어. 마을 길가 공방 수레의 브람 할아범이라면 고칠 수 있을 거야.")])
            else:
                self.open_menu(M.MergeMenu(self))
        elif oid == "bram":
            if not s.flags.get("bram_met"):
                s.flags["bram_met"] = True
                s.flags["bench"] = True
                s.npc["bram"]["met"] = True
                self.push_lines(S.BRAM_INTRO, on_done=lambda: self.open_menu(M.BramMenu(self)), title="공방 장인 · 브람 코퍼")
            else:
                self.open_menu(M.BramMenu(self))
        elif oid.startswith("trap"):
            i = int(oid[4:])
            if s.trap_ready(i):
                got = s.pull_trap(i, self.rng)
                self.sfx("splash")
                pos = V(o["pos"])
                txt = []
                for k, n in got.items():
                    nm = "강 송어" if k == "food:fish" else ("마력 부스러기" if k == "shard" else D.MATS[k][0])
                    txt.append(f"{nm}+{n}")
                self.floater(pos + V(0, -70), " ".join(txt), U.CREAM, icon=next((k for k in got if k not in ("shard",)), "scale"))
                self.sparkle(pos, (160, 210, 255), 14)
                s.save()
            elif s.traps[i]:
                self.toast("통발을 놓아 두었어요. 내일 걷으러 와요!")
            else:
                ok, msg = s.set_trap(i)
                self.toast(msg)
                if ok:
                    self.sfx("splash")
        elif oid.startswith("totem"):
            i = int(oid[5:])
            if s.totem_at == i:
                self.toast("토템이 이 낚시터를 지키고 있어요. (노란 영역 +%d%%)" % round((D.TOTEM_BONUS[s.gear['totem']] - 1) * 100))
            else:
                s.totem_at = i
                self.sfx("sparkle")
                self.sparkle(o["pos"], (255, 230, 150), 16)
                self.toast(("북쪽" if i == 0 else "남쪽") + " 낚시터에 토템을 세웠어요!")
        elif oid.startswith("berry"):
            i = int(oid[5:])
            self.day_flags[f"berry{i}"] = True
            s.add_mat("berry", 2)
            self.sfx("pop")
            self.floater(V(o["pos"]) + V(0, -60), "숲딸기 +2", U.CREAM, icon="berry")
            self.food_bonus(V(o["pos"]) + V(0, -94), "mushroom", 0.6)
        elif oid.startswith("fly"):
            i = int(oid[3:])
            self.day_flags[f"fly{i}"] = True
            n = self.rng.randint(1, 2)
            s.add_mat("firefly", n)
            self.floater(V(o["pos"]) + V(0, -60), f"반딧불 가루 +{n}", U.CREAM, icon="firefly")
            self.food_bonus(V(o["pos"]) + V(0, -94), "mushroom", 0.4)
            self.sparkle(o["pos"], (255, 250, 170), 16)
        elif oid == "mailbox":
            self.open_menu(M.MailMenu(self))
        elif oid.startswith("gather"):
            i = int(oid[6:])
            gs = next((x for x in self.gather if x["i"] == i), None)
            if gs:
                self.do_gather(gs)
        elif oid == "hans_shop":
            self.open_menu(M.HansMenu(self))
        elif oid == "noel":
            if not s.flags.get("noel_intro"):
                s.flags["noel_intro"] = True
                self.push_lines([("noel", "스승님 가게에 불이 켜져 있길래. 노엘 브라이어라고 합니다. 스승님의 옛 제자죠."),
                                 ("noel", "기력이 모자라 보이는군요, 꼬마 마녀님. 한 병이면 평생 갑니다. 대신 값은 제대로 받습니다.")],
                                on_done=lambda: self.open_menu(M.NoelMenu(self)))
            else:
                self.open_menu(M.NoelMenu(self))
        elif oid == "dew":
            s.flags["dew"] = True
            self.sparkle(o["pos"], (200, 220, 255), 20)
            self.push_lines([("narr", "강물 위로 떨어진 달빛이 이슬처럼 맺혔다. 작은 병에 조심스럽게 담았다."),
                             ("luna", "테오한테 가져다줘. 소원을 품은 마도석도 잊지 말고.")])
        elif oid == "booth":
            self.open_menu(M.MarketBooth(self))

    def pet_luna(self):
        s = self.s
        if not s.luna_petted:
            s.luna_petted = True
            s.luna = min(100, s.luna + 8)
            self.hearts(self.luna, 6)
            line = self.rng.choice(["…나쁘지 않네.", "귀 뒤. 거기.", "골골…", "오늘은 특별히 허락한다."])
            self.floater(self.luna + V(0, -60), f"루나: {line}", U.CREAM)
            self.luna_rewards()
        elif s.luna_snacks < 2 and s.materials["scale"] > 0:
            s.materials["scale"] -= 1
            s.luna_snacks += 1
            s.luna = min(100, s.luna + 3)
            self.hearts(self.luna, 3)
            self.floater(self.luna + V(0, -60), "생선 간식! 호감도 +3", U.CREAM)
            self.luna_rewards()
        else:
            self.floater(self.luna + V(0, -60), "…오늘은 됐다." if s.luna_snacks >= 2 or s.materials["scale"] == 0 else "…", U.CREAM)

    def luna_rewards(self):
        s = self.s
        tier = s.magic_tier
        if tier > s.flags.get("magic_tier", 0):
            s.flags["magic_tier"] = tier
            name, hits = D.MAGIC_TIERS[tier][1], D.MAGIC_TIERS[tier][2]
            self.toast(f"루나 Lv.{s.luna_level}! 리라의 마법이 「{name}」(으)로 진화했어요 · 몬스터 {hits}타", 5)
            self.sparkle(self.luna, D.MAGIC_TIERS[tier][3], 24)
        for th, text in ((30, "루나가 가게를 순찰하기 시작했어요 (하루 손님 +1)"), (60, "루나가 아침마다 재료를 물어 와요 · 루나 인형 레시피 해금"), (100, "루나가 조각상을 선물했어요! (B 꾸미기)")):
            key = f"luna{th}"
            if s.luna >= th and not s.flags.get(key):
                s.flags[key] = True
                self.toast(text, 5)
                if th == 100 and "lunastatue" not in s.deco_owned:
                    s.deco_owned.append("lunastatue")

    # ═══════════════════ 장면 이동 ═══════════════════
    def go_outdoor(self):
        self.floaters, self.particles, self.shots = [], [], []
        self.villagers, self.ambient = [], []
        self.scene = "outdoor"
        self.p = V(380, 470)
        self.luna = V(410, 500)
        self.face = "down"

    def go_shop(self):
        self.floaters, self.particles, self.shots = [], [], []
        self.villagers, self.ambient = [], []
        self.scene = "shop"
        self.p = V(470, 730)
        self.luna = V(430, 740)
        self.face = "up"

    def check_region(self):
        s = self.s
        om = self.maps["outdoor"]
        reg = om.region(self.p)
        if not reg:
            return
        if reg == "forest" and s.forest_paid_day != s.day:
            if s.energy < 3:
                self.p.x = om.FOREST_X - 10
                self.toast("숲에 들어가려면 기력 3이 필요해요.")
                return
            s.energy -= 3
            s.forest_paid_day = s.day
            self.toast("숲에 들어왔어요 (기력 -3). " + ("마법 버튼을 꾹 눌러 마법!" if self.touch.enabled else "스페이스로 마법!"))
        if reg not in s.first_visits:
            s.first_visits.append(reg)
            self.push_lines(S.FIRST_VISIT[reg], title={"farm": "할머니의 텃밭", "river": "반짝이는 강가", "forest": "달빛 숲"}[reg])

    # ═══════════════════ 입력 ═══════════════════
    def key(self, k):
        if self.mode == "title":
            return
        if k == pg.K_ESCAPE:
            if self.placing:
                self.placing = None
                self.toast("배치를 취소했어요.")
            else:
                self.open_menu(M.Pause(self))
        elif k == pg.K_e:
            self.interact()
        elif k == pg.K_o:
            if self.scene == "plaza":
                return
            self.set_shop(not self.shop_open)
        elif k in (pg.K_i, pg.K_TAB):
            self.open_menu(M.Bag(self))
        elif k == pg.K_j:
            self.open_menu(M.Goals(self))
        elif k == pg.K_r:
            self.open_menu(M.Notebook(self))
        elif k == pg.K_b:
            if self.scene != "shop":
                self.toast("꾸미기는 가게 안에서 할 수 있어요.")
            else:
                self.open_menu(M.Decorate(self))
        elif k == pg.K_F1:
            self.open_menu(M.Help(self))
        elif k == pg.K_h:
            if self.luna.distance_to(self.p) < 160:
                self.pet_luna()
            else:
                self.toast("루나가 멀리 있어요.")
        elif k == pg.K_t:
            self.tracker_open = not self.tracker_open
            self.sfx("page")
        elif k == pg.K_F9:
            self.open_menu(M.ImageTodo(self))
        elif k == pg.K_F11 and not WEB:
            self.fullscreen = not self.fullscreen
            self.window = pg.display.set_mode((0, 0), pg.FULLSCREEN) if self.fullscreen else pg.display.set_mode((W, H), pg.RESIZABLE)

    def click_world(self, pos):
        if not self.placing or self.scene != "shop":
            return
        s = self.s
        d = self.placing
        sm = self.maps["shop"]
        if D.DECO[d][1] == "wall":
            best = None
            for i, (x, y) in enumerate(D.WALL_SLOTS):
                if abs(pos[0] - x) < 50 and abs(pos[1] - y) < 70:
                    best = i
            used = {v[1] for k, v in s.deco_placed.items() if v[0] == "wall" and k != d}
            if best is None or best in used:
                self.toast("벽의 빈 걸이 칸을 눌러 주세요.")
                return
            s.deco_placed[d] = ["wall", best]
        else:
            cell = self.snap(pos)
            if not sm.deco_valid(self, cell, ignore=d):
                self.toast("여기엔 놓을 수 없어요 (통로·진열대 앞은 비워 둬요).")
                return
            s.deco_placed[d] = ["floor", cell[0], cell[1]]
        self.toast(f"{D.DECO[d][0]}을(를) 놓았어요. 효과: {D.DECO[d][3]}")
        self.placing = None
        s.save()

    def snap(self, pos):
        c = ShopMap.DECO_CELL
        return (int(pos[0] // c) * c + c // 2, int(pos[1] // c) * c + c // 2 + 20)

    def mouse_canvas(self, pos):
        ww, wh = self.window.get_size()
        sc = min(ww / W, wh / H)
        ox, oy = (ww - W * sc) / 2, (wh - H * sc) / 2
        return ((pos[0] - ox) / sc, (pos[1] - oy) / sc)

    # ═══════════════════ 업데이트 ═══════════════════
    def update(self, dt):
        self.t += dt
        self.dt_last = dt
        self.update_fade(dt)
        self.hint_t -= dt
        for m in self.messages:
            m[1] -= dt
        self.messages = [m for m in self.messages if m[1] > 0]
        for f in self.floaters:
            f[0].y -= 40 * dt
            f[2] -= dt
        self.floaters = [f for f in self.floaters if f[2] > 0]
        for p in self.particles:
            p["p"] += p["v"] * dt
            p["t"] -= dt
        self.particles = [p for p in self.particles if p["t"] > 0]
        self.pick_music()
        self.touch.update(dt)
        if self.mode != "play":
            return
        self.watch_stats()
        self.update_ambient(dt)
        if self.menu is None and self.queue:
            self.queue.pop(0)()
        if self.menu is not None:
            if hasattr(self.menu, "update"):
                self.menu.update(dt)
            return
        s = self.s
        self.fast = bool(pg.key.get_pressed()[pg.K_z]) or self.touch.fast_on   # Z 꾹: 시간 4배속 (기다림 줄이기)
        tdt = dt * (4 if self.fast else 1)
        self.advance_time(tdt)
        # 이동
        keys = pg.key.get_pressed()
        d = V((keys[pg.K_d] or keys[pg.K_RIGHT]) - (keys[pg.K_a] or keys[pg.K_LEFT]),
              (keys[pg.K_s] or keys[pg.K_DOWN]) - (keys[pg.K_w] or keys[pg.K_UP]))
        tv = self.touch.move_vec()
        if d.length() == 0 and tv.length() > 0:     # 터치 조이스틱
            d = V(tv)
        self.moving = d.length() > 0
        if self.moving:
            d = d.normalize()
            if abs(d.x) > abs(d.y):
                self.face = "right" if d.x > 0 else "left"
            else:
                self.face = "down" if d.y > 0 else "up"
            sp = 230 * (1.6 if keys[pg.K_LSHIFT] or keys[pg.K_RSHIFT] or (tv.length() > 0 and self.touch.running()) else 1)
            self.move(d * sp * dt)
        if (keys[pg.K_SPACE] or self.touch.magic_held()) and self.scene == "outdoor" and self.p.x > self.maps["outdoor"].FOREST_X:
            self.shoot()
        # 루나 따라오기
        # 리라 '뒤쪽'을 따라와서 앞에 있는 물건·사람을 가리지 않게
        back = {"down": V(-40, -30), "up": V(40, 34), "left": V(58, 6), "right": V(-58, 6)}[self.face]
        target = self.p + back
        if self.luna.distance_to(target) > 6:
            self.luna += (target - self.luna) * min(1, dt * 3)
        if self.scene == "outdoor":
            self.check_region()
            self.update_forest(dt)
            mw, mh = self.maps["outdoor"].size
            self.cam = V(max(0, min(mw - W, self.p.x - W / 2)), max(0, min(mh - H, self.p.y - H / 2)))
        else:
            self.cam = V(0, 0)
        if self.scene == "plaza":
            self.update_market(tdt)
        else:
            self.update_customers(tdt)
        self.save_timer += dt
        if self.save_timer > 60:
            self.save_timer = 0
            s.save()

    def move(self, delta):
        mp = self.maps[self.scene]
        blockers = mp.all_blockers(self)
        here = pg.Rect(self.p.x - 15, self.p.y - 12, 30, 14)
        if any(here.colliderect(b) for b in blockers):   # 끼임 방지: 이미 겹쳐 있으면 자유롭게 빠져나오기
            self.p += delta
            return
        for axis in (0, 1):
            np_ = V(self.p)
            np_[axis] += delta[axis]
            r = pg.Rect(np_.x - 15, np_.y - 12, 30, 14)
            if not any(r.colliderect(b) for b in blockers):
                self.p = np_
        mw, mh = mp.size
        self.p.x = max(20, min(mw - 20, self.p.x))
        self.p.y = max(20, min(mh - 4, self.p.y))
        if self.scene == "shop" and self.p.y > 790:
            self.go_outdoor()

    # ═══════════════════ 그리기 ═══════════════════
    def walk_frame(self, c, key, height=None):
        """v1.5: 4방향 걷기 스프라이트 시트(walk/<이름>/<방향>_<0~2>)가 있으면 그걸로 그려요.
        움직이는 방향(앞·뒤·좌·우)에 맞는 줄을 고르고, 걸을 땐 걸음→서기→반대 걸음→서기 순서로 바꿔요.
        멈추면 옆을 보고 있던 경우 그 방향, 아니면 앞모습으로 서 있어요. 그림이 없으면 None."""
        p = c["pos"]
        prev = c.get("_pp")
        c["_pp"] = V(p)
        if prev is not None:
            dx, dy = p.x - prev.x, p.y - prev.y
            if abs(dx) > 0.05 or abs(dy) > 0.05:
                c["_dir"] = ("right" if dx > 0 else "left") if abs(dx) > abs(dy) else ("down" if dy > 0 else "up")
        c["_wf"] = False
        if not A.has_walk(key):
            return None
        c["_wf"] = True
        d = c.get("_dir", "down")
        if c.get("moving"):
            i = (0, 1, 2, 1)[int(self.t * 7 + c["seed"]) % 4]
        else:
            i = 1
            if d in ("up",):
                d = "down"
        return A.walk(key, d, i)

    def draw_person(self, surf, c, cam):
        pos = c["pos"] - cam
        x, y = int(pos.x), int(pos.y)
        if c["kind"] == "npc":
            img = self.walk_frame(c, c["npc"], 96) or A.image_or(f"npc_world/{c['npc']}", f"portraits/{c['npc']}", 96)
            bob = abs(math.sin(self.t * 9 + c["seed"])) * (1 if c.get("_wf") else 3) if c.get("moving") else 0
            surf.blit(img, (x - img.get_width() // 2, y - img.get_height() - bob))
        elif A.exists(f"villagers/v{c['ti'] % 8}_standing") and not A.exists(f"npc_world/customer_{c['ti']}"):
            vi = c["ti"] % 8
            moving = c.get("moving")
            # v0.8: 걷는 그림(원본이 왼쪽을 봄)을 걷는 내내 쓰고, 오른쪽으로 갈 때만 뒤집어요 (문워크 수정)
            px = c.get("_px", c["pos"].x)
            if abs(c["pos"].x - px) > 0.05:
                c["_right"] = c["pos"].x > px
            c["_px"] = c["pos"].x
            img = A.pix(f"villagers/v{vi}_{'walking' if moving else 'standing'}", 2)
            if moving and c.get("_right"):
                img = pg.transform.flip(img, True, False)
            ph = self.t * 10 + c["seed"]
            bob = abs(math.sin(ph)) * 3 if moving else 0
            if moving and int(ph / math.pi) % 2:      # 한 발씩 내딛는 느낌: 살짝 눌렸다 펴짐
                img = pg.transform.scale(img, (img.get_width(), img.get_height() - 2))
            if "shadow" not in A._cache:
                sh = pg.Surface((30, 10), pg.SRCALPHA)
                pg.draw.ellipse(sh, (0, 0, 0, 70), sh.get_rect())
                A._cache["shadow"] = sh
            surf.blit(A._cache["shadow"], (x - 15, y - 6))
            surf.blit(img, (x - img.get_width() // 2, y - img.get_height() - bob + 2))
        elif A.exists(f"npc_world/customer_{c['ti']}"):
            img = self.walk_frame(c, f"customer_{c['ti']}", 92) or A.image(f"npc_world/customer_{c['ti']}", height=92)
            bob = abs(math.sin(self.t * 9 + c["seed"])) * (1 if c.get("_wf") else 3) if c.get("moving") else 0
            if "shadow" in A._cache:
                surf.blit(A._cache["shadow"], (x - 15, y - 6))
            surf.blit(img, (x - img.get_width() // 2, y - img.get_height() - bob))
        else:
            A.missing.add(f"npc_world/customer_{c['ti']}")
            s = 1.0
            ph = self.t * 9 + c["seed"]
            bob = abs(math.sin(ph)) * 3 if c.get("moving") else 0
            sw = math.sin(ph) * 3 if c.get("moving") else 0
            pg.draw.ellipse(surf, (0, 0, 0, 60), (x - 14, y - 5, 28, 9))
            pg.draw.rect(surf, (60, 44, 58), (x - 8 + sw, y - 20, 6, 20))
            pg.draw.rect(surf, (60, 44, 58), (x + 2 - sw, y - 20, 6, 20))
            yy = y - bob
            pg.draw.polygon(surf, c["col"], [(x - 16, yy - 18), (x - 12, yy - 50), (x + 12, yy - 50), (x + 16, yy - 18)])
            pg.draw.circle(surf, (120, 80, 60), (x, yy - 66), 17)
            pg.draw.circle(surf, (255, 222, 196), (x, yy - 63), 15)
            pg.draw.circle(surf, (50, 36, 44), (x - 5, yy - 62), 2)
            pg.draw.circle(surf, (50, 36, 44), (x + 5, yy - 62), 2)
            hat = c["hat"]
            if hat == "cap":
                pg.draw.ellipse(surf, (220, 90, 90), (x - 16, yy - 84, 32, 18))
            elif hat == "bonnet":
                pg.draw.ellipse(surf, (255, 236, 244), (x - 22, yy - 82, 44, 16))
            elif hat == "hood":
                pg.draw.arc(surf, (90, 80, 170), (x - 19, yy - 84, 38, 40), 0.2, 2.9, 5)
            elif hat == "ears":
                pg.draw.polygon(surf, (40, 30, 40), [(x - 14, yy - 74), (x - 10, yy - 92), (x - 2, yy - 78)])
                pg.draw.polygon(surf, (40, 30, 40), [(x + 14, yy - 74), (x + 10, yy - 92), (x + 2, yy - 78)])
            elif hat == "straw":
                pg.draw.ellipse(surf, (236, 206, 120), (x - 26, yy - 82, 52, 14))
            elif hat == "band":
                pg.draw.rect(surf, (210, 70, 60), (x - 15, yy - 76, 30, 5))
        if c.get("bubble") and c.get("bubble_t", 0) > 0:
            self.bubble(surf, (x, y - 118), c["bubble"])

    def bubble(self, surf, pos, text):
        x, y = pos
        if text == "♥":
            pg.draw.circle(surf, (255, 255, 255), (x, y), 16)
            U.heart(surf, (x, y + 2), 9)
            return
        f = A.font(16, True)
        t = f.render(text if text != "💧" else "…?", True, U.INK)
        r = pg.Rect(0, 0, t.get_width() + 18, 28)
        r.center = (x, y)
        pg.draw.rect(surf, (255, 255, 255), r, border_radius=12)
        pg.draw.polygon(surf, (255, 255, 255), [(x - 5, r.bottom - 1), (x + 5, r.bottom - 1), (x, r.bottom + 7)])
        surf.blit(t, (r.x + 9, r.y + 3))

    def draw_lira(self, surf, cam):
        frame = int(self.t * 8) % 4 if self.moving else 0
        img = A.image(f"lira/{self.face}_{frame}", height=100)
        pos = self.p - cam
        pg.draw.ellipse(surf, (0, 0, 0, 70), (pos.x - 20, pos.y - 6, 40, 12))
        surf.blit(img, (pos.x - img.get_width() / 2, pos.y - img.get_height() + 4))

    def draw_luna(self, surf, cam):
        prev = getattr(self, "_luna_prev", V(self.luna))
        dv = self.luna - prev
        self._luna_prev = V(self.luna)
        lm = dv.length() > 0.4
        if A.has_walk("luna"):
            if lm:
                self._luna_dir = ("right" if dv.x > 0 else "left") if abs(dv.x) > abs(dv.y) else ("down" if dv.y > 0 else "up")
                img = A.walk("luna", self._luna_dir, (0, 1, 2, 1)[int(self.t * 8) % 4])
            else:
                # 멈추면 리라 쪽을 바라봐요
                img = A.walk("luna", "right" if self.p.x > self.luna.x else "left", 1)
        else:
            img = A.image_or("npc_world/luna", "props/luna_sprite", 50)
            if self.luna.x > self.p.x:
                img = pg.transform.flip(img, True, False)
        pos = self.luna - cam
        # 가까운 상호작용 대상과 겹치면 반투명
        o = self.nearest() if self.menu is None else None
        if o and V(o["pos"]).distance_to(self.luna) < 60:
            img = img.copy()
            img.set_alpha(120)
        surf.blit(img, (pos.x - img.get_width() / 2, pos.y - img.get_height() + 4))
        if not self.s.luna_petted and self.menu is None and self.luna.distance_to(self.p) < 160:
            U.keycap(surf, (pos.x, pos.y - 66 + math.sin(self.t * 4) * 2), "H", 11)

    def render_world(self, surf):
        mp = self.maps[self.scene]
        if self.scene != "outdoor":
            self.cam = V(0, 0)
        cam = self.cam
        mp.draw_ground(surf, self, cam)
        if hasattr(mp, "draw_wall_items"):
            mp.draw_wall_items(surf, self)
        items = []
        for y, img, (x, yy) in mp.drawables(self):
            items.append((y, lambda img=img, x=x, yy=yy: surf.blit(img, (x - cam.x, yy - cam.y))))
        items.append((self.p.y, lambda: self.draw_lira(surf, cam)))
        items.append((self.luna.y, lambda: self.draw_luna(surf, cam)))
        for c in self.customers:
            items.append((c["pos"].y, lambda c=c: self.draw_person(surf, c, cam)))
        if self.scene == "outdoor":
            for v in self.villagers:
                items.append((v["pos"].y, lambda v=v: self.draw_person(surf, v, cam)))
            for c in getattr(self, "critters", []):
                if -60 < c["p"].x - cam.x < W + 60 and -60 < c["p"].y - cam.y < H + 60:
                    items.append((c["p"].y if c["k"] != "duck" else 0, lambda c=c: self.draw_critter(surf, c, cam)))
            self.draw_ambient(surf, cam, "under")
            for k, pos in self.npcs_here():
                fake = dict(kind="npc", npc=k, pos=pos, seed=0) if k in D.NPCS else None
                if fake:
                    items.append((pos.y, lambda f=fake: self.draw_person(surf, f, cam)))
                else:
                    img = A.image_or(f"npc_world/{k}", f"portraits/{k}", 96)
                    items.append((pos.y, lambda img=img, pos=pos: surf.blit(img, (pos.x - cam.x - img.get_width() // 2, pos.y - cam.y - img.get_height()))))
            if self.s.noel_here():
                img = A.image_or("npc_world/noel", "portraits/noel", 100)
                nx, ny = self.maps["outdoor"].NOEL
                items.append((ny, lambda img=img: surf.blit(img, (nx - cam.x - img.get_width() // 2, ny - cam.y - img.get_height()))))
            for sl in self.slimes:
                if sl["hp"] > 0:
                    items.append((sl["p"].y, lambda sl=sl: self.draw_slime(surf, sl, cam)))
        items.sort(key=lambda i: i[0])
        for _, fn in items:
            fn()
        for sh in self.shots:   # 마법 탄: 루나 레벨에 따라 4단계로 진화 (별 → 푸른 별 → 쌍둥이 금별 → 보름달)
            p = sh["p"] - cam
            tier = sh.get("tier", 0)
            col = D.MAGIC_TIERS[tier][3]
            size = (34, 42, 40, 64)[tier]
            key = ("shotfx", tier, int(self.t * 20) % 12)
            if key not in A._cache:
                st = U.tint(pg.transform.smoothscale(A.raw("fx/star_06"), (size, size)), col)
                A._cache[key] = pg.transform.rotate(st, key[2] * 30)
            img = A._cache[key]
            dirv = sh["v"].normalize() if sh["v"].length() else V(1, 0)
            side = V(-dirv.y, dirv.x)
            offs = [side * 9, side * -9] if tier == 2 else [V()]
            for off in offs:
                for k in range(1, 4 + tier):
                    tp = p + off - dirv * k * 12
                    pg.draw.circle(surf, col, tp, max(1, 6 + tier - k))
                surf.blit(img, (p.x + off.x - img.get_width() / 2, p.y + off.y - img.get_height() / 2))
                pg.draw.circle(surf, (255, 255, 255), p + off, 4 + (3 if tier == 3 else 0))
            if tier == 3:   # 보름달: 은은한 빛무리
                glow = pg.Surface((60, 60), pg.SRCALPHA)
                pg.draw.circle(glow, (255, 250, 210, 70), (30, 30), 28)
                surf.blit(glow, (p.x - 30, p.y - 30))
        self.draw_ambient(surf, cam, "over")
        if self.scene == "shop":
            mp.lamp_glow(surf, self)
        # 밤
        if self.scene in ("outdoor", "plaza"):
            h = self.s.hour
            a = 0 if h < 17.5 else min(150, int((h - 17.5) * 45))
            if self.scene == "plaza":
                a = 70
            if a:
                ov = pg.Surface((W, H), pg.SRCALPHA)
                ov.fill((20, 20, 60, a))
                surf.blit(ov, (0, 0))
            self.draw_ambient(surf, cam, "glow")
        # 배치 모드 격자
        if self.placing and self.scene == "shop":
            self.draw_placing(surf)
        # UI 층: 이름표 · 말풍선 · 떠오르는 글씨
        mp.labels(surf, self) if hasattr(mp, "labels") else None
        self.draw_markers(surf, cam)
        for p in self.particles:
            pos = p["p"] - cam
            if p["kind"] == "heart":
                U.heart(surf, (int(pos.x), int(pos.y)), 7)
            else:
                pg.draw.circle(surf, p["col"], pos, 3)
        for pos, text, t, col, ic in self.floaters:
            x, y = pos.x - cam.x, pos.y - cam.y
            if ic:
                img = U.icon("coins", 24, (200, 150, 40)) if ic == "coin" else A.item_icon(ic, 32)
                tw = A.font(16, True).size(text)[0]
                pop = 1 + max(0, t - 1.4) * 2          # 처음에 톡 튀어나오는 느낌
                if pop != 1:
                    img = pg.transform.scale(img, (int(img.get_width() * pop), int(img.get_height() * pop)))
                surf.blit(img, (x - tw // 2 - img.get_width() - 2, y - img.get_height() // 2))
            U.outlined(surf, text, (x, y), 16, col)

    def draw_slime(self, surf, sl, cam):
        if sl["kind"] == "mush":   # 버섯돌이: Fluent 버섯(픽셀) + 눈·발, 통통 뛰어다님
            pos = sl["p"] - cam
            hop = abs(math.sin(sl.get("hop", 0))) * 16
            if "shadow" in A._cache:
                surf.blit(A._cache["shadow"], (pos.x - 15, pos.y - 6))
            big = A.raw("props/mushroom_mob").get_width() > 64       # v1.1: GPT 버섯돌이 그림
            img = A.image("props/mushroom_mob", height=54) if big else A.pix("props/mushroom_mob", 2)
            if sl["hurt"] > 0:
                img = U.tint(img, (255, 255, 255))
            x, y = pos.x - img.get_width() / 2, pos.y - img.get_height() - hop
            if not big:
                for fx in (-10, 6):   # 발
                    pg.draw.rect(surf, (90, 60, 50), (pos.x + fx, pos.y - 8 - hop, 6, 6))
            surf.blit(img, (x, y))
            if sl["hp"] < D.MONSTER_HP:   # 체력 막대 (맞았을 때만)
                U.bar(surf, (pos.x - 20, y - 12, 40, 6), sl["hp"] / D.MONSTER_HP, (230, 90, 110))
            return
        size = 120 if sl["kind"] == "boss" else 48
        tint = {"wool": (255, 255, 255), "crystal": (210, 170, 255), "bee": (255, 220, 120), "boss": (180, 255, 180)}[sl["kind"]]
        name = {"wool": "props/slime_wool", "crystal": "props/slime_crystal", "bee": "props/slime_bee", "boss": "props/slime_boss"}[sl["kind"]]
        img = A.image_or(name, "props/slime", size, tint)
        pos = sl["p"] - cam
        sq = 1 + math.sin(self.t * 6 + sl["p"].x) * 0.05
        img2 = pg.transform.smoothscale(img, (int(img.get_width() * sq), int(img.get_height() / sq)))
        surf.blit(img2, (pos.x - img2.get_width() / 2, pos.y - img2.get_height()))
        if sl["kind"] == "boss":
            U.bar(surf, (pos.x - 60, pos.y - size - 20, 120, 10), sl["hp"] / D.BOSS_HP, (120, 220, 120))
        elif sl["hp"] < D.MONSTER_HP:
            U.bar(surf, (pos.x - 20, pos.y - img2.get_height() - 12, 40, 6), sl["hp"] / D.MONSTER_HP, (230, 90, 110))

    def draw_placing(self, surf):
        d = self.placing
        sm = self.maps["shop"]
        mx, my = self.mouse
        ov = pg.Surface((W, H), pg.SRCALPHA)
        if D.DECO[d][1] == "wall":
            used = {v[1] for k, v in self.s.deco_placed.items() if v[0] == "wall" and k != d}
            for i, (x, y) in enumerate(D.WALL_SLOTS):
                col = (220, 90, 90, 90) if i in used else (120, 220, 140, 110)
                pg.draw.rect(ov, col, (x - 40, y - 50, 80, 100), border_radius=10)
        else:
            c = sm.DECO_CELL
            for x in range(sm.FLOOR_AREA.left, sm.FLOOR_AREA.right, c):
                for y in range(sm.FLOOR_AREA.top, sm.FLOOR_AREA.bottom, c):
                    cell = self.snap((x + 1, y + 1))
                    ok = sm.deco_valid(self, cell, ignore=d)
                    pg.draw.rect(ov, (120, 220, 140, 45) if ok else (220, 90, 90, 25), (cell[0] - 30, cell[1] - 52, 60, 60), 0, 6)
            cell = self.snap((mx, my))
            ok = sm.deco_valid(self, cell, ignore=d)
            pg.draw.rect(ov, (120, 240, 150, 150) if ok else (240, 90, 90, 150), (cell[0] - 30, cell[1] - 52, 60, 60), 3, 6)
            img = A.image(D.DECO[d][5], height=70).copy()
            img.set_alpha(160)
            ov.blit(img, (cell[0] - img.get_width() // 2, cell[1] - img.get_height()))
        surf.blit(ov, (0, 0))
        U.pill(surf, (W // 2 - 260, 150, 520, 30), f"{D.DECO[d][0]} 배치 중 · 초록 칸을 클릭 · Esc 취소", bg=(70, 52, 92), size=15)

    # ═══════════════════ 마을 생활 · 분위기 ═══════════════════
    ROUTES = [
        [(380, 740), (900, 730), (1480, 730), (1720, 730), (1480, 730), (900, 730)],
        [(560, 580), (1020, 580), (1020, 730), (560, 730)],
        [(380, 520), (380, 740), (1200, 740), (1200, 1000), (1200, 740)],
        [(1400, 730), (700, 730), (700, 1000), (700, 730)],
    ]
    VILLAGER_LINES = ["좋은 아침이에요!", "마녀님 가게 열었어요?", "오늘 날씨 좋다~", "고양이다!", "장터 언제 열려요?",
                      "물약 향이 좋네요", "강가에 물고기 많대요", "숲엔 슬라임 조심!", "흥얼흥얼~", "어머, 루나 안녕"]

    def watch_stats(self):
        s = self.s
        lv = s.level
        if self.last_level is not None and lv > self.last_level:
            self.sfx("levelup")
            self.toast(f"레벨 업! Lv.{lv} · 최대 기력 +1", 4.5)
            self.sparkle(self.p + V(0, -60), (200, 170, 255), 22)
        self.last_level = lv
        if self.last_gold is not None and s.gold > self.last_gold:
            self.sfx("coin", 0.12)
        self.last_gold = s.gold

    def update_ambient(self, dt):
        s = self.s
        # 바깥 주민 (8~20시)
        want = 0
        if self.scene == "outdoor" and 8 <= s.hour < 20:
            want = 3 + min(3, s.chapter // 2)
        while len(self.villagers) < want:
            ti = self.rng.randrange(len(D.CUSTOMER_TYPES))
            _, _, _, _, col, hat = D.CUSTOMER_TYPES[ti]
            route = self.rng.choice(self.ROUTES)
            k = self.rng.randrange(len(route))
            jit = V(self.rng.uniform(-18, 18), self.rng.uniform(-14, 14))
            self.villagers.append(dict(kind="gen", ti=ti, col=col, hat=hat, route=route, k=k, jit=jit,
                                       pos=V(route[k]) + jit, seed=self.rng.random() * 9, moving=True,
                                       speed=self.rng.uniform(55, 85), pause=0, bubble=None, bubble_t=0, talk_cd=0))
        if len(self.villagers) > want:
            self.villagers = self.villagers[:want]
        for v in self.villagers:
            v["bubble_t"] -= dt
            v["talk_cd"] -= dt
            if v["pause"] > 0:
                v["pause"] -= dt
                v["moving"] = False
            else:
                tgt = V(v["route"][(v["k"] + 1) % len(v["route"])]) + v["jit"]
                d = tgt - v["pos"]
                if d.length() < 4:
                    v["k"] = (v["k"] + 1) % len(v["route"])
                    if self.rng.random() < 0.35:
                        v["pause"] = self.rng.uniform(1.5, 4)
                else:
                    v["pos"] += d.normalize() * min(d.length(), v["speed"] * dt)
                    v["moving"] = True
            if v["talk_cd"] <= 0 and self.p.distance_to(v["pos"]) < 110:
                v["bubble"] = self.rng.choice(self.VILLAGER_LINES)
                v["bubble_t"] = 2.6
                v["talk_cd"] = 14
                v["pause"] = max(v["pause"], 1.8)
        self.update_critters(dt)
        # 새 · 나비 · 반딧불 · 굴뚝 연기
        self.bird_t -= dt
        amb = self.ambient
        if self.scene == "outdoor":
            cx, cy = self.cam
            night = s.hour >= 18.5
            if not night and sum(1 for a in amb if a["k"] == "fly") < 7 and self.rng.random() < dt * 2:
                bx, by = self.rng.choice([(840, 420), (300, 600), (1100, 400), (1250, 1000), (700, 1000)])
                amb.append(dict(k="fly", p=V(bx + self.rng.uniform(-150, 150), by + self.rng.uniform(-90, 90)),
                                ph=self.rng.uniform(0, 6), t=self.rng.uniform(8, 14), col=self.rng.choice([(255, 236, 140), (250, 190, 220), (200, 220, 255)])))
            if night and sum(1 for a in amb if a["k"] == "bug") < 26 and self.rng.random() < dt * 8:
                amb.append(dict(k="bug", p=V(cx + self.rng.uniform(0, W), cy + self.rng.uniform(60, H)),
                                ph=self.rng.uniform(0, 6), t=self.rng.uniform(5, 9)))
            if not night and self.bird_t <= 0:
                self.bird_t = self.rng.uniform(9, 18)
                y = cy + self.rng.uniform(80, H - 200)
                for i in range(self.rng.randint(2, 4)):
                    amb.append(dict(k="bird", p=V(cx - 40 - i * 34, y + i * 18 * self.rng.choice((-1, 1))), ph=i, t=14))
            if self.rng.random() < dt * 2.2:
                amb.append(dict(k="smoke", p=V(452 + self.rng.uniform(-4, 4), 214), ph=0, t=3.2))
        for a in amb:
            a["t"] -= dt
            a["ph"] += dt
            if a["k"] == "fly":
                a["p"] += V(math.cos(a["ph"] * 1.3) * 40, math.sin(a["ph"] * 2.1) * 30) * dt
            elif a["k"] == "bug":
                a["p"] += V(math.sin(a["ph"] * 0.9) * 18, math.cos(a["ph"] * 1.1) * 14 - 4) * dt
            elif a["k"] == "bird":
                a["p"] += V(170, math.sin(a["ph"] * 3) * 12) * dt
            elif a["k"] == "smoke":
                a["p"] += V(10 + math.sin(a["ph"] * 2) * 8, -26) * dt
        self.ambient = [a for a in amb if a["t"] > 0]

    def update_critters(self, dt):
        """바깥 동물: 강의 오리(다리 위·아래 물길에서만), 숲 달팽이·고슴도치 (Fluent Emoji 픽셀).
        v0.8: 상호작용 없는 토끼·닭은 뺐어요."""
        if self.scene != "outdoor":
            return
        if not hasattr(self, "critters"):
            r = random.Random(4)
            cs = []
            # (위쪽 물길 60~620, 아래쪽 물길 840~1440) — 다리(690~770)는 건너지 않아요
            for lo, hi in ((60, 620), (60, 620), (840, 1440), (840, 1440)):
                cs.append(dict(k="duck", p=V(r.uniform(1535, 1625), r.uniform(lo, hi)), lo=lo, hi=hi, dir=r.choice((-1, 1)), t=r.uniform(0, 5)))
            cs.append(dict(k="snail", p=V(1900, 520), t=0))
            cs.append(dict(k="hedgehog", p=V(2150, 1180), t=0))
            for c in cs:
                c.update(tgt=V(c["p"]), left=False, hop=0.0, home=V(c["p"]))
            self.critters = cs
        for c in self.critters:
            c["t"] -= dt
            k = c["k"]
            if k == "duck":
                c["p"].y += 16 * c["dir"] * dt
                c["p"].x = c["home"].x + math.sin(self.t * 0.6 + c["home"].y) * 14
                if c["p"].y > c["hi"] or c["p"].y < c["lo"] or (c["t"] <= 0 and self.rng.random() < 0.02):
                    c["dir"] *= -1
                    c["p"].y = max(c["lo"], min(c["hi"], c["p"].y))
                    c["t"] = 6
                continue
            if c["t"] <= 0:
                c["t"] = self.rng.uniform(1.5, 4)
                spread = {"snail": 40, "hedgehog": 90}[k]
                c["tgt"] = c["home"] + V(self.rng.uniform(-spread, spread), self.rng.uniform(-spread / 2, spread / 2))
            speed = {"snail": 6, "hedgehog": 30}[k]
            d = c["tgt"] - c["p"]
            if d.length() > 2:
                c["left"] = d.x < 0
                c["p"] += d.normalize() * min(d.length(), speed * dt)
                c["hop"] += dt * 8
            else:
                c["hop"] = 0

    def draw_critter(self, surf, c, cam):
        img = A.decor(c["k"])
        if c.get("left"):
            img = pg.transform.flip(img, True, False)
        pos = c["p"] - cam
        hop = abs(math.sin(c["hop"])) * 2
        if c["k"] == "duck":
            hop = math.sin(self.t * 2 + c["home"].y) * 2
            if c.get("dir", 1) < 0:      # 위로 헤엄칠 땐 반대로 봄
                img = pg.transform.flip(img, True, False)
        elif "shadow" in A._cache:
            surf.blit(A._cache["shadow"], (pos.x - 15, pos.y - 6))
        surf.blit(img, (pos.x - img.get_width() / 2, pos.y - img.get_height() - hop))

    def draw_ambient(self, surf, cam, layer):
        if self.scene != "outdoor":
            return
        for a in self.ambient:
            p = a["p"] - cam
            if not (-40 < p.x < W + 40 and -40 < p.y < H + 40):
                continue
            k = a["k"]
            if layer == "under" and k == "smoke":
                life = a["t"] / 3.2
                img = A.raw("fx/smoke_01")
                sz = int(18 + (1 - life) * 40)
                im = pg.transform.smoothscale(img, (sz, sz))
                im = U.tint(im, (236, 230, 240))
                im.set_alpha(int(150 * life))
                surf.blit(im, (p.x - sz // 2, p.y - sz // 2))
            elif layer == "over" and k == "fly":
                flap = abs(math.sin(a["ph"] * 14))
                w = 2 + int(5 * flap)
                pg.draw.ellipse(surf, a["col"], (p.x - w - 1, p.y - 4, w, 7))
                pg.draw.ellipse(surf, a["col"], (p.x + 1, p.y - 4, w, 7))
                pg.draw.line(surf, (70, 50, 50), (p.x, p.y - 3), (p.x, p.y + 3), 1)
            elif layer == "over" and k == "bird":
                y = p.y + math.sin(a["ph"] * 10) * 2
                wing = 5 if int(a["ph"] * 6) % 2 else -3
                pg.draw.lines(surf, (60, 50, 70), False, [(p.x - 8, y + wing), (p.x, y), (p.x + 8, y + wing)], 2)
                sh = pg.Surface((14, 5), pg.SRCALPHA)
                pg.draw.ellipse(sh, (0, 0, 0, 40), sh.get_rect())
                surf.blit(sh, (p.x - 7, p.y + 120))
            elif layer == "glow" and k == "bug":
                a_ = (math.sin(a["ph"] * 3) + 1) / 2 * min(1, a["t"])
                img = A.raw("fx/light_01")
                sz = 26
                im = pg.transform.smoothscale(img, (sz, sz))
                im = U.tint(im, (255, 250, 150))
                im.set_alpha(int(200 * a_))
                surf.blit(im, (p.x - sz // 2, p.y - sz // 2), special_flags=0)
                pg.draw.circle(surf, (255, 255, 200), p, 2)

    def npc_marker(self, k):
        """머리 위 표시: '!' 새 부탁 · '✓' 부탁 완료 가능 · '♥' 오늘 아직 대화 안 함."""
        s = self.s
        if k not in s.npc or k not in D.NPCS:
            return None
        if k in D.QUESTS and s.quest_ready(k):
            return "done"
        if s.quest_available(k):
            return "quest"
        if s.npc[k]["talked"] != s.day:
            return "talk"
        return None

    def draw_markers(self, surf, cam):
        s = self.s
        bob = math.sin(self.t * 4) * 3
        pts = []
        for k, pos in self.npcs_here():
            mk = self.npc_marker(k)
            if mk:
                pts.append((pos, mk))
        if self.scene == "outdoor":
            # 우편함: 새 편지 · 소포 준비 표시
            mbx, mby = self.maps["outdoor"].MAILBOX
            if s.unread_mail() or any(s.parcel_ready(i) for i in range(len(s.parcels))):
                r = pg.Rect(0, 0, 26, 26)
                r.center = (mbx - cam.x, mby - cam.y - 78 + bob)
                U.tag(surf, r, fill=(255, 226, 120), edge=U.INK, inner=False)
                t = A.font(15, True).render("!", False, U.INK)
                surf.blit(t, (r.centerx - t.get_width() // 2, r.centery - t.get_height() // 2))
            # 채집 자리 반짝임
            for gs in getattr(self, "gather", []):
                if self.day_flags.get(f"gather{gs['i']}"):
                    continue
                ph = self.t * 2.4 + gs["i"] * 1.7
                if math.sin(ph) > 0.2:
                    sp = A.pix("decor/sparkle", 2)
                    sp = sp.copy()
                    sp.set_alpha(int(255 * (math.sin(ph) - 0.2) / 0.8))
                    surf.blit(sp, (gs["pos"][0] - cam.x + 8, gs["pos"][1] - cam.y - 58))
        for pos, mk in pts:
            x, y = pos.x - cam.x, pos.y - cam.y - 122 + bob
            r = pg.Rect(0, 0, 26, 26)
            r.center = (x, y)
            if mk == "talk":
                r.inflate_ip(6, 6)
                U.tag(surf, r, fill=(255, 244, 248), edge=(150, 80, 110), inner=False)
                U.heart(surf, (r.centerx, r.centery + 1), 8)
            else:
                U.tag(surf, r, fill=(255, 226, 120) if mk == "quest" else (170, 226, 160), edge=U.INK, inner=False)
                t = A.font(15, True).render("!" if mk == "quest" else "✓", False, U.INK)
                surf.blit(t, (r.centerx - t.get_width() // 2, r.centery - t.get_height() // 2))
        # E 표시 (가까운 대상 위)
        if self.menu is None and not self.placing:
            o = self.nearest()
            if o:
                p = V(o["pos"]) - cam
                up = 132 if o["kind"] == "npc" else (78 if o["kind"] == "luna" else 70)
                if o["kind"] == "npc" and self.npc_marker(o["id"][4:]):
                    up += 34
                f = A.font(15, True)
                t = f.render(o["label"], False, U.INK)
                w = t.get_width() + 46
                x = max(8, min(W - w - 8, p.x - w // 2))
                y = max(96, min(H - 130, p.y - up + bob * 0.5))
                r = pg.Rect(x, y, w, 32)
                U.tag(surf, r, inner=False)
                cap = pg.Rect(r.x + 6, r.y + 5, 22, 22)
                pg.draw.rect(surf, (120, 100, 90), cap.move(0, 2))
                pg.draw.rect(surf, U.LAV, cap)
                pg.draw.rect(surf, U.INK, cap, 1)
                e = A.font(13, True).render("E", False, U.CREAM)
                surf.blit(e, (cap.centerx - e.get_width() // 2, cap.y + 4))
                surf.blit(t, (r.x + 36, r.centery - t.get_height() // 2))
                pg.draw.polygon(surf, (120, 96, 78), [(p.x - 6, r.bottom), (p.x + 6, r.bottom), (p.x, r.bottom + 7)]) if r.x < p.x < r.right else None

    # ═══════════════════ HUD ═══════════════════
    QUICK = [("bag", "I", "가방"), ("scroll", "J", "장 목표"), ("letter", "R", "인물 목록"),
             ("plant", "B", "꾸미기"), ("help", "F1", "도움말"), ("cog", "Esc", "메뉴")]

    def quick_rects(self):
        n = len(self.QUICK)
        size, gap = 64, 10
        x0 = W - 18 - n * size - (n - 1) * gap
        return [pg.Rect(x0 + i * (size + gap), H - 96, size, size) for i in range(n)]

    def quick_hit(self, pos):
        return self.mode == "play" and any(r.collidepoint(pos) for r in self.quick_rects())

    def quick_action(self, i):
        key = [pg.K_i, pg.K_j, pg.K_r, pg.K_b, pg.K_F1, pg.K_ESCAPE][i]
        self.key(key)

    def quick_dot(self, i):
        s = self.s
        if i == 1:
            ch = s.chapter
            return any(c in D.GOALS and s.goals_done(c) and c not in s.goals_claimed for c in range(1, ch + 1))
        if i == 2:
            return any(k in D.QUESTS and (s.quest_ready(k) or s.quest_available(k)) for k in s.met_npcs())
        if i == 3:
            return any(d not in s.deco_placed for d in s.deco_owned)
        return False

    def click_hud(self, pos):
        if self.mode != "play" or self.menu:
            return False
        for i, r in enumerate(self.quick_rects()):
            if r.collidepoint(pos):
                self.sfx("click")
                self.quick_action(i)
                return True
        if pg.Rect(14, 118, 300, 36).collidepoint(pos):
            self.tracker_open = not self.tracker_open
            self.sfx("page")
            return True
        return False

    def dial_frame(self):
        h = self.s.hour
        if self.scene == "plaza" or h >= 18.5 or h < 6:
            name = "night"
        elif h < 10:
            name = "dawn"
        elif h < 15:
            name = "day"
        else:
            name = "noon"
        key = ("dial", name, int(self.t * 5) % 10)
        if key not in A._cache:
            img = A.raw(f"ui/paper/dial_{name}_{key[2] + 1}")
            br = img.get_bounding_rect()
            img = img.subsurface(br).copy()
            A._cache[key] = pg.transform.scale(img, (img.get_width() * 2, img.get_height() * 2))
        return A._cache[key]

    def tracker_lines(self):
        s = self.s
        out = []
        ch = s.chapter
        nxt = next((c for c in D.CHAPTERS if c[0] == ch + 1), None)
        for desc, key, n in D.GOALS.get(ch, [])[:3]:
            v = min(n, s.goal_value(key))
            out.append((v >= n, desc, f"{v}/{n}"))
        # 지금 할 일 한 줄
        h = s.hour
        if self.scene == "plaza":
            tip = "부스(E)에서 진열을 바꾸고 손님을 맞아요"
        elif h >= 20:
            tip = "침대(E)에서 하루를 마쳐요"
        elif s.unread_mail() and not self.shop_open:
            tip = "저택 앞 우편함에 편지가 왔어요!"
        elif s.chapter >= 2 and not s.flags.get("bram_met") and 8 <= h < 19:
            tip = "마을 길가에 공방 수레가 생겼대요 (브람)"
        elif not any(s.shelf_count(i) for i in range(6) if s.shelves[i]):
            tip = "솥 앞에서 [사용]으로 만들고 진열대를 채워요" if self.touch.enabled else "솥(E)에서 만들고 진열대를 채워요"
        elif h < D.SHOP_OPEN:
            tip = "9시부터 [영업] 버튼으로 가게를 열어요" if self.touch.enabled else "9시부터 O 키로 가게를 열어요"
        elif not self.shop_open and h < D.SHOP_CLOSE:
            tip = "[영업] 버튼으로 가게를 열어요" if self.touch.enabled else "O 키로 가게를 열어요"
        elif self.shop_open:
            tip = "영업 중! 텃밭·강가·숲에 다녀와도 돼요"
        else:
            tip = "단골과 이야기하거나 하루를 마쳐요"
        return nxt, out, tip

    def draw_hud(self, surf):
        s = self.s
        from state import xp_threshold
        # ── 왼쪽 위: 하늘 창(시간) + 날짜 딱지
        dial = self.dial_frame()
        dx, dy = 12, 10
        surf.blit(dial, (dx, dy))
        r = pg.Rect(dx + dial.get_width() + 6, 14, 250, 84)
        U.tag(surf, r)
        ch = D.CHAPTERS[s.chapter - 1]
        U.text(surf, f"{ch[0]}장 · {ch[1]}", (r.x + 14, r.y + 10), 15, U.LAV_DARK, True)
        U.text(surf, f"{s.day}일째", (r.x + 14, r.y + 34), 24, U.INK, True)
        U.text(surf, self.hhmm(), (r.x + 108, r.y + 38), 20, U.INK_SOFT)
        # OPEN 도장
        st = pg.Rect(r.right - 70, r.y + 42, 60, 26)
        open_ = self.shop_open
        pg.draw.rect(surf, (70, 140, 90) if open_ else (150, 90, 100), st, 2)
        pg.draw.rect(surf, (70, 140, 90) if open_ else (150, 90, 100), st.inflate(-6, -6), 1)
        t = A.font(12, True).render("OPEN" if open_ else "CLOSED", False, (70, 140, 90) if open_ else (150, 90, 100))
        surf.blit(t, (st.centerx - t.get_width() // 2, st.centery - t.get_height() // 2))
        # ── 오른쪽 위: 돈 · 레벨 · 기력 · 누적
        R_ = pg.Rect(W - 342, 14, 328, 112)
        U.tag(surf, R_)
        surf.blit(U.icon("coins", 24, (190, 140, 40)), (R_.x + 14, R_.y + 14))
        U.text(surf, f"{s.gold:,}원", (R_.x + 46, R_.y + 12), 24, U.INK, True)
        lv = s.level
        lo, hi = xp_threshold(lv), xp_threshold(lv + 1)
        pg.draw.rect(surf, U.LAV, (R_.right - 86, R_.y + 12, 72, 26))
        pg.draw.rect(surf, U.INK, (R_.right - 86, R_.y + 12, 72, 26), 1)
        t = A.font(15, True).render(f"Lv.{lv}", False, U.CREAM)
        surf.blit(t, (R_.right - 50 - t.get_width() // 2, R_.y + 16))
        pg.draw.rect(surf, (200, 184, 230), (R_.right - 86, R_.y + 40, 72, 4))
        pg.draw.rect(surf, U.LAV_DARK, (R_.right - 86, R_.y + 40, int(72 * ((s.xp - lo) / max(1, hi - lo) if lv < 10 else 1)), 4))
        # 기력
        surf.blit(U.icon("heart", 24, (200, 70, 90)), (R_.x + 12, R_.y + 49))
        U.paper_bar(surf, (R_.x + 42, R_.y + 50, 170, 22), s.energy / max(1, s.max_energy), "red")
        U.text(surf, f"기력 {s.energy}/{s.max_energy}", (R_.x + 222, R_.y + 53), 13, U.INK, True)
        if self.scene == "outdoor" and self.p.x > self.maps["outdoor"].FOREST_X - 40:     # v1.0 마력 칸
            mr = pg.Rect(R_.x, R_.bottom + 6, 328, 30)
            U.tag(surf, mr, inner=False)
            boss = self.boss_near()
            U.text(surf, "거대 슬라임 앞: 1발 = 기력 1" if boss else "마력", (mr.x + 12, mr.y + 8), 13, U.LAV_DARK, True)
            if not boss:
                for k in range(D.MANA_PER_ENERGY):
                    on = k < s.mana
                    c = (mr.x + 70 + k * 24, mr.centery)
                    if U.A.exists("icons/ui_mana"):          # v1.2 마력 구슬 일러스트
                        ic = U.icon("mana", 22, None if on else (190, 180, 170))
                        surf.blit(ic, (c[0] - 11, c[1] - 11))
                        continue
                    pg.draw.circle(surf, (150, 110, 230) if on else (205, 195, 215), c, 7)
                    pg.draw.circle(surf, U.INK, c, 7, 1)
                U.text(surf, "다 쓰면 기력 1로 다시 채워요", (mr.x + 146, mr.y + 9), 11, U.INK_SOFT)
        # 누적 매출
        surf.blit(U.icon("fame", 24, (190, 140, 40)), (R_.x + 12, R_.y + 77))
        U.paper_bar(surf, (R_.x + 42, R_.y + 78, 170, 22), s.total_revenue / D.GOAL_REVENUE, "orange")
        U.text(surf, f"{s.total_revenue / 10000:,.1f}/{D.GOAL_REVENUE // 10000}만", (R_.x + 222, R_.y + 81), 13, U.INK, True)
        if self.scene == "plaza" and self.market:
            self.draw_ranking(surf)
        else:
            self.draw_tracker(surf)
        self.draw_quickbar(surf)
        # 알림 (종이 딱지)
        y = 16
        for text, t_ in self.messages:
            f = A.font(15, True)
            tt = f.render(text, False, U.INK)
            rr = pg.Rect(W // 2 - tt.get_width() // 2 - 20, y, tt.get_width() + 40, 34)
            if rr.x < 300:
                rr.x = 300
            slide = min(1, (3.6 - t_) * 6) if t_ > 3.4 else 1
            rr.y = int(y - (1 - slide) * 20)
            U.tag(surf, rr, fill=(252, 244, 226), inner=False)
            pg.draw.rect(surf, U.LAV, (rr.x + 6, rr.y + 6, 4, rr.h - 12))
            surf.blit(tt, (rr.x + 20, rr.centery - tt.get_height() // 2))
            y += 40
        if getattr(self, "fast", False) and self.menu is None:
            rr = pg.Rect(W // 2 - 70, H - 150, 140, 34)
            U.tag(surf, rr, fill=(255, 236, 170), inner=False)
            U.text(surf, "▶▶ 4배속" + ("" if self.touch.enabled else " (Z)"), (rr.centerx, rr.y + 8), 15, U.INK, True, center=True)
        if self.hint_t > 0 or self.show_help:
            txt = "WASD 이동 · Shift 달리기 · E 사용/대화 · H 루나 · Space 마법 · O 영업 · Z 꾹 = 빨리 감기"
            if self.touch.enabled:
                txt = None
            if txt:
                tt = A.font(13).render(txt, False, U.INK)
                rr = pg.Rect(18, H - 50, tt.get_width() + 28, 30)
                U.tag(surf, rr, inner=False)
                surf.blit(tt, (rr.x + 14, rr.centery - tt.get_height() // 2))

    def draw_tracker(self, surf):
        nxt, goals, tip = self.tracker_lines()
        head = pg.Rect(14, 118, 300, 36)
        hover = head.collidepoint(self.mouse) and self.menu is None
        if not self.tracker_open:
            U.tag(surf, head, fill=(248, 236, 212) if hover else U.PAPER, inner=False)
            surf.blit(U.icon("scroll", 24, U.LAV_DARK), (head.x + 8, head.y + 6))
            U.text(surf, "목표 펼치기", (head.x + 38, head.y + 10), 13, U.INK, True)
            U.keycap(surf, (head.right - 22, head.y + 8), "T", 11)
            return
        h = 48 + (44 if nxt else 0) + 24 * len(goals) + 36
        r = pg.Rect(14, 118, 300, h)
        # 리라가 목표판 뒤에 있으면 반투명하게
        lp = self.p - self.cam
        behind = r.inflate(40, 60).collidepoint(lp.x, lp.y - 40) and not r.collidepoint(self.mouse)
        self.tracker_alpha = max(0.35, getattr(self, "tracker_alpha", 1) - self.dt_last * 4) if behind else min(1, getattr(self, "tracker_alpha", 1) + self.dt_last * 4)
        real, surf = surf, pg.Surface((W, H), pg.SRCALPHA) if self.tracker_alpha < 1 else surf
        U.tag(surf, r)
        surf.blit(U.icon("scroll", 24, U.LAV_DARK), (r.x + 10, r.y + 8))
        U.text(surf, "오늘의 목표", (r.x + 40, r.y + 12), 15, U.LAV_DARK, True)
        U.keycap(surf, (r.right - 24, r.y + 10), "T", 11)
        y = r.y + 42
        if nxt:
            U.text(surf, f"다음 장까지 {self.s.total_revenue / 10000:,.1f} / {nxt[2] / 10000:,.0f}만 원", (r.x + 16, y), 13, U.INK)
            U.paper_bar(surf, (r.x + 16, y + 18, r.w - 32, 18), self.s.total_revenue / nxt[2], "orange")
            y += 44
        for done, desc, prog in goals:
            col = (70, 130, 80) if done else U.INK
            box = pg.Rect(r.x + 16, y + 3, 12, 12)
            pg.draw.rect(surf, col, box, 2)
            if done:
                pg.draw.lines(surf, col, False, [(box.x + 2, box.y + 6), (box.x + 5, box.y + 9), (box.x + 11, box.y + 1)], 2)
            dtext = desc if A.font(13).size(desc)[0] < r.w - 100 else desc[:15] + "…"
            U.text(surf, dtext, (r.x + 36, y), 13, col)
            U.text(surf, prog, (r.right - 16, y), 13, U.INK_SOFT, right=True)
            y += 24
        pg.draw.line(surf, U.LINE, (r.x + 14, y + 2), (r.right - 14, y + 2), 2)
        U.text(surf, "→ " + tip, (r.x + 16, y + 10), 13, U.LAV_DARK, True)
        if surf is not real:
            surf.set_alpha(int(255 * self.tracker_alpha))
            real.blit(surf, (0, 0))

    def draw_quickbar(self, surf):
        rects = self.quick_rects()
        back = pg.Rect(rects[0].x - 12, rects[0].y - 10, rects[-1].right - rects[0].x + 24, 100)
        U.tag(surf, back, inner=False)
        for i, (r, (ic, key, name)) in enumerate(zip(rects, self.QUICK)):
            hover = r.collidepoint(self.mouse) and self.menu is None
            dis = i == 3 and self.scene != "shop"
            U.slot(surf, r, hover)
            img = U.icon(ic, 48, (150, 140, 130) if dis else U.INK)
            surf.blit(img, (r.centerx - 24, r.centery - 27 - (1 if hover else 0)))
            U.keycap(surf, (r.centerx, r.bottom - 2), key, 11)
            if not dis and self.quick_dot(i):
                c = (r.right - 6, r.y + 6)
                pg.draw.circle(surf, U.INK, c, 7)
                pg.draw.circle(surf, (230, 80, 90), c, 5)
                if int(self.t * 2) % 2:
                    pg.draw.circle(surf, (255, 160, 160), (c[0] - 1, c[1] - 1), 2)
            if hover:
                tt = A.font(13, True).render(name, False, U.INK)
                tr = pg.Rect(0, 0, tt.get_width() + 20, 26)
                tr.midbottom = (r.centerx, back.y - 4)
                tr.right = min(tr.right, W - 6)
                U.tag(surf, tr, inner=False)
                surf.blit(tt, (tr.x + 10, tr.y + 6))

    def draw_ranking(self, surf):
        mk = self.market
        rows = [("리라의 마법 부스", mk["lira"])] + list(mk["rivals"].items())
        rows.sort(key=lambda r: -r[1])
        r = pg.Rect(14, 118, 300, 48 + 24 * len(rows))
        U.tag(surf, r)
        surf.blit(U.icon("crown", 24, (190, 140, 40)), (r.x + 10, r.y + 8))
        U.text(surf, "달빛 장터 순위판", (r.x + 40, r.y + 12), 15, U.LAV_DARK, True)
        for i, (name, v) in enumerate(rows):
            col = (120, 60, 150) if name.startswith("리라") else U.INK
            U.text(surf, f"{i + 1}. {name}", (r.x + 16, r.y + 42 + i * 24), 13, col, name.startswith("리라"))
            U.text(surf, f"{int(v):,}원", (r.right - 16, r.y + 42 + i * 24), 13, col, right=True)

    def render(self):
        surf = self.canvas
        self.ui.begin(self.mouse)
        if self.mode == "title":
            self.title.draw(surf)
        else:
            self.render_world(surf)
            self.draw_hud(surf)
            self.touch.draw(surf)
            if self.menu:
                ov = pg.Surface((W, H), pg.SRCALPHA)   # 대화 중엔 가게가 보이도록 옅게
                ov.fill((20, 12, 30, 45 if isinstance(self.menu, M.Dialogue) else 120))
                surf.blit(ov, (0, 0))
                self.menu.draw(surf)
        if self.fade > 0:
            ov = pg.Surface((W, H), pg.SRCALPHA)
            ov.fill((16, 10, 24, int(255 * self.fade)))
            surf.blit(ov, (0, 0))
        if WEB and self.portrait():
            self.draw_rotate_hint(surf)
        self.ui.end()
        ww, wh = self.window.get_size()
        sc = min(ww / W, wh / H)
        if abs(sc - 1) < 1e-3:
            self.window.blit(surf, (0, 0))
        else:
            self.window.fill((0, 0, 0))
            img = pg.transform.smoothscale(surf, (int(W * sc), int(H * sc)))
            self.window.blit(img, ((ww - img.get_width()) // 2, (wh - img.get_height()) // 2))
        pg.display.flip()

    # ═══════════════════ 메인 루프 ═══════════════════
    def handle_event(self, e):
        if e.type in (pg.FINGERDOWN, pg.FINGERMOTION, pg.FINGERUP):
            if not self.fade_dir:
                self.handle_touch(e)
            return
        from_touch = getattr(e, "touch", False)
        if e.type == pg.MOUSEBUTTONDOWN and e.button == 1:
            pos = self.mouse_canvas(e.pos)
            if from_touch and self.touch.claims(pos):
                return                      # 손가락 이벤트가 이미 처리
            if not from_touch and self.touch.enabled and self.touch.down("mouse", pos):
                return                      # PC 브라우저에서 마우스로 조이스틱·버튼
        elif e.type == pg.MOUSEMOTION:
            if not from_touch and self.touch.stick_id == "mouse":
                self.touch.motion("mouse", self.mouse_canvas(e.pos))
            return
        elif e.type == pg.MOUSEBUTTONUP and e.button == 1:
            if not from_touch:
                self.touch.up("mouse")
            return
        if e.type == pg.QUIT:
            self.quit()
        elif e.type == pg.KEYDOWN:
            if self.menu and hasattr(self.menu, "key"):
                self.menu.key(e.key)
            elif self.menu and e.key == pg.K_ESCAPE:
                self.close_menu()
            elif self.mode == "title":
                if not self.fade_dir:
                    self.title.key(e.key)
            else:
                self.key(e.key)
        elif e.type == pg.MOUSEBUTTONDOWN and e.button == 1:
            pos = self.mouse_canvas(e.pos)
            if self.fade_dir:
                pass
            elif self.menu or self.mode == "title":
                self.ui.click = pos
            elif not self.click_hud(pos):
                self.click_world(pos)
        elif e.type == pg.MOUSEBUTTONDOWN and e.button == 3 and self.menu and hasattr(self.menu, "rclick"):
            self.menu.rclick(self.mouse_canvas(e.pos))
        elif e.type == pg.MOUSEWHEEL and self.menu and hasattr(self.menu, "wheel"):
            self.menu.wheel(e.y)

    def quit(self):
        if self.s and self.mode == "play":
            self.s.save()
        if WEB:                     # 웹에서는 창을 닫을 수 없으니 타이틀로 돌아가요
            if self.mode == "play":
                self.close_menu()
                self.fade_to(self.back_to_title)
            return
        self.running = False

    def back_to_title(self):
        self.menu = None
        self.mode = "title"
        self.title = M.Title(self)

    # ─── 웹: 화면 방향 ───
    def portrait(self):
        try:
            w = __import__("platform").window
            return int(w.innerWidth) < int(w.innerHeight)
        except Exception:
            return False

    def draw_rotate_hint(self, surf):
        ov = pg.Surface((W, H), pg.SRCALPHA)
        ov.fill((24, 14, 36, 225))
        surf.blit(ov, (0, 0))
        U.outlined(surf, "휴대폰을 가로로 돌려 주세요", (W // 2, H // 2 - 30), 36, U.CREAM, (58, 36, 70))
        U.outlined(surf, "달빛 고양이 상점은 가로 화면에서 즐길 수 있어요", (W // 2, H // 2 + 30), 20, U.GOLD, (58, 36, 70))

    # ─── 터치 ───
    def finger_pos(self, e):
        ww, wh = self.window.get_size()
        return self.mouse_canvas((e.x * ww, e.y * wh))

    def handle_touch(self, e):
        """손가락 이벤트. 조이스틱·버튼이 가져가면 True."""
        tc = self.touch
        if e.type == pg.FINGERDOWN:
            tc.enabled = True
            return tc.down(e.finger_id, self.finger_pos(e))
        if e.type == pg.FINGERMOTION:
            return tc.motion(e.finger_id, self.finger_pos(e))
        if e.type == pg.FINGERUP:
            return tc.up(e.finger_id)
        return False

    def step(self, fps=60):
        dt = min(self.clock.tick(fps) / 1000, 0.05)
        self.mouse = self.mouse_canvas(pg.mouse.get_pos())
        for e in pg.event.get():
            self.handle_event(e)
        self.update(dt)
        self.render()

    def run(self):
        while self.running:
            self.step()
        pg.quit()

    async def run_async(self):
        """웹(pygbag)용: 한 프레임마다 브라우저에 차례를 넘겨줘요."""
        import asyncio
        while self.running:
            self.step(60)
            await asyncio.sleep(0)

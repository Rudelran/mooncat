# -*- coding: utf-8 -*-
"""이미지·폰트 불러오기. 파일이 없으면 '빈칸(자리 표시)' 그림을 대신 그린다.
빈칸 목록은 missing 집합에 쌓이고, F9로 확인할 수 있다."""
import os
from pathlib import Path
import pygame as pg

ROOT = Path(__file__).resolve().parent.parent
ASSET = ROOT / "assets"
missing = set()
_cache = {}


def img_path(name):
    """그림 파일 경로. 웹 버전은 용량을 줄이려고 불투명한 큰 그림을 .jpg로 바꿔 둬서, png가 없으면 jpg를 찾아요."""
    p = ASSET / f"{name}.png"
    if not p.exists():
        j = ASSET / f"{name}.jpg"
        if j.exists():
            return j
    return p
_fonts = {}


# ─── 픽셀 글꼴 (갈무리, OFL) ───
# 요청 크기를 갈무리가 선명하게 보이는 크기(원래 크기의 정수배)로 맞춰요.
GALMURI = [  # (요청 상한, 파일, 실제 크기, 굵게 파일)
    (13, "Galmuri11.ttf", 12, "Galmuri11-Bold.ttf"),
    (17, "Galmuri14.ttf", 15, None),
    (22, "Galmuri9.ttf", 20, None),
    (27, "Galmuri11.ttf", 24, "Galmuri11-Bold.ttf"),
    (33, "Galmuri14.ttf", 30, None),
    (999, "Galmuri11.ttf", 36, "Galmuri11-Bold.ttf"),
]


class PixelFont:
    """pygame Font 감싸기: 항상 안티앨리어싱 끔, 굵은 파일이 없으면 1px 겹쳐 그려 굵게."""
    def __init__(self, font, fake_bold=False):
        self.f = font
        self.fake_bold = fake_bold

    SUBST = {"✓": "√v", "✔": "√v", "▸": "▶>", "▾": "▼v", "✦": "★*", "♡": "♥"}

    def fix(self, text):
        """글꼴에 없는 글자(예: ✓)를 비슷한 글자로 바꿈. 네모(⊠)로 보이는 것을 막아요."""
        if not hasattr(self, "_ok"):
            self._ok = {}
        out = []
        for ch in text:
            if ch in self.SUBST:
                if ch not in self._ok:
                    self._ok[ch] = next((c for c in self.SUBST[ch] if self._has(c)), ch)
                out.append(self._ok[ch])
            else:
                out.append(ch)
        return "".join(out)

    def _has(self, ch):
        """없는 글자는 '없는 글자 표시(.notdef)'와 똑같이 그려지는 것으로 판단."""
        try:
            if not hasattr(self, "_notdef"):
                self._notdef = pg.image.tobytes(self.f.render("\u0378", False, (0, 0, 0), (255, 255, 255)), "RGB")
            img = pg.image.tobytes(self.f.render(ch, False, (0, 0, 0), (255, 255, 255)), "RGB")
            return img != self._notdef
        except Exception:
            return True

    def render(self, text, aa=False, color=(0, 0, 0), bg=None):
        text = self.fix(text)
        t = self.f.render(text, False, color)
        if not self.fake_bold or not text:
            return t
        s = pg.Surface((t.get_width() + 1, t.get_height()), pg.SRCALPHA)
        s.blit(t, (0, 0))
        s.blit(t, (1, 0))
        return s

    def size(self, text):
        w, h = self.f.size(self.fix(text))
        return (w + (1 if self.fake_bold else 0), h)

    def get_linesize(self):
        return self.f.get_linesize()

    def get_height(self):
        return self.f.get_height()


def _font_file(name):
    p = ASSET / "fonts" / name
    return p if p.exists() else None


def font(size, bold=False):
    key = (size, bold)
    if key in _fonts:
        return _fonts[key]
    for limit, fname, real, bname in GALMURI:
        if size <= limit:
            break
    path = _font_file(bname if (bold and bname) else fname)
    f = None
    if path:
        try:
            f = PixelFont(pg.font.Font(str(path), real), fake_bold=bold and not bname)
        except Exception:
            f = None
    if f is None:   # 글꼴 파일이 없을 때: 맑은 고딕
        win = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
        for c in [win / ("malgunbd.ttf" if bold else "malgun.ttf"), Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")]:
            if c.exists():
                f = PixelFont(pg.font.Font(str(c), size))
                break
        else:
            f = PixelFont(pg.font.Font(None, size + 6))
    _fonts[key] = f
    return f


def pix(name, scale=2):
    """픽셀 아트를 최근접 확대 (UI 조각용)."""
    key = ("pix", name, scale)
    if key in _cache:
        return _cache[key]
    path = img_path(name)
    if not path.exists():
        missing.add(name)
        img = placeholder(name, (32 * scale, 32 * scale))
    else:
        img = pg.image.load(str(path)).convert_alpha()
        if scale != 1:
            img = pg.transform.scale(img, (img.get_width() * scale, img.get_height() * scale))
    _cache[key] = img
    return img


# v1.2: 이모지 도트 장식 → GPT 일러스트 (assets/decor_hd). 화면 높이(px) 기준.
DECOR_H = {"rock": 40, "tulip": 38, "clover": 28, "blossom": 30, "hibiscus": 34, "log": 40, "leaf": 24, "maple": 26,
           "wild_herb": 54, "wild_flower": 54, "honey": 62, "duck": 38, "snail": 30, "hedgehog": 34,
           "potted": 52, "books": 46, "teapot": 32, "basket": 34, "candle": 30}


def decor(name, flip=False):
    """바깥·가게 장식 그림. decor_hd가 있으면 일러스트, 없으면 예전 도트(2배)."""
    key = ("decor", name, flip)
    if key in _cache:
        return _cache[key]
    if name in DECOR_H and exists("decor_hd/" + name):
        img = image("decor_hd/" + name, height=DECOR_H[name])
    else:
        img = pix("decor/" + name, 2)
    if flip:
        img = pg.transform.flip(img, True, False)
    _cache[key] = img
    return img


def raw(name):
    key = ("raw", name)
    if key not in _cache:
        path = img_path(name)
        if path.exists():
            _cache[key] = pg.image.load(str(path)).convert_alpha()
        else:
            missing.add(name)
            _cache[key] = placeholder(name, (32, 32))
    return _cache[key]


def placeholder(name, size, color=(90, 70, 120)):
    w, h = size
    s = pg.Surface((w, h), pg.SRCALPHA)
    pg.draw.rect(s, (*color, 150), (0, 0, w, h), border_radius=8)
    # 점선 테두리
    for x in range(0, w, 10):
        pg.draw.line(s, (250, 240, 220, 220), (x, 0), (min(x + 5, w), 0), 2)
        pg.draw.line(s, (250, 240, 220, 220), (x, h - 2), (min(x + 5, w), h - 2), 2)
    for y in range(0, h, 10):
        pg.draw.line(s, (250, 240, 220, 220), (0, y), (0, min(y + 5, h)), 2)
        pg.draw.line(s, (250, 240, 220, 220), (w - 2, y), (w - 2, min(y + 5, h)), 2)
    label = name.split("/")[-1]
    f = font(max(10, min(16, w // 8)))
    t = f.render(label, True, (255, 250, 235))
    if t.get_width() > w - 6:
        t = pg.transform.smoothscale(t, (w - 6, max(8, int(t.get_height() * (w - 6) / t.get_width()))))
    s.blit(t, ((w - t.get_width()) // 2, (h - t.get_height()) // 2))
    return s


def walk(name, d, i):
    """v1.5: 4방향 걷기 그림 walk/<이름>/<방향>_<0~2>.png (2배로 저장 → 절반으로 부드럽게 축소)."""
    key = ("walk", name, d, i)
    if key not in _cache:
        img = raw(f"walk/{name}/{d}_{i}")
        _cache[key] = pg.transform.smoothscale(img, (max(1, img.get_width() // 2), max(1, img.get_height() // 2)))
    return _cache[key]


def has_walk(name):
    key = ("has_walk", name)
    if key not in _cache:
        _cache[key] = all(exists(f"walk/{name}/{d}_{i}") for d in ("down", "left", "right", "up") for i in range(3))
    return _cache[key]


def exists(name):
    return (img_path(name)).exists()


def image(name, size=None, height=None, color=(90, 70, 120)):
    """name: 'props/cauldron' 형식. size=(w,h) 강제, height=높이 기준 비율 유지."""
    key = (name, size, height)
    if key in _cache:
        return _cache[key]
    path = img_path(name)
    if path.exists():
        img = pg.image.load(str(path)).convert_alpha()
        if size:
            img = pg.transform.smoothscale(img, size)
        elif height:
            w = max(1, round(img.get_width() * height / img.get_height()))
            img = pg.transform.smoothscale(img, (w, height))
    else:
        missing.add(name)
        img = None
        import fallback              # 점선 빈칸 대신 임시 픽셀 그림
        if size:
            img = fallback.make(name, size)
        elif height and name in fallback.ASPECT:      # v1.0: 높이만 줘도 임시 그림
            img = fallback.make(name, (max(8, int(height * fallback.ASPECT[name])), height))
        if img is None:
            img = placeholder(name, size or (height or 64, height or 64), color)
    _cache[key] = img
    return img


def image_or(name, fallback, height, tint=None):
    """name이 없으면 fallback 그림(선택적으로 색을 입힘)을 쓰고, name은 빈칸 목록에 올린다."""
    if exists(name):
        return image(name, height=height)
    missing.add(name)
    key = ("tint", name, fallback, height, tint)
    if key in _cache:
        return _cache[key]
    img = image(fallback, height=height).copy()
    if tint:
        ov = pg.Surface(img.get_size(), pg.SRCALPHA)
        ov.fill((*tint, 255))
        img.blit(ov, (0, 0), special_flags=pg.BLEND_RGBA_MULT)
    _cache[key] = img
    return img


def mat_icon(mid, size, color, label):
    """재료 아이콘. assets/mats/<id>.png 가 없으면 색 동그라미 + 첫 글자."""
    name = f"mats/{mid}"
    if exists(name):   # 도트 아이콘은 최근접 확대, v1.3 일러스트(64px 초과)는 부드럽게 축소
        key = ("matpx", mid, size)
        if key not in _cache:
            img = raw(name)
            _cache[key] = (pg.transform.smoothscale if img.get_width() > 64 else pg.transform.scale)(img, (size, size))
        return _cache[key]
    missing.add(name)
    key = ("mat", mid, size)
    if key in _cache:
        return _cache[key]
    s = pg.Surface((size, size), pg.SRCALPHA)
    pg.draw.circle(s, (40, 28, 40, 160), (size // 2 + 1, size // 2 + 2), size // 2 - 1)
    pg.draw.circle(s, color, (size // 2, size // 2), size // 2 - 2)
    pg.draw.circle(s, (255, 255, 255, 90), (size // 2 - size // 6, size // 2 - size // 6), size // 6)
    t = font(max(10, int(size * 0.42)), True).render(label[0], True, (50, 35, 45))
    s.blit(t, ((size - t.get_width()) // 2, (size - t.get_height()) // 2))
    _cache[key] = s
    return s


def portrait(pid, height):
    return image(f"portraits/{pid}", height=height)


def item_icon(key, size):
    """'food:potato' · 'dish:d_soup' · 재료 id → 픽셀 아이콘(최근접 확대)."""
    import data as D
    if key.startswith("food:") or key.startswith("dish:"):
        kind, k = key.split(":", 1)
        name = ("food/" if kind == "food" else "dishes/") + k
        ck = ("itemic", name, size)
        if ck not in _cache:
            if exists(name):
                img = raw(name)
                sc = size / max(img.get_size())
                new = (max(1, round(img.get_width() * sc)), max(1, round(img.get_height() * sc)))
                # v1.1: 큰 GPT 일러스트는 부드럽게, 작은 도트 아이콘은 최근접으로
                _cache[ck] = pg.transform.smoothscale(img, new) if max(img.get_size()) > 64 else pg.transform.scale(img, new)
            else:
                missing.add(name)
                _cache[ck] = placeholder(name, (size, size))
        return _cache[ck]
    return mat_icon(key, size, D.MATS[key][3], D.MATS[key][0])

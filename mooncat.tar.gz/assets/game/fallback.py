# -*- coding: utf-8 -*-
"""그림 파일이 아직 없을 때 점선 빈칸 대신 보여 줄 '임시 픽셀 그림'.
절반 해상도로 그린 뒤 2배 최근접 확대 → 종이 UI와 같은 도트 굵기.
진짜 그림(PNG)을 assets 폴더에 넣으면 그쪽이 우선이고, 빈칸 목록(F9)에도 계속 남아요."""
import math
import pygame as pg
import assets as A

WOOD, WOOD_D, WOOD_L = (122, 80, 50), (78, 50, 34), (168, 116, 72)
CREAM = (246, 234, 210)
INK = (62, 42, 36)


def _canvas(size):
    w, h = size
    return pg.Surface((w // 2, h // 2), pg.SRCALPHA)


def _up(s, size):
    return pg.transform.scale(s, size)


def _goods(name, px):
    img = A.raw("goods/" + name)
    return pg.transform.scale(img, (px, px)) if img.get_width() != px else img


# ─── 가게 벽 게시판 ───
def notice_board(size):
    s = _canvas(size)
    w, h = s.get_size()
    pg.draw.rect(s, WOOD_D, (0, 0, w, h))
    pg.draw.rect(s, WOOD, (1, 1, w - 2, h - 2))
    pg.draw.rect(s, (196, 150, 100), (4, 4, w - 8, h - 8))           # 코르크
    for i in range(30):                                               # 코르크 점
        x, y = (i * 17) % (w - 10) + 5, (i * 11) % (h - 10) + 5
        s.set_at((x, y), (170, 124, 80))
    notes = [(7, 7, 16, 14, CREAM), (26, 9, 15, 17, (250, 226, 236)), (10, 24, 18, 13, (226, 240, 250))]
    for x, y, nw, nh, c in notes:
        pg.draw.rect(s, (120, 90, 70), (x + 1, y + 1, nw, nh))
        pg.draw.rect(s, c, (x, y, nw, nh))
        for ly in range(y + 4, y + nh - 2, 3):
            pg.draw.line(s, (170, 160, 150), (x + 2, ly), (x + nw - 3, ly))
        pg.draw.rect(s, (200, 60, 70), (x + nw // 2 - 1, y - 1, 2, 2))
    return _up(s, size)


# ─── 장터 분수 ───
def fountain(size):
    s = _canvas(size)
    w, h = s.get_size()
    stone, stone_d, stone_l = (150, 140, 170), (96, 88, 116), (190, 182, 206)
    water, water_l = (90, 140, 210), (170, 210, 245)
    pg.draw.ellipse(s, stone_d, (2, h - 26, w - 4, 24))
    pg.draw.ellipse(s, stone, (2, h - 30, w - 4, 22))
    pg.draw.ellipse(s, water, (7, h - 27, w - 14, 15))
    pg.draw.ellipse(s, water_l, (14, h - 24, w - 40, 5))
    cx = w // 2
    pg.draw.rect(s, stone_d, (cx - 4, 14, 8, h - 30))
    pg.draw.rect(s, stone, (cx - 3, 14, 5, h - 30))
    pg.draw.ellipse(s, stone_d, (cx - 14, 10, 28, 9))
    pg.draw.ellipse(s, stone_l, (cx - 13, 9, 26, 7))
    pg.draw.ellipse(s, water, (cx - 10, 10, 20, 4))
    for dx in (-1, 1):                                                # 물줄기
        for t in range(12):
            x = cx + dx * (10 + t * 1.6)
            y = 13 + (t * t) * 0.34
            s.set_at((int(x), int(y)), water_l)
            s.set_at((int(x), int(y) + 1), water)
    pg.draw.rect(s, water_l, (cx - 1, 3, 2, 8))
    return _up(s, size)


# ─── 장터 가판대 ───
STALL_GOODS = {"silver": ("crystal_ball", "ring"), "bakery": ("bread", "croissant"),
               "flower": ("tulip", "bouquet"), "candy": ("lollipop", "candy")}


def stall(kind, col, size):
    s = _canvas(size)
    w, h = s.get_size()
    dark = tuple(max(0, c - 50) for c in col)
    # 기둥
    for x in (5, w - 8):
        pg.draw.rect(s, WOOD_D, (x, 16, 3, h - 16))
    # 판매대
    top = h - 30
    pg.draw.rect(s, WOOD_D, (2, top, w - 4, 30))
    pg.draw.rect(s, WOOD_L, (2, top, w - 4, 4))
    pg.draw.rect(s, dark, (4, top + 6, w - 8, 22))
    pg.draw.rect(s, col, (5, top + 7, w - 10, 20))
    for x in range(10, w - 10, 12):
        pg.draw.line(s, dark, (x, top + 8), (x, top + 25))
    # 차양 (줄무늬 + 물결 끝단)
    pg.draw.rect(s, dark, (0, 2, w, 16))
    for i, x in enumerate(range(0, w, 8)):
        pg.draw.rect(s, col if i % 2 == 0 else CREAM, (x, 3, 8, 14))
        pg.draw.circle(s, col if i % 2 == 0 else CREAM, (x + 4, 17), 4)
        pg.draw.circle(s, dark, (x + 4, 17), 4, 1)
    pg.draw.rect(s, dark, (0, 1, w, 2))
    # 물건
    for i, gname in enumerate(STALL_GOODS.get(kind, ())):
        g = _goods(gname, 20)
        s.blit(g, (w // 2 - 24 + i * 26, top - 16))
    return _up(s, size)


def booth_lira(size):
    s = _canvas(size)
    w, h = s.get_size()
    lav, lav_d, lav_l = (150, 118, 206), (84, 60, 120), (210, 196, 240)
    for x in (6, w - 9):
        pg.draw.rect(s, WOOD_D, (x, 20, 3, h - 20))
    top = h - 30
    pg.draw.rect(s, WOOD_D, (2, top, w - 4, 30))
    pg.draw.rect(s, WOOD_L, (2, top, w - 4, 4))
    pg.draw.rect(s, lav_d, (4, top + 6, w - 8, 22))
    pg.draw.rect(s, lav, (5, top + 7, w - 10, 20))
    # 달 문양 천
    pg.draw.circle(s, (250, 226, 150), (w // 2, top + 17), 6)
    pg.draw.circle(s, lav, (w // 2 + 3, top + 15), 6)
    # 차양 + 달 간판
    pg.draw.rect(s, lav_d, (0, 4, w, 18))
    for i, x in enumerate(range(0, w, 10)):
        c = lav if i % 2 == 0 else lav_l
        pg.draw.rect(s, c, (x, 5, 10, 16))
        pg.draw.circle(s, c, (x + 5, 21), 5)
        pg.draw.circle(s, lav_d, (x + 5, 21), 5, 1)
    for i in range(6):                                                # 작은 별 장식
        x = 14 + i * (w - 28) // 5
        s.set_at((x, 10), (255, 240, 180)); s.set_at((x + 1, 10), (255, 240, 180))
    return _up(s, size)


# ─── 영구 기력 물약 병 ───
TONIC_COL = {"tonic1": (120, 200, 110), "tonic2": (250, 200, 80), "tonic3": (130, 160, 240),
             "tonic4": (200, 150, 250), "tonic5": None}


def tonic(tid, size):
    s = pg.Surface((30, 30), pg.SRCALPHA)
    col = TONIC_COL.get(tid) or (240, 150, 190)
    pg.draw.rect(s, (60, 44, 50), (12, 3, 6, 5))                       # 코르크 테두리
    pg.draw.rect(s, (170, 120, 80), (13, 4, 4, 3))
    pg.draw.rect(s, (60, 44, 50), (11, 8, 8, 4))
    pg.draw.circle(s, (60, 44, 50), (15, 19), 10)
    pg.draw.circle(s, (230, 240, 250), (15, 19), 9)
    pg.draw.rect(s, (230, 240, 250), (12, 8, 6, 5))
    if tid == "tonic5":
        for i, c in enumerate([(240, 110, 130), (250, 200, 90), (130, 210, 140), (120, 160, 240), (190, 140, 240)]):
            pg.draw.rect(s, c, (7, 15 + i * 2, 17, 2))
        m = pg.Surface((30, 30), pg.SRCALPHA)
        pg.draw.circle(m, (255, 255, 255, 255), (15, 19), 8)
        s2 = pg.Surface((30, 30), pg.SRCALPHA)
        s2.blit(s, (0, 0))
        s2.blit(m, (0, 0), special_flags=pg.BLEND_RGBA_MIN)
        pg.draw.circle(s, (230, 240, 250), (15, 19), 9)
        s.blit(s2, (0, 0))
    else:
        pg.draw.circle(s, col, (15, 21), 7)
        pg.draw.rect(s, col, (8, 17, 15, 3))
    pg.draw.rect(s, (255, 255, 255), (10, 15, 2, 4))                  # 반짝
    return pg.transform.scale(s, size)


# ─── 부엌 화덕 (v0.7) ───
def stove(size):
    s = _canvas(size)
    w, h = s.get_size()
    brick, brick_d, mortar = (176, 96, 72), (140, 72, 56), (210, 180, 150)
    # 연통
    pg.draw.rect(s, (70, 60, 66), (w - 14, 0, 7, h - 30))
    pg.draw.rect(s, (100, 90, 96), (w - 13, 0, 2, h - 30))
    # 벽돌 몸통
    body = pg.Rect(2, h - 40, w - 4, 40)
    pg.draw.rect(s, mortar, body)
    for row, y in enumerate(range(body.y, body.bottom, 5)):
        for x in range(body.x - (4 if row % 2 else 0), body.right, 9):
            pg.draw.rect(s, brick if (x // 9 + row) % 3 else brick_d, (max(x + 1, body.x), y + 1, 8 if x + 9 <= body.right else body.right - x - 1, 4))
    # 쇠 상판
    pg.draw.rect(s, (60, 52, 58), (0, h - 44, w, 6))
    pg.draw.rect(s, (96, 88, 96), (0, h - 44, w, 2))
    # 불구멍
    fire = pg.Rect(w // 2 - 11, h - 26, 22, 14)
    pg.draw.rect(s, (40, 26, 30), fire.inflate(4, 4))
    pg.draw.rect(s, (230, 120, 50), fire)
    pg.draw.rect(s, (255, 200, 90), fire.inflate(-8, -6))
    for k in range(3):
        s.set_at((fire.x + 4 + k * 7, fire.y + 2), (255, 240, 170))
    # 프라이팬 (Fluent 픽셀)
    pan = A.raw("decor/pan")
    s.blit(pan, (6, h - 44 - pan.get_height() + 3))
    return _up(s, size)


def make(name, size):
    """name에 맞는 임시 그림을 만들어 돌려준다. 없으면 None."""
    size = (int(size[0]), int(size[1]))
    try:
        if name in _V10_MAKERS:
            return _V10_MAKERS[name](size)
        if name.startswith("items/gear_"):
            return gear_icon(name[len("items/gear_"):], size)
        if name == "props/stove":
            return stove(size)
        if name == "props/notice_board":
            return notice_board(size)
        if name == "plaza/fountain":
            return fountain(size)
        if name == "plaza/booth_lira":
            return booth_lira(size)
        if name.startswith("plaza/stall_"):
            kind = name.split("_", 1)[1]
            col = {"silver": (96, 110, 160), "bakery": (196, 136, 80), "flower": (180, 120, 180), "candy": (230, 130, 160)}.get(kind, (150, 120, 150))
            return stall(kind, col, size)
        if name.startswith("items/tonic"):
            return tonic(name.split("/")[1], size)
    except Exception:
        return None
    return None


# ═══════════════════ v1.0 임시 그림 (브람 · 세공대 · 통발 · 토템 · 공방 도구) ═══════════════════
SKIN, SKIN_D = (236, 196, 160), (196, 150, 120)
BEARD, BEARD_D = (226, 222, 214), (170, 164, 156)
COPPER, COPPER_D, COPPER_L = (196, 116, 70), (132, 72, 44), (236, 164, 110)
LEATHER, LEATHER_D = (120, 78, 52), (84, 52, 34)
SHIRT, SHIRT_D = (160, 72, 64), (112, 46, 44)

# 높이만 주고 부를 때 쓸 가로:세로 비율
ASPECT = {"portraits/bram": 0.78, "portraits/bram_smile": 0.78, "npc_world/bram": 0.72, "props/bram_stall": 1.35,
          "props/merge_bench": 1.3, "props/trap_set": 1.0, "props/trap_full": 1.0, "props/totem_1": 0.5, "props/totem_2": 0.5}


def bram_portrait(size, smile=False):
    s = _canvas(size)
    w, h = s.get_size()
    cx = w // 2
    # 몸 (셔츠 + 가죽 앞치마)
    pg.draw.ellipse(s, SHIRT_D, (cx - w * 0.46, h * 0.62, w * 0.92, h * 0.6))
    pg.draw.ellipse(s, SHIRT, (cx - w * 0.44, h * 0.63, w * 0.88, h * 0.56))
    pg.draw.rect(s, LEATHER_D, (cx - w * 0.26, h * 0.7, w * 0.52, h * 0.32))
    pg.draw.rect(s, LEATHER, (cx - w * 0.24, h * 0.71, w * 0.48, h * 0.3))
    for sx in (-1, 1):
        pg.draw.line(s, LEATHER_D, (cx + sx * w * 0.22, h * 0.72), (cx + sx * w * 0.3, h * 0.6), 2)
    pg.draw.rect(s, COPPER, (cx - 3, h * 0.84, 6, 5))
    # 머리
    face = pg.Rect(cx - w * 0.26, h * 0.18, w * 0.52, h * 0.42)
    pg.draw.ellipse(s, SKIN_D, face.inflate(2, 2))
    pg.draw.ellipse(s, SKIN, face)
    # 두건 (붉은 반다나) + 보안경
    pg.draw.ellipse(s, SHIRT_D, (face.x - 1, face.y - h * 0.05, face.w + 2, face.h * 0.5))
    pg.draw.ellipse(s, SHIRT, (face.x, face.y - h * 0.045, face.w, face.h * 0.46))
    pg.draw.rect(s, SKIN, (face.x + 2, face.y + face.h * 0.28, face.w - 4, face.h * 0.2))
    for sx in (-1, 1):
        gx = cx + sx * w * 0.11
        pg.draw.circle(s, COPPER_D, (int(gx), int(face.y + face.h * 0.2)), max(3, int(w * 0.07)))
        pg.draw.circle(s, (170, 210, 230), (int(gx), int(face.y + face.h * 0.2)), max(2, int(w * 0.05)))
    # 눈썹 · 눈
    ey = face.y + face.h * 0.48
    for sx in (-1, 1):
        ex = cx + sx * w * 0.1
        pg.draw.line(s, BEARD_D, (ex - 5, ey - 5), (ex + 5, ey - 4 - sx), 3)
        if smile:
            pg.draw.arc(s, INK, (ex - 4, ey - 2, 8, 6), 0.3, 2.8, 2)
        else:
            pg.draw.rect(s, INK, (ex - 2, ey - 1, 3, 4))
    # 코
    pg.draw.ellipse(s, (224, 150, 130), (cx - 5, ey + 2, 10, 9))
    # 수염 (땋은 두 갈래)
    beard = [(face.x + 2, ey + 6), (face.right - 2, ey + 6), (cx + w * 0.2, h * 0.86), (cx, h * 0.95), (cx - w * 0.2, h * 0.86)]
    pg.draw.polygon(s, BEARD_D, [(x, y + 1) for x, y in beard])
    pg.draw.polygon(s, BEARD, beard)
    for sx in (-1, 1):
        bx = cx + sx * w * 0.09
        for k in range(3):
            pg.draw.circle(s, BEARD_D, (int(bx), int(h * 0.8 + k * 4)), 2)
    pg.draw.arc(s, INK, (cx - 6, ey + 9, 12, 7 if smile else 4), 3.4, 6.0, 2)       # 입
    for k in range(6):                                                               # 톱밥
        s.set_at((int(cx - w * 0.15 + k * w * 0.06), int(h * 0.74 + (k % 2) * 3)), (230, 190, 120))
    return _up(s, size)


def bram_world(size):
    s = _canvas(size)
    w, h = s.get_size()
    cx = w // 2
    pg.draw.ellipse(s, (0, 0, 0, 60), (cx - w * 0.36, h - 7, w * 0.72, 6))
    # 다리 · 장화
    for sx in (-1, 1):
        pg.draw.rect(s, LEATHER_D, (cx + sx * w * 0.14 - 4, h * 0.8, 8, h * 0.16))
    # 몸
    body = pg.Rect(cx - w * 0.34, h * 0.45, w * 0.68, h * 0.4)
    pg.draw.ellipse(s, SHIRT_D, body.inflate(2, 2))
    pg.draw.ellipse(s, SHIRT, body)
    pg.draw.rect(s, LEATHER, (cx - w * 0.2, h * 0.52, w * 0.4, h * 0.32))
    # 망치
    pg.draw.line(s, WOOD_D, (cx + w * 0.34, h * 0.5), (cx + w * 0.44, h * 0.82), 3)
    pg.draw.rect(s, (150, 150, 160), (cx + w * 0.28, h * 0.44, w * 0.18, h * 0.08))
    # 머리 · 수염
    head = pg.Rect(cx - w * 0.25, h * 0.12, w * 0.5, h * 0.36)
    pg.draw.ellipse(s, SKIN, head)
    pg.draw.ellipse(s, SHIRT, (head.x, head.y - 3, head.w, head.h * 0.45))
    pg.draw.polygon(s, BEARD, [(head.x + 2, head.y + head.h * 0.55), (head.right - 2, head.y + head.h * 0.55), (cx, h * 0.7)])
    for sx in (-1, 1):
        pg.draw.rect(s, INK, (cx + sx * w * 0.09 - 1, head.y + head.h * 0.45, 2, 3))
    pg.draw.ellipse(s, (224, 150, 130), (cx - 3, head.y + head.h * 0.5, 6, 5))
    return _up(s, size)


def bram_stall(size):
    s = _canvas(size)
    w, h = s.get_size()
    # 수레 몸통
    pg.draw.rect(s, WOOD_D, (4, h * 0.55, w - 8, h * 0.3))
    pg.draw.rect(s, WOOD, (6, h * 0.56, w - 12, h * 0.27))
    for x in range(10, w - 10, 12):
        pg.draw.line(s, WOOD_D, (x, h * 0.57), (x, h * 0.82))
    # 바퀴
    for wx in (w * 0.2, w * 0.8):
        pg.draw.circle(s, WOOD_D, (int(wx), int(h * 0.86)), int(h * 0.12))
        pg.draw.circle(s, WOOD_L, (int(wx), int(h * 0.86)), int(h * 0.08), 2)
    # 기둥 · 구리색 차양
    for px in (8, w - 10):
        pg.draw.rect(s, WOOD_D, (px, h * 0.12, 3, h * 0.45))
    for k in range(8):
        col = COPPER if k % 2 == 0 else CREAM
        x0 = 4 + k * (w - 8) / 8
        pg.draw.polygon(s, col, [(x0, h * 0.1), (x0 + (w - 8) / 8, h * 0.1), (x0 + (w - 8) / 8, h * 0.24), (x0 + (w - 8) / 16, h * 0.28), (x0, h * 0.24)])
    pg.draw.rect(s, COPPER_D, (2, h * 0.07, w - 4, 4))
    # 모루 · 통발 · 톱
    pg.draw.rect(s, (70, 70, 84), (w * 0.14, h * 0.44, w * 0.2, h * 0.08))
    pg.draw.rect(s, (110, 110, 126), (w * 0.12, h * 0.4, w * 0.26, h * 0.05))
    pg.draw.ellipse(s, (170, 140, 90), (w * 0.46, h * 0.36, w * 0.2, h * 0.2))
    for k in range(4):
        pg.draw.line(s, (120, 94, 60), (w * 0.48 + k * w * 0.04, h * 0.37), (w * 0.48 + k * w * 0.04, h * 0.55))
    pg.draw.rect(s, (180, 130, 80), (w * 0.72, h * 0.42, w * 0.16, h * 0.12))
    pg.draw.rect(s, COPPER_L, (w * 0.74, h * 0.38, w * 0.12, h * 0.05))
    return _up(s, size)


def merge_bench(size):
    s = _canvas(size)
    w, h = s.get_size()
    pg.draw.rect(s, WOOD_D, (w * 0.08, h * 0.55, 5, h * 0.42))
    pg.draw.rect(s, WOOD_D, (w * 0.88, h * 0.55, 5, h * 0.42))
    pg.draw.rect(s, WOOD_D, (2, h * 0.42, w - 4, h * 0.16))
    pg.draw.rect(s, WOOD_L, (3, h * 0.43, w - 6, h * 0.08))
    # 격자 판
    grid = pg.Rect(w * 0.18, h * 0.24, w * 0.4, h * 0.2)
    pg.draw.rect(s, (90, 70, 110), grid)
    for k in range(1, 4):
        pg.draw.line(s, (140, 116, 170), (grid.x + grid.w * k / 4, grid.y), (grid.x + grid.w * k / 4, grid.bottom))
    pg.draw.line(s, (140, 116, 170), (grid.x, grid.centery), (grid.right, grid.centery))
    for k, col in enumerate(((196, 176, 255), (250, 200, 80), (110, 180, 250))):
        pg.draw.polygon(s, col, [(grid.x + 5 + k * 9, grid.y + 3), (grid.x + 8 + k * 9, grid.y + 6), (grid.x + 5 + k * 9, grid.y + 9), (grid.x + 2 + k * 9, grid.y + 6)])
    # 확대경 · 망치
    pg.draw.circle(s, COPPER_D, (int(w * 0.74), int(h * 0.3)), int(h * 0.1), 2)
    pg.draw.circle(s, (200, 230, 245), (int(w * 0.74), int(h * 0.3)), int(h * 0.08))
    pg.draw.line(s, COPPER_D, (w * 0.74, h * 0.4), (w * 0.74, h * 0.44), 2)
    pg.draw.line(s, WOOD, (w * 0.62, h * 0.4), (w * 0.86, h * 0.36), 2)
    pg.draw.rect(s, (130, 130, 146), (w * 0.84, h * 0.3, w * 0.06, h * 0.1))
    return _up(s, size)


def trap_prop(size, full=False):
    s = _canvas(size)
    w, h = s.get_size()
    pg.draw.ellipse(s, (120, 180, 220, 150), (2, h * 0.62, w - 4, h * 0.3))           # 물결
    body = pg.Rect(w * 0.18, h * 0.3, w * 0.64, h * 0.52)
    pg.draw.ellipse(s, (120, 94, 60), body)
    pg.draw.ellipse(s, (176, 140, 90), body.inflate(-4, -4))
    for k in range(1, 5):
        x = body.x + body.w * k / 5
        pg.draw.line(s, (120, 94, 60), (x, body.y + 2), (x, body.bottom - 2))
    pg.draw.line(s, (120, 94, 60), (body.x + 2, body.centery), (body.right - 2, body.centery))
    pg.draw.line(s, WOOD_D, (w * 0.84, h * 0.08), (w * 0.84, h * 0.7), 3)              # 말뚝 · 밧줄
    pg.draw.line(s, (220, 200, 150), (w * 0.84, h * 0.2), (body.right - 3, body.y + 6))
    pg.draw.rect(s, (230, 80, 80), (w * 0.8, h * 0.06, 6, 5))                          # 빨간 깃
    if full:
        pg.draw.polygon(s, (190, 210, 230), [(w * 0.46, h * 0.3), (w * 0.58, h * 0.14), (w * 0.62, h * 0.3)])
        for k in range(3):
            s.set_at((int(w * 0.3 + k * 7), int(h * 0.2 - k * 3)), (255, 250, 190))
    return _up(s, size)


def totem_prop(size, lv=1):
    s = _canvas(size)
    w, h = s.get_size()
    cx = w // 2
    pg.draw.ellipse(s, (0, 0, 0, 60), (cx - w * 0.4, h - 6, w * 0.8, 5))
    pg.draw.rect(s, WOOD_D, (cx - w * 0.2, h * 0.3, w * 0.4, h * 0.68))
    pg.draw.rect(s, WOOD, (cx - w * 0.17, h * 0.31, w * 0.34, h * 0.66))
    for k in range(3):                                   # 물결 무늬
        y = h * (0.45 + k * 0.16)
        pg.draw.arc(s, (90, 150, 200), (cx - w * 0.15, y, w * 0.3, h * 0.06), 3.3, 6.1, 2)
    head = [(cx - w * 0.36, h * 0.3), (cx, h * 0.08), (cx + w * 0.36, h * 0.3)]     # 물고기 머리
    pg.draw.polygon(s, (90, 150, 200), head)
    pg.draw.polygon(s, (60, 110, 160), head, 2)
    pg.draw.circle(s, CREAM, (int(cx + w * 0.08), int(h * 0.22)), 2)
    if lv >= 2:
        pg.draw.circle(s, (255, 244, 190, 120), (cx, int(h * 0.06)), int(w * 0.34))
        pg.draw.circle(s, (250, 236, 150), (cx, int(h * 0.06)), int(w * 0.16))
        pg.draw.circle(s, (255, 255, 230), (cx - 2, int(h * 0.05)), int(w * 0.06))
    return _up(s, size)


def gear_icon(k, size):
    s = _canvas(size)
    w, h = s.get_size()
    if k in ("trap", "trap_iron"):
        body = pg.Rect(w * 0.12, h * 0.25, w * 0.76, h * 0.55)
        col, dk = ((176, 140, 90), (120, 94, 60)) if k == "trap" else ((150, 156, 170), (90, 94, 110))
        pg.draw.ellipse(s, dk, body)
        pg.draw.ellipse(s, col, body.inflate(-4, -4))
        for q in range(1, 4):
            pg.draw.line(s, dk, (body.x + body.w * q / 4, body.y + 2), (body.x + body.w * q / 4, body.bottom - 2))
    elif k in ("totem1", "totem2"):
        return totem_prop(size, 2 if k == "totem2" else 1)
    elif k == "pot":
        pg.draw.ellipse(s, COPPER_D, (w * 0.12, h * 0.34, w * 0.76, h * 0.52))
        pg.draw.ellipse(s, COPPER, (w * 0.14, h * 0.36, w * 0.72, h * 0.46))
        pg.draw.ellipse(s, (80, 50, 40), (w * 0.18, h * 0.3, w * 0.64, h * 0.16))
        pg.draw.line(s, COPPER_D, (w * 0.86, h * 0.5), (w * 0.98, h * 0.44), 3)
        pg.draw.line(s, COPPER_L, (w * 0.24, h * 0.5), (w * 0.3, h * 0.72), 2)
    elif k in ("board6", "board7"):
        n = 6 if k == "board6" else 7
        r = pg.Rect(w * 0.12, h * 0.12, w * 0.76, h * 0.76)
        pg.draw.rect(s, WOOD_D, r)
        pg.draw.rect(s, (90, 70, 110), r.inflate(-4, -4))
        for q in range(1, n):
            pg.draw.line(s, (140, 116, 170), (r.x + r.w * q / n, r.y + 2), (r.x + r.w * q / n, r.bottom - 2))
            pg.draw.line(s, (140, 116, 170), (r.x + 2, r.y + r.h * q / n), (r.right - 2, r.y + r.h * q / n))
    elif k == "hammer":
        pg.draw.line(s, WOOD_D, (w * 0.25, h * 0.85), (w * 0.62, h * 0.35), 4)
        pg.draw.polygon(s, (130, 130, 146), [(w * 0.46, h * 0.18), (w * 0.86, h * 0.44), (w * 0.76, h * 0.56), (w * 0.38, h * 0.3)])
        pg.draw.circle(s, (196, 176, 255), (int(w * 0.72), int(h * 0.2)), 3)
    elif k == "shelf":
        pg.draw.rect(s, WOOD_D, (w * 0.14, h * 0.12, w * 0.72, h * 0.8))
        for q in range(3):
            pg.draw.rect(s, WOOD_L, (w * 0.18, h * (0.2 + q * 0.24), w * 0.64, 3))
        pg.draw.polygon(s, (250, 220, 90), [(w * 0.7, h * 0.02), (w * 0.76, h * 0.14), (w * 0.9, h * 0.14), (w * 0.79, h * 0.22), (w * 0.83, h * 0.36), (w * 0.7, h * 0.27), (w * 0.57, h * 0.36), (w * 0.61, h * 0.22), (w * 0.5, h * 0.14), (w * 0.64, h * 0.14)])
    else:
        return None
    return _up(s, size)


_V10_MAKERS = {
    "portraits/bram": lambda sz: bram_portrait(sz), "portraits/bram_smile": lambda sz: bram_portrait(sz, True),
    "npc_world/bram": bram_world, "props/bram_stall": bram_stall, "props/merge_bench": merge_bench,
    "props/trap_set": lambda sz: trap_prop(sz), "props/trap_full": lambda sz: trap_prop(sz, True),
    "props/totem_1": lambda sz: totem_prop(sz, 1), "props/totem_2": lambda sz: totem_prop(sz, 2),
}

# -*- coding: utf-8 -*-
"""효과음 · 배경음. 소리 파일은 게임 안에서 직접 합성해 만든 자체 제작 음원."""
import json, time
import pygame as pg
import assets as A
from state import save_dir, web_persist, WEB

VOL = {"click": .5, "hover": .3, "page": .6, "open": .6, "close": .5, "coin": .5, "craft": .7, "sparkle": .5,
       "heart": .6, "error": .5, "levelup": .7, "doorbell": .45, "splash": .6, "magic": .35, "pop": .6}


class Audio:
    def __init__(self):
        self.ok = False
        self.sounds = {}
        self.last = {}
        self.track = None
        self.settings = {"bgm": 0.6, "sfx": 0.8}
        try:
            p = save_dir() / "settings-v5.json"
            if p.exists():
                self.settings.update(json.loads(p.read_text(encoding="utf-8")))
        except Exception:
            pass
        try:
            if not pg.mixer.get_init():
                pg.mixer.init(22050, -16, 1, 512)
            self.ok = True
        except Exception:
            self.ok = False
        if self.ok:
            for n in VOL:
                f = A.ASSET / "sfx" / f"{n}.ogg"      # 웹 버전은 ogg
                if not f.exists():
                    f = A.ASSET / "sfx" / f"{n}.ogg"
                if f.exists():
                    try:
                        self.sounds[n] = pg.mixer.Sound(str(f))
                    except Exception:
                        pass

    def save(self):
        try:
            f = save_dir() / "settings-v5.json"
            f.write_text(json.dumps(self.settings), encoding="utf-8")
            web_persist(f)
        except Exception:
            pass

    def play(self, name, gap=0.05):
        if not self.ok or name not in self.sounds or self.settings["sfx"] <= 0:
            return
        now = time.time()
        if now - self.last.get(name, 0) < gap:
            return
        self.last[name] = now
        s = self.sounds[name]
        s.set_volume(VOL.get(name, .5) * self.settings["sfx"])
        s.play()

    def music(self, name):
        if not self.ok or name == self.track:
            return
        self.track = name
        f = A.ASSET / "bgm" / f"{name}.ogg"
        try:
            if not f.exists():
                if WEB:
                    pg.mixer.music.stop()
                else:
                    pg.mixer.music.fadeout(600)
                return
            if WEB:          # 웹: 페이드아웃 중에 새 곡을 불러오면 브라우저가 멈춰요 → 바로 멈추고 교체
                pg.mixer.music.stop()
            else:
                pg.mixer.music.fadeout(400)
            pg.mixer.music.load(str(f))
            pg.mixer.music.set_volume(self.settings["bgm"] * 0.6)
            pg.mixer.music.play(-1, fade_ms=900)
        except Exception:
            pass

    def set_volume(self, kind, v):
        self.settings[kind] = max(0, min(1, v))
        if kind == "bgm" and self.ok:
            pg.mixer.music.set_volume(self.settings["bgm"] * 0.6)
        self.save()

# -*- coding: utf-8 -*-
"""게임 상태·경제 규칙·저장."""
import json, os, random, sys
from pathlib import Path
import data as D

WEB = sys.platform == "emscripten"      # 웹(브라우저) 버전인지
_web_restored = False

SAVE_NAME = "save-v4-claude.json"


def save_dir():
    global _web_restored
    if WEB:
        p = Path("/tmp/MooncatAtelier")
        p.mkdir(parents=True, exist_ok=True)
        if not _web_restored:          # 브라우저 저장소(localStorage)에 있던 기록을 파일로 되살리기
            _web_restored = True
            try:
                ls = __import__("platform").window.localStorage
                for name in (SAVE_NAME, "settings-v5.json"):
                    v = ls.getItem("mooncat:" + name)
                    if v:
                        (p / name).write_text(str(v), encoding="utf-8")
            except Exception:
                pass
        return p
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    p = Path(base) / "MooncatAtelier"
    p.mkdir(parents=True, exist_ok=True)
    return p


def web_persist(path):
    """웹 버전: 방금 쓴 파일을 브라우저 저장소에도 넣어 둬요 (창을 닫아도 남도록)."""
    if not WEB:
        return
    try:
        ls = __import__("platform").window.localStorage
        ls.setItem("mooncat:" + Path(path).name, Path(path).read_text(encoding="utf-8"))
    except Exception:
        pass


def xp_threshold(level):
    """레벨 level에 도달하는 데 필요한 누적 경험치."""
    return int(sum(60 * k ** 1.5 for k in range(1, level)))


class State:
    def __init__(self):
        self.version = 4
        self.day = 1
        self.hour = D.DAY_START
        self.gold = 12_000
        self.total_revenue = 0
        self.xp = 0
        self.energy = D.BASE_ENERGY
        self.tonics = []
        self.chapter = 1
        self.story_seen = []
        self.goals_claimed = []
        self.stats = {}
        self.materials = {m: 0 for m in D.MAT_ORDER}
        self.materials.update(herb=8, starflower=6, sunflower=10, cotton=4, bottle=8, salt=6, wool=3, crystal=2)
        self.products = {p: 0 for p in D.PROD_ORDER}
        self.products["p_sun"] = 4
        self.shelves = [None] * 6
        self.shelves[0] = {"type": "potion", "stock": {"p_sun": 4}}
        self.shelves[1] = {"type": "bath", "stock": {}}
        self.products["p_sun"] = 0
        self.deco_owned = []
        self.deco_placed = {}          # id -> ["floor", x, y] or ["wall", slot]
        self.plots = [{"crop": None, "days": 0, "watered": False} for _ in range(8)]
        self.plot_count = 4
        self.luna = 5
        self.luna_petted = False
        self.luna_snacks = 0
        self.npc = {k: {"aff": 0, "met": False, "talked": -1, "quest": "none", "seen": []} for k in list(D.NPC_ORDER) + ["cecilia", "noel", "bram"]}
        self.flags = {}
        self.first_visits = []
        self.forest_paid_day = 0
        self.hans_day = 0
        self.hans_stock = {}
        self.price_mode = 100
        self.competition_until = 0
        self.orders = []
        self.orders_day = 0
        self.rooms = []
        self.workshop_recipe = None
        self.ending = ""
        self.free = False
        self.noel_met = False
        self.letters_read = 0
        self.lucky_day = 0
        self.food = {f: 0 for f in D.FOOD_ORDER}       # 요리 재료
        self.dishes = {d: 0 for d in D.DISH_ORDER}      # 만든 요리
        self.eaten_today = 0
        self.mail = []              # v0.8 우편함: {"kind": "letter"/"neighbor", "sp", "line", "day", "read"}
        self.parcels = []           # 버들골 소포 주문
        self.parcels_day = 0
        self.last_letter_day = 0
        self.market = {"signed": False, "day": 0, "done": False, "rank": 0, "helpers": [], "shared": None, "cart": {}}
        # v1.0
        self.shelf_store = []           # 회수한 진열장 {"type", "lv"}
        self.gear = {"trap": 0, "trap_iron": 0, "totem": 0, "pot": 0, "hammer": 0, "board": 5}
        self.traps = [None, None, None]  # 통발 자리: {"kind": "trap"/"trap_iron", "day": 놓은 날}
        self.totem_at = None             # 토템이 서 있는 낚시터 번호 (0 북쪽 · 1 남쪽)
        self.mana = 0                    # 마력 칸 (0~3)
        self.shards = 0                  # 마력 부스러기 주머니
        self.merge = [0] * 49            # 세공대 판 (7×7 중 board×board만 사용)
        self.dishq = {}                  # 요리 품질별 개수 {did: [보통, 좋음, 최고]}
        self.new_day_log()

    # ───────────── 기본 계산 ─────────────
    def new_day_log(self):
        self.log = {"revenue": 0, "visitors": 0, "sold": {}, "missed": {}, "regulars": [], "cat_revenue": {}}

    @property
    def level(self):
        lv = 1
        while lv < 10 and self.xp >= xp_threshold(lv + 1):
            lv += 1
        return lv

    def add_xp(self, n):
        before = self.level
        self.xp += n
        return self.level > before

    @property
    def max_energy(self):
        return D.BASE_ENERGY + (self.level - 1) + sum(t[2] for t in D.TONICS if t[0] in self.tonics)

    def stat(self, key, n=1):
        self.stats[key] = self.stats.get(key, 0) + n

    def placed(self, deco):
        return deco in self.deco_placed

    @property
    def rep(self):
        return sum(D.DECO[d][2] for d in self.deco_placed) + self.level

    def unlocked(self, pid):
        u = D.PROD[pid]["unlock"]
        if isinstance(u, int):
            return self.chapter >= u
        if u == "luna60":
            return self.luna >= 60
        if u.startswith("quest:"):
            return self.npc[u[6:]]["quest"] in ("active", "done")
        return False

    def mat_unlocked(self, m):
        return self.chapter >= D.MATS[m][2]

    def max_craft(self, pid):
        r = D.PROD[pid]["recipe"]
        return min(self.materials.get(k, 0) // v for k, v in r.items())

    def craft(self, pid, times=1, rng=random):
        if not self.unlocked(pid):
            return False, "아직 모르는 레시피예요."
        times = min(times, self.max_craft(pid))
        if times < 1:
            return False, "재료가 부족해요."
        made = 0
        for _ in range(times):
            for k, v in D.PROD[pid]["recipe"].items():
                self.materials[k] -= v
            n = 2 + (1 if self.placed("orrery") and rng.random() < 0.15 else 0)
            self.products[pid] += n
            made += n
            self.stat("craft:" + pid)
            self.stat("craft_cat:" + D.PROD[pid]["cat"])
        up = self.add_xp(2 * made)
        return True, f"{D.PROD[pid]['name']} {made}개 완성!" + ("  레벨 업!" if up else "")

    def add_mat(self, m, n, xp=True):
        self.materials[m] = self.materials.get(m, 0) + n
        if xp:
            self.add_xp(n)

    # ───────────── 판매 ─────────────
    def sale_price(self, pid):
        p = D.PROD[pid]["price"] * self.price_mode / 100
        if D.PROD[pid]["cat"] == "goods" and self.placed("pawsign"):
            p *= 1.10
        return p

    def tip_mult(self):
        return 1 + self.rep * 0.004 + (0.10 if self.placed("teaset") else 0)

    def record_sale(self, items, lucky=False, market=False):
        """items: 제품 id 리스트 (이미 재고에서 빠진 상태). 결제액 반환."""
        base = sum(self.sale_price(p) for p in items)
        total = int(round(base * self.tip_mult() * (2 if lucky else 1) / 10) * 10)
        self.gold += total
        self.total_revenue += total
        self.log["revenue"] += total
        for p in items:
            self.log["sold"][p] = self.log["sold"].get(p, 0) + 1
            c = D.PROD[p]["cat"]
            self.log["cat_revenue"][c] = self.log["cat_revenue"].get(c, 0) + D.PROD[p]["price"]
            self.stat("sold")
            self.stat("sold_cat:" + c)
            if c != "potion":
                self.stat("sold_nonpotion")
        self.add_xp(int(base / 250))
        return total

    def miss(self, cat, why):
        k = f"{cat}|{why}"
        self.log["missed"][k] = self.log["missed"].get(k, 0) + 1

    def customers_today(self):
        n = 8 + 2 * self.level + self.rep // 4
        if self.luna >= 30:
            n += 1
        if self.placed("pawsign"):
            n += 1
        return min(28, n)

    # ───────────── 진열대 ─────────────
    def shelf_count(self, i):
        s = self.shelves[i]
        return sum(s["stock"].values()) if s else 0

    def shelf_cap(self, i):
        sh = self.shelves[i]
        return D.SHELF_TYPES[sh["type"]][2] + D.SHELF_LV_BONUS.get(sh.get("lv", 1), 0)

    def stock(self, i, pid, n):
        s = self.shelves[i]
        n = min(n, self.products[pid], self.shelf_cap(i) - self.shelf_count(i))
        if n <= 0:
            return 0
        self.products[pid] -= n
        s["stock"][pid] = s["stock"].get(pid, 0) + n
        return n

    def unstock(self, i, pid):
        s = self.shelves[i]
        n = s["stock"].pop(pid, 0)
        self.products[pid] += n

    def auto_stock(self):
        moved = 0
        for i, s in enumerate(self.shelves):
            if not s:
                continue
            cat = D.SHELF_TYPES[s["type"]][1]
            pids = [p for p in D.PROD_ORDER if D.PROD[p]["cat"] == cat and self.products[p] > 0]
            guard = 0
            while pids and self.shelf_count(i) < self.shelf_cap(i) and guard < 200:
                guard += 1
                for p in list(pids):
                    if self.products[p] <= 0:
                        pids.remove(p)
                        continue
                    moved += self.stock(i, p, 1)
                    if self.shelf_count(i) >= self.shelf_cap(i):
                        break
        return moved

    def buy_shelf(self, t, free=False):
        price = 0 if free else D.SHELF_TYPES[t][3]
        if self.gold < price:
            return False, "보유금이 부족해요."
        self.gold -= price
        if None not in self.shelves:        # v1.0: 자리가 차면 진열장 창고로
            self.shelf_store.append({"type": t, "lv": 1})
            return True, f"{D.SHELF_TYPES[t][0]}을(를) 진열장 창고에 넣었어요. (계산대 › 진열대 배치)"
        self.shelves[self.shelves.index(None)] = {"type": t, "stock": {}, "lv": 1}
        return True, f"{D.SHELF_TYPES[t][0]}을(를) 들여놓았어요."

    # ───────────── v1.0 진열대 배치 ─────────────
    def pickup_shelf(self, i):
        sh = self.shelves[i]
        if not sh:
            return False, "빈 자리예요."
        for pid, n in sh["stock"].items():
            self.products[pid] = self.products.get(pid, 0) + n
        self.shelf_store.append({"type": sh["type"], "lv": sh.get("lv", 1)})
        self.shelves[i] = None
        return True, f"{D.SHELF_TYPES[sh['type']][0]}을(를) 회수했어요. 올려 둔 제품은 창고로 돌아갔어요."

    def place_shelf(self, j, i):
        if self.shelves[i] is not None or not (0 <= j < len(self.shelf_store)):
            return False, "놓을 수 없어요."
        st = self.shelf_store.pop(j)
        self.shelves[i] = {"type": st["type"], "stock": {}, "lv": st.get("lv", 1)}
        return True, f"{D.SHELF_TYPES[st['type']][0]}을(를) {i + 1}번 자리에 놓았어요."

    def swap_shelves(self, i, j):
        self.shelves[i], self.shelves[j] = self.shelves[j], self.shelves[i]
        return True, f"{i + 1}번과 {j + 1}번 자리를 바꿨어요."

    def upgrade_shelf(self, i):
        sh = self.shelves[i]
        if not sh:
            return False, "빈 자리예요."
        lv = sh.get("lv", 1)
        if lv >= 3:
            return False, "이미 최고 레벨이에요."
        cost, mats = D.SHELF_UP_COST[lv + 1]
        if self.gold < cost:
            return False, "보유금이 부족해요."
        if any(self.materials.get(m, 0) < n for m, n in mats.items()):
            return False, "재료가 부족해요: " + ", ".join(f"{D.MATS[m][0]} {n}" for m, n in mats.items())
        self.gold -= cost
        for m, n in mats.items():
            self.materials[m] -= n
        sh["lv"] = lv + 1
        self.stat("shelf_up")
        return True, f"{D.SHELF_TYPES[sh['type']][0]} Lv.{lv + 1}! 진열 칸 {self.shelf_cap(i)}칸"

    # ───────────── v1.0 브람 공방 ─────────────
    def bram_owned(self, k):
        g = self.gear
        return {"trap": False, "trap_iron": g["trap_iron"] >= D.TRAP_IRON_MAX, "totem1": g["totem"] >= 1, "totem2": g["totem"] >= 2,
                "pot": g["pot"] > 0, "board6": g["board"] >= 6, "board7": g["board"] >= 7, "hammer": g["hammer"] > 0}.get(k, False)

    def bram_can(self, k):
        name, price, ch, desc, pre = D.BRAM_SHOP[k]
        if self.chapter < ch:
            return False, f"{ch}장부터"
        if pre and not self.bram_owned(pre):
            return False, f"{D.BRAM_SHOP[pre][0]} 먼저"
        if self.bram_owned(k):
            return False, "보유 중"
        if self.gold < price:
            return False, "보유금 부족"
        return True, ""

    def buy_bram(self, k, n=1):
        ok, why = self.bram_can(k)
        if not ok:
            return False, why
        name, price, ch, desc, pre = D.BRAM_SHOP[k]
        if k == "trap":
            n = max(1, min(n, self.gold // price))
        else:
            n = 1
        self.gold -= price * n
        g = self.gear
        if k == "trap":
            g["trap"] += n
        elif k == "trap_iron":
            g["trap_iron"] += 1
        elif k in ("totem1", "totem2"):
            g["totem"] = 1 if k == "totem1" else 2
        elif k == "pot":
            g["pot"] = 1
        elif k in ("board6", "board7"):
            g["board"] = 6 if k == "board6" else 7
        elif k == "hammer":
            g["hammer"] = 1
        self.stat("bram_buys")
        return True, f"{name}{f' {n}개' if n > 1 else ''} 구매 (-{price * n:,}원)"

    def traps_owned(self):
        """가방에 있는 통발 + 강에 놓인 쇠 통발 수."""
        return self.gear["trap_iron"] + sum(1 for t in self.traps if t and t["kind"] == "trap_iron")

    def set_trap(self, i):
        if self.traps[i]:
            return False, "이미 통발이 있어요."
        if self.gear["trap"] > 0:
            kind = "trap"
        elif self.gear["trap_iron"] > 0:
            kind = "trap_iron"
        else:
            return False, "통발이 없어요. 브람 공방에서 사요."
        self.gear[kind] -= 1
        self.traps[i] = {"kind": kind, "day": self.day}
        return True, ("튼튼한 통발" if kind == "trap_iron" else "통발") + "을 놓았어요. 내일 걷으러 와요!"

    def trap_ready(self, i):
        t = self.traps[i]
        return bool(t) and self.day > t["day"]

    def pull_trap(self, i, rng=random):
        t = self.traps[i]
        if not t or self.day <= t["day"]:
            return None
        got = {}
        got["food:fish"] = rng.randint(1, 2)
        table = [(m, w) for m, w, ch in D.TRAP_LOOT if self.chapter >= ch]
        names = [m for m, w in table for _ in range(w)]
        rolls = 3 if t["kind"] == "trap_iron" else 2
        for _ in range(rolls):
            m = rng.choice(names)
            got[m] = got.get(m, 0) + (1 if m in ("shell", "jelly") else rng.randint(1, 2))
        if rng.random() < 0.2:
            got["shard"] = rng.randint(1, 2)
        for k, n in got.items():
            if k == "food:fish":
                self.add_food("fish", n)
            elif k == "shard":
                self.shards += n
            else:
                self.add_mat(k, n)
        if t["kind"] == "trap_iron":
            self.gear["trap_iron"] += 1
        self.traps[i] = None
        self.stat("traps_pulled")
        return got

    def totem_mult(self, spot):
        if self.totem_at is None or spot is None or self.totem_at != spot:
            return 1.0
        return D.TOTEM_BONUS.get(self.gear["totem"], 1.0)

    # ───────────── v1.0 마법 기력 ─────────────
    def pay_shot(self, boss=False):
        """마법 한 발의 기력. 쏠 수 있으면 True."""
        if boss:
            if self.energy < 1:
                return False
            self.energy -= 1
            return True
        if self.mana <= 0:
            if self.energy < 1:
                return False
            self.energy -= 1
            self.mana = D.MANA_PER_ENERGY
        self.mana -= 1
        return True

    # ───────────── v1.0 마도석 세공대 ─────────────
    @property
    def board_n(self):
        return self.gear.get("board", 5)

    def merge_cells(self):
        n = self.board_n
        return [r * 7 + c for r in range(n) for c in range(n)]

    def merge_empty(self):
        return [i for i in self.merge_cells() if self.merge[i] == 0]

    def merge_spawn(self, count=1, rng=random):
        made = 0
        for _ in range(count):
            empty = self.merge_empty()
            if self.shards <= 0 or not empty:
                break
            self.merge[rng.choice(empty)] = 1
            self.shards -= 1
            made += 1
        return made

    def merge_put_crystal(self, rng=random):
        empty = self.merge_empty()
        if self.materials.get("crystal", 0) <= 0:
            return False, "가방에 마력 조각이 없어요."
        if not empty:
            return False, "세공대에 빈칸이 없어요."
        self.materials["crystal"] -= 1
        self.merge[rng.choice(empty)] = 2
        return True, "마력 조각을 세공대에 올렸어요."

    def merge_move(self, a, b, rng=random):
        """a칸을 b칸으로. 같은 단계면 합치기. 결과 문자열 (없으면 None)."""
        if a == b or self.merge[a] == 0:
            return None
        ta, tb = self.merge[a], self.merge[b]
        if tb == 0:
            self.merge[b], self.merge[a] = ta, 0
            return "move"
        if ta == tb and ta < D.MERGE_MAX:
            nt = ta + 1
            bonus = False
            if self.gear.get("hammer") and nt < D.MERGE_MAX and rng.random() < 0.10:
                nt += 1
                bonus = True
            self.merge[b], self.merge[a] = nt, 0
            self.stat("merges")
            self.stat(f"merge_t{nt}")
            self.add_xp(nt)
            return "hammer" if bonus else "merge"
        self.merge[a], self.merge[b] = tb, ta
        return "swap"

    def merge_extract(self, a):
        t = self.merge[a]
        out = D.MERGE_TIERS.get(t, (None, None, None))[2]
        if not out:
            return False, "부스러기는 합쳐야 쓸 수 있어요."
        kind, k, n = out
        if kind == "mat":
            self.add_mat(k, n, xp=False)
            name = D.MATS[k][0]
        else:
            self.products[k] = self.products.get(k, 0) + n
            self.stat("craft_cat:stone", n)
            self.stat("gems_cut", n)
            name = D.PROD[k]["name"]
        self.merge[a] = 0
        return True, f"{name} {n}개를 얻었어요!"

    # ───────────── v1.0 요리 품질 ─────────────
    def dq(self, did):
        q = self.dishq.setdefault(did, [0, 0, 0])
        tot = self.dishes.get(did, 0)
        diff = tot - sum(q)
        if diff > 0:
            q[0] += diff
        while sum(q) > tot:
            for k in range(3):
                if q[k] > 0:
                    q[k] -= 1
                    break
        return q

    def best_q(self, did):
        q = self.dq(did)
        for k in (2, 1, 0):
            if q[k] > 0:
                return k + 1
        return 0

    def add_dish(self, did, quality=1):
        self.dq(did)
        self.dishes[did] = self.dishes.get(did, 0) + 1
        self.dishq[did][quality - 1] += 1
        if quality >= 3:
            self.stat("dish_star")

    def take_dish(self, did):
        q = self.best_q(did)
        if q == 0:
            return 0
        self.dishq[did][q - 1] -= 1
        self.dishes[did] -= 1
        return q

    def dish_energy(self, did, q):
        return max(1, round(D.DISH[did]["energy"] * D.COOK_Q[q][1]))

    # ───────────── 한스 · 노엘 ─────────────
    def refresh_hans(self):
        if self.hans_day != self.day:
            self.hans_day = self.day
            self.hans_stock = {m: q for m, (p, q) in D.HANS.items()}

    def hans_price(self, m):
        a = self.npc["hans"]["aff"]
        d = 0.10 if a >= 100 else 0.05 if a >= 50 else 0
        return int(D.HANS[m][0] * (1 - d))

    def buy_hans(self, m, n=1):
        self.refresh_hans()
        n = min(n, self.hans_stock.get(m, 0))
        cost = self.hans_price(m) * n
        if n <= 0:
            return False, "오늘 건 다 나갔다."
        if self.gold < cost:
            return False, "보유금이 부족해요."
        self.gold -= cost
        self.hans_stock[m] -= n
        self.add_mat(m, n, xp=False)
        self.stat("hans_buys")
        extra = ""
        if random.random() < 0.4:
            self.add_food("milk", 1)
            extra = " · 덤으로 신선 우유 1병!"
        return True, f"{D.MATS[m][0]} {n}개 구매 (-{cost:,}원){extra}"

    def sell_hans(self, m, n=1):
        n = min(n, self.materials.get(m, 0))
        if n <= 0:
            return False, "팔 재료가 없어요."
        gain = D.HANS[m][0] // 2 * n
        self.materials[m] -= n
        self.gold += gain
        return True, f"{D.MATS[m][0]} {n}개를 {gain:,}원에 팔았어요."

    def noel_here(self):
        return self.noel_met and self.day % 3 == 1 and 18 <= self.hour < 24

    def buy_tonic(self, tid):
        t = next(t for t in D.TONICS if t[0] == tid)
        if tid in self.tonics:
            return False, "이미 마신 물약이에요."
        if self.chapter < t[4]:
            return False, f"{t[4]}장부터 살 수 있어요."
        if self.gold < t[3]:
            return False, "보유금이 부족해요."
        self.gold -= t[3]
        self.tonics.append(tid)
        self.energy += t[2]
        return True, f"{t[1]}! 최대 기력 +{t[2]}"

    # ───────────── 단골 ─────────────
    def met_npcs(self):
        return [k for k in D.NPC_ORDER if self.npc[k]["met"]]

    def add_aff(self, k, n):
        self.npc[k]["aff"] = max(0, min(100, self.npc[k]["aff"] + n))

    def quest_available(self, k):
        n = self.npc[k]
        return k in D.QUESTS and n["met"] and n["quest"] == "none" and self.chapter >= D.NPCS[k]["quest_ch"] and n["aff"] >= 30

    def quest_ready(self, k):
        q = D.QUESTS[k]
        if self.npc[k]["quest"] != "active":
            return False
        if q.get("boss") and not self.flags.get("boss_down"):
            return False
        if q.get("page") and not self.flags.get("page_found"):
            return False
        if q.get("dew") and not self.flags.get("dew"):
            return False
        if any(self.products.get(p, 0) < n for p, n in q["need"].items()):
            return False
        if any(self.materials.get(m, 0) < n for m, n in q.get("need_mats", {}).items()):
            return False
        return True

    def finish_quest(self, k):
        q = D.QUESTS[k]
        for p, n in q["need"].items():
            self.products[p] -= n
        for m, n in q.get("need_mats", {}).items():
            self.materials[m] -= n
        self.npc[k]["quest"] = "done"
        self.add_aff(k, 30)
        if q["deco"] not in self.deco_owned:
            self.deco_owned.append(q["deco"])
        self.stat("quests_done")
        self.stat("quest:" + k)
        self.add_xp(80)

    def friends50(self):
        return sum(1 for k in D.NPC_ORDER if self.npc[k]["aff"] >= 50)

    # ───────────── 목표 · 장 ─────────────
    def goal_value(self, key):
        if key == "rep":
            return self.rep
        if key == "friends50":
            return self.friends50()
        if key == "visited":
            return len(self.first_visits)
        if key == "market_done":
            return 1 if self.market["done"] else 0
        return self.stats.get(key, 0)

    def goals_done(self, ch):
        return all(self.goal_value(k) >= n for _, k, n in D.GOALS.get(ch, []))

    def claim_goals(self, ch):
        if ch in self.goals_claimed or not self.goals_done(ch):
            return None
        self.goals_claimed.append(ch)
        name, gold = D.GOAL_REWARD[ch]
        self.gold += gold
        if ch == 1:
            self.buy_shelf("goods", free=True)
            self.noel_met = True
        elif ch == 2:
            self.plot_count = min(8, self.plot_count + 2)
        elif ch == 3:
            self.gear["totem"] = max(1, self.gear.get("totem", 0))
        elif ch == 4:
            self.buy_shelf("stone", free=True)
        elif ch == 6 and "tapestry" not in self.deco_owned:
            self.deco_owned.append("tapestry")
        return name

    def next_chapter_due(self):
        """누적 매출로 열려야 하는 다음 장 번호 (없으면 None).
        v0.8: 하룻밤에 한 장씩만 열리고, 마지막 장(7)은 달빛 장터를 마친 뒤에만 열려요."""
        nxt = self.chapter + 1
        for num, _, need in D.CHAPTERS:
            if num == nxt and self.total_revenue >= need:
                if num == 7 and not self.market["done"]:
                    return None
                return num
        return None

    # ───────────── 루나 레벨 · 마법 ─────────────
    @property
    def luna_level(self):
        return max(1, min(10, self.luna // 10))

    @property
    def magic_tier(self):
        """지금 쓸 수 있는 마법 단계 번호 (0~3)."""
        lv = self.luna_level
        return max(i for i, t in enumerate(D.MAGIC_TIERS) if lv >= t[0])

    def shot_damage(self):
        return D.MONSTER_HP // D.MAGIC_TIERS[self.magic_tier][2]

    # ───────────── 우편함 · 버들골 소포 ─────────────
    def unread_mail(self):
        return sum(1 for m in self.mail if not m["read"])

    def post_letter(self, sp, line, kind="letter"):
        self.mail.append({"kind": kind, "sp": sp, "line": line, "day": self.day, "read": False})

    def refresh_parcels(self, rng=random):
        if not self.flags.get("neighbor"):
            return
        if self.parcels and self.day - self.parcels_day < 2 and any(not o["done"] for o in self.parcels):
            return
        import story_extra as E
        self.parcels_day = self.day
        self.parcels = []
        pool = [p for p in D.PROD_ORDER if self.unlocked(p) and D.PROD[p]["unlock"] != "luna60"]
        for _ in range(2):
            kinds = rng.sample(pool, min(len(pool), rng.choice([2, 2, 3])))
            items = {p: 1 for p in kinds}
            cells = lambda: sum(len(D.PACK_SHAPES[D.PROD[p]["cat"]]) * n for p, n in items.items())
            target = rng.randint(9, 14)           # 상자 칸 수 (퍼즐 크기)
            while cells() < target:
                p = rng.choice([p for p in kinds if items[p] < 3] or kinds)
                if items[p] >= 3:
                    break
                items[p] += 1
            reward = int(sum(D.PROD[p]["price"] * n for p, n in items.items()) * D.PACK_REWARD / 100) * 100
            first = D.PROD[kinds[0]]["name"]
            self.parcels.append({"sender": rng.choice(E.NEIGHBOR["senders"]), "note": rng.choice(E.NEIGHBOR["notes"]).format(item=first),
                                 "items": items, "reward": reward, "done": False})

    def parcel_ready(self, i):
        o = self.parcels[i]
        return not o["done"] and all(self.products.get(p, 0) >= n for p, n in o["items"].items())

    def ship_parcel(self, i, bonus=0.0):
        o = self.parcels[i]
        for p, n in o["items"].items():
            self.products[p] -= n
        o["done"] = True
        pay = int(o["reward"] * (1 + bonus) / 10) * 10
        self.gold += pay
        self.total_revenue += pay
        self.log["revenue"] += pay
        self.stat("parcels_done")
        self.add_xp(pay // 400)
        return pay

    # ───────────── 의뢰 게시판 ─────────────
    def refresh_orders(self, rng=random):
        if self.chapter < 5:
            return
        if self.orders and self.day - self.orders_day < 3 and any(not o["done"] for o in self.orders):
            return
        self.orders_day = self.day
        self.orders = []
        people = self.met_npcs() or D.NPC_ORDER[:1]
        rng.shuffle(people)
        for k in people[:3]:
            likes = D.NPCS[k]["likes"]
            pool = [p for p in D.PROD_ORDER if self.unlocked(p) and D.PROD[p]["unlock"] != "luna60"]
            liked = [p for p in pool if D.PROD[p]["cat"] in likes]
            pid = rng.choice(liked if liked and rng.random() < 0.7 else pool)
            qty = rng.randint(3, 6)
            self.orders.append({"npc": k, "pid": pid, "qty": qty, "reward": int(D.PROD[pid]["price"] * qty * 1.25), "done": False})

    def fulfill_order(self, i):
        o = self.orders[i]
        if o["done"] or self.products[o["pid"]] < o["qty"]:
            return False, "제품이 모자라요."
        self.products[o["pid"]] -= o["qty"]
        o["done"] = True
        self.gold += o["reward"]
        self.total_revenue += o["reward"]
        self.log["revenue"] += o["reward"]
        self.add_aff(o["npc"], 3)
        self.stat("orders_done")
        self.add_xp(o["reward"] // 400)
        return True, f"납품 완료! +{o['reward']:,}원"

    # ───────────── 하루 넘기기 ─────────────
    def sleep(self, rng=random):
        """다음 날 아침으로. 로그는 호출 전에 가져가야 한다."""
        greenhouse = "greenhouse" in self.rooms
        for i, p in enumerate(self.plots[: self.plot_count]):
            if p["crop"] and p["watered"]:
                p["days"] += 1
                if greenhouse and p["crop"] == "moonherb":
                    p["days"] += 1
            p["watered"] = False
        # 공방 자동 제작
        msgs = []
        if "workshop" in self.rooms and self.workshop_recipe and self.max_craft(self.workshop_recipe) > 0:
            ok, m = self.craft(self.workshop_recipe, 1)
            msgs.append("공방: " + m)
        if "terrace" in self.rooms and self.materials["herb"] > 0 and self.materials["starflower"] > 0:
            self.materials["herb"] -= 1
            self.materials["starflower"] -= 1
            self.gold += 6000
            self.total_revenue += 6000
            msgs.append("테라스 찻집 음료 매출 +6,000원")
        self.day += 1
        self.hour = D.DAY_START
        self.energy = self.max_energy
        self.luna_petted = False
        self.luna_snacks = 0
        self.eaten_today = 0
        if rng.random() < 0.25:
            self.food["milk"] += 1
            msgs.append("문 앞에 이웃이 두고 간 신선 우유가 한 병 있어요.")
        for n in self.npc.values():
            n.pop("visited", None)
        # v0.8 우편함: 부모님 편지 (3일마다) · 버들골 첫 편지
        import story as S, story_extra as E
        if self.day - self.last_letter_day >= D.LETTER_EVERY and self.day >= 3:
            letters = S.LETTERS + E.LETTERS_EXTRA
            sp, line = letters[self.letters_read % len(letters)]
            self.letters_read += 1
            self.last_letter_day = self.day
            self.post_letter(sp, line)
            msgs.append("우편함에 집에서 온 편지가 도착했어요. (저택 앞 우편함)")
        if self.total_revenue >= D.NEIGHBOR_AT and not self.flags.get("neighbor_mail"):
            self.flags["neighbor_mail"] = True
            self.post_letter("ursula", "", kind="neighbor")
            msgs.append("우편함에 낯선 마을 도장이 찍힌 편지가 도착했어요!")
        self.refresh_parcels(rng)
        if self.luna >= 60:
            m = rng.choice(["herb", "starflower", "scale", "berry", "wool"])
            self.add_mat(m, 2, xp=False)
            msgs.append(f"루나가 {D.MATS[m][0]} 2개를 물어 왔어요.")
        self.new_day_log()
        return msgs

    # ───────────── 요리 ─────────────
    def add_food(self, f, n=1):
        self.food[f] = self.food.get(f, 0) + n
        self.stat("food_got", n)

    def max_cook(self, did):
        need = D.DISH[did]["need"]
        return min(self.food.get(f, 0) // n for f, n in need.items())

    def cook_take(self, did):
        """요리 재료를 먼저 써요 (냄비 젓기를 시작할 때)."""
        if self.max_cook(did) <= 0:
            return False
        for f, n in D.DISH[did]["need"].items():
            self.food[f] -= n
        return True

    def cook_finish(self, did, quality=1):
        self.add_dish(did, quality)
        self.stat("cooked")
        self.add_xp(4 + 2 * (quality - 1))
        qn = D.COOK_Q[quality]
        return f"{D.DISH[did]['name']} 완성!" + (f" ({qn[3]} {qn[0]} 품질)" if quality > 1 else "")

    def cook(self, did, quality=1):
        if not self.cook_take(did):
            return False, "요리 재료가 부족해요."
        return True, self.cook_finish(did, quality)

    def eat(self, did):
        if self.dishes.get(did, 0) <= 0:
            return False, "요리가 없어요."
        if self.eaten_today >= D.EAT_PER_DAY:
            return False, f"오늘은 배불러요. (하루 {D.EAT_PER_DAY}번)"
        if self.energy >= self.max_energy:
            return False, "기력이 이미 가득해요."
        q = self.take_dish(did)
        gain = min(self.dish_energy(did, q), self.max_energy - self.energy)
        self.energy += gain
        self.eaten_today += 1
        qn = D.COOK_Q[q]
        return True, f"{qn[3]}{D.DISH[did]['name']}을(를) 먹었어요. 기력 +{gain}"

    # ───────────── 저장 ─────────────
    def to_json(self):
        d = dict(self.__dict__)
        return d

    def save(self):
        try:
            p = save_dir() / SAVE_NAME
            tmp = p.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.to_json(), ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, p)
            web_persist(p)
            return True
        except Exception:
            return False

    @classmethod
    def load(cls):
        p = save_dir() / SAVE_NAME
        if not p.exists():
            return None
        try:
            raw = json.loads(p.read_text(encoding="utf-8"))
            s = cls()
            for k, v in raw.items():
                if hasattr(s, k):
                    setattr(s, k, v)
            for m in D.MAT_ORDER:
                s.materials.setdefault(m, 0)
            for pid in D.PROD_ORDER:
                s.products.setdefault(pid, 0)
            for f in D.FOOD_ORDER:
                s.food.setdefault(f, 0)
            for d in D.DISH_ORDER:
                s.dishes.setdefault(d, 0)
            # v1.0 이전 저장 채우기
            for k in list(D.NPC_ORDER) + ["cecilia", "noel", "bram"]:
                s.npc.setdefault(k, {"aff": 0, "met": False, "talked": -1, "quest": "none", "seen": []})
            base = State()
            for k, v in base.gear.items():
                s.gear.setdefault(k, v)
            if len(s.merge) < 49:
                s.merge = (list(s.merge) + [0] * 49)[:49]
            if len(s.traps) < 3:
                s.traps = (list(s.traps) + [None] * 3)[:3]
            for sh in s.shelves:
                if sh:
                    sh.setdefault("lv", 1)
            if s.flags.pop("rod", None):        # 낚싯대 업그레이드 → 낚시 토템
                s.gear["totem"] = max(1, s.gear["totem"])
            if "mail" not in raw and s.letters_read:     # v0.7 이전 저장: 이미 읽은 편지를 우편함에 '읽음'으로 채움
                import story as S, story_extra as E
                letters = S.LETTERS + E.LETTERS_EXTRA
                for i in range(min(s.letters_read, len(letters))):
                    sp, line = letters[i]
                    s.mail.append({"kind": "letter", "sp": sp, "line": line, "day": (i + 1) * 3, "read": True})
                s.last_letter_day = s.day
            return s
        except Exception:
            return None

# -*- coding: utf-8 -*-
"""UI 그리기 도우미 — Humble Pixel 'Paper UI System'(종이 UI) 조각으로 창 · 버튼 · 리본을 조립한다.
조각은 assets/ui/paper/ 에 있고, 초록 장식은 게임 톤(라벤더)으로 바꿔 두었다."""
import math
import pygame as pg
import assets as A

INK = (62, 42, 36)
INK_SOFT = (100, 80, 68)
PAPER = (236, 221, 192)
PAPER_DARK = (218, 202, 170)
LINE = (180, 167, 148)
WOOD = (122, 80, 50)
WOOD_DARK = (70, 44, 30)
WOOD_LIGHT = (168, 116, 72)
GOLD = (232, 182, 74)
LAV = (132, 100, 190)
LAV_DARK = (84, 60, 120)
CREAM = (255, 246, 226)
GREEN = (96, 160, 90)
RED = (176, 42, 54)
NIGHT = (34, 26, 48)
PLUM = (58, 36, 70)

SCALE = 2          # 종이 조각 확대 배율 (32px 조각 → 64px)
_panel_cache = {}


def P(name, scale=SCALE):
    return A.pix("ui/paper/" + name, scale)


def _tile(n, dark=False):
    return A.raw(f"ui/paper/paper_{n + (17 if dark else 0)}")


def build_paper(w, h, dark=False, border=True, back=True, night=False):
    """종이 한 장(+뒤에 비스듬한 종이)을 1배율로 조립한 뒤 SCALE배 최근접 확대."""
    key = (w, h, dark, border, back, night)
    if key in _panel_cache:
        return _panel_cache[key]
    s = SCALE
    nw, nh = max(40, w // s), max(40, h // s)
    pad = 6 if back else 0
    base = pg.Surface((nw + pad * 2, nh + pad * 2), pg.SRCALPHA)

    def sheet(dk):
        surf = pg.Surface((nw, nh), pg.SRCALPHA)
        c = 16   # 모서리 조각 크기(원본 32px 중 가장자리 16px 사용)
        tiles = [_tile(i, dk) for i in range(1, 10)]
        # 가운데 채우기
        mid = pg.transform.scale(tiles[4].subsurface((8, 8, 16, 16)), (nw - 2 * c, nh - 2 * c))
        surf.blit(mid, (c, c))
        # 네 변
        top = tiles[1].subsurface((0, 0, 32, c))
        bot = tiles[7].subsurface((0, 32 - c, 32, c))
        lef = tiles[3].subsurface((0, 0, c, 32))
        rig = tiles[5].subsurface((32 - c, 0, c, 32))
        surf.blit(pg.transform.scale(top, (nw - 2 * c, c)), (c, 0))
        surf.blit(pg.transform.scale(bot, (nw - 2 * c, c)), (c, nh - c))
        surf.blit(pg.transform.scale(lef, (c, nh - 2 * c)), (0, c))
        surf.blit(pg.transform.scale(rig, (c, nh - 2 * c)), (nw - c, c))
        # 모서리
        surf.blit(tiles[0].subsurface((0, 0, c, c)), (0, 0))
        surf.blit(tiles[2].subsurface((32 - c, 0, c, c)), (nw - c, 0))
        surf.blit(tiles[6].subsurface((0, 32 - c, c, c)), (0, nh - c))
        surf.blit(tiles[8].subsurface((32 - c, 32 - c, c, c)), (nw - c, nh - c))
        return surf

    if back:
        b = sheet(True)
        b = pg.transform.rotate(b, -1.6)
        base.blit(b, (pad + 3 - (b.get_width() - nw) // 2, pad + 4 - (b.get_height() - nh) // 2))
    front = sheet(dark)
    if border:
        o = 17 if dark else 0
        tl, tr, br, bl = (A.raw(f"ui/paper/paper_{n + o}") for n in (11, 13, 15, 17))
        line_l = A.raw(f"ui/paper/paper_{10 + o}")
        line_t = A.raw(f"ui/paper/paper_{12 + o}")
        # 테두리 선 (조각 안의 선 위치를 찾아 늘림)
        inset = 6
        col = LINE if not dark else (150, 130, 110)
        pg.draw.rect(front, col, (inset, inset, nw - 2 * inset, nh - 2 * inset), 1)
        # 장식 모서리 (원본 32px 조각 → 모서리에 맞춰 붙임)
        for img, (x, y) in ((tl, (0, 0)), (tr, (nw - 32, 0)), (br, (nw - 32, nh - 32)), (bl, (0, nh - 32))):
            front.blit(img, (x, y))
    base.blit(front, (pad, pad))
    if night:
        ov = pg.Surface(base.get_size(), pg.SRCALPHA)
        ov.fill((200, 205, 255, 255))
        base.blit(ov, (0, 0), special_flags=pg.BLEND_RGBA_MULT)
    out = pg.transform.scale(base, (base.get_width() * s, base.get_height() * s))
    res = (out, pad * s)
    _panel_cache[key] = res
    return res


class UI:
    def __init__(self):
        self.click = None
        self.mouse = (0, 0)
        self.hovered = None
        self.sound = None        # 게임이 audio.play 연결

    def begin(self, mouse):
        self.mouse = mouse

    def end(self):
        self.click = None

    def _sfx(self, name):
        if self.sound:
            self.sound(name)

    # ───────── 창 ─────────
    def frame(self, surf, rect, style="paper", radius=14):
        rect = pg.Rect(rect)
        name = f"ui/frame_{style}"
        if A.exists(name):   # 사용자가 넣은 9-slice 프레임이 있으면 우선
            nine_slice(surf, A.image(name), rect, 24)
            return rect.inflate(-28, -28)
        dark = style in ("cork",)
        night = style in ("dark",)
        img, pad = build_paper(rect.w, rect.h, dark=dark, night=night)
        surf.blit(img, (rect.x - pad, rect.y - pad))
        return rect.inflate(-34, -30)

    def note(self, surf, rect, dark=False):
        """작은 메모지 (테두리 장식 없이)."""
        rect = pg.Rect(rect)
        img, pad = build_paper(rect.w, rect.h, dark=dark, border=False, back=False)
        surf.blit(img, (rect.x - pad, rect.y - pad))
        return rect.inflate(-20, -16)

    # ───────── 버튼 ─────────
    def button(self, surf, rect, label, enabled=True, primary=False, size=18, key=None, icon=None):
        rect = pg.Rect(rect)
        hover = rect.collidepoint(self.mouse) and enabled
        draw_button(surf, rect, primary, enabled, hover)
        fg = CREAM if (primary and enabled) else (INK if enabled else (160, 146, 130))
        x = rect.centerx
        if icon:
            ic = globals()["icon"](icon, 24, CREAM if (primary and enabled) else INK)
        f = A.font(size, True)
        t = f.render(label, False, fg)
        if t.get_width() > rect.w - 12:
            t = pg.transform.scale(t, (rect.w - 12, t.get_height()))
        tw = t.get_width() + (28 if icon else 0)
        x0 = rect.centerx - tw // 2
        if icon:
            surf.blit(ic, (x0, rect.centery - 12 + (1 if hover else 0)))
            x0 += 28
        surf.blit(t, (x0, rect.centery - t.get_height() // 2 + (1 if hover else 0)))
        if enabled and self.click and rect.collidepoint(self.click):
            self.click = None
            self._sfx("click")
            return True
        return False

    def hit(self, rect):
        if self.click and pg.Rect(rect).collidepoint(self.click):
            self.click = None
            self._sfx("click")
            return True
        return False


def tint(img, col):
    """알파는 두고 색만 col로 바꿈."""
    out = img.copy()
    out.fill((0, 0, 0, 255), special_flags=pg.BLEND_RGBA_MULT)
    out.fill((*col[:3], 0), special_flags=pg.BLEND_RGBA_ADD)
    return out


_btn_cache = {}


def draw_button(surf, rect, primary=False, enabled=True, hover=False):
    """Paper UI 'Sliced 10' 조각(위아래 라벤더 띠가 있는 종이 칸)을 가로로 늘려 버튼을 만든다."""
    key = (rect.w, rect.h, primary, enabled, hover)
    if key not in _btn_cache:
        src = A.raw("ui/paper/btn_10")          # 16x16
        s = 2 if rect.h < 44 else 3
        nw, nh = max(8, rect.w // s), max(8, rect.h // s)
        b = pg.Surface((nw, nh), pg.SRCALPHA)
        # 3x3 조각 (4px 모서리)
        c = 4
        parts = {}
        for i, sx in enumerate((0, c, 16 - c)):
            for j, sy in enumerate((0, c, 16 - c)):
                sw = c if i != 1 else 16 - 2 * c
                sh = c if j != 1 else 16 - 2 * c
                if i == 2:   # 원본은 오른쪽 테두리가 없는 조각이라 왼쪽을 뒤집어 씀
                    parts[(i, j)] = pg.transform.flip(src.subsurface((0, sy, c, sh)), True, False)
                else:
                    parts[(i, j)] = src.subsurface((sx, sy, sw, sh))
        xs = [(0, c), (c, nw - 2 * c), (nw - c, c)]
        ys = [(0, c), (c, nh - 2 * c), (nh - c, c)]
        for i in range(3):
            for j in range(3):
                b.blit(pg.transform.scale(parts[(i, j)], (xs[i][1], ys[j][1])), (xs[i][0], ys[j][0]))
        if primary:
            fill = pg.Surface((nw - 2, nh - 2 * c + 2), pg.SRCALPHA)
            fill.fill((*((150, 118, 206) if hover else LAV), 255) if enabled else (190, 180, 190, 255))
            b.blit(fill, (1, c - 1))
        elif hover:
            fill = pg.Surface((nw - 2, nh - 2 * c), pg.SRCALPHA)
            fill.fill((248, 236, 212, 255))
            b.blit(fill, (1, c))
        if not enabled:
            g = pg.Surface((nw, nh), pg.SRCALPHA)
            g.fill((150, 140, 140, 90))
            b.blit(g, (0, 0), special_flags=pg.BLEND_RGBA_MULT if False else 0)
        img = pg.transform.scale(b, (nw * s, nh * s))
        _btn_cache[key] = img
    img = _btn_cache[key]
    y = rect.y + (1 if hover else 0)
    sh = pg.Surface((img.get_width(), 4), pg.SRCALPHA)
    sh.fill((60, 40, 30, 60))
    surf.blit(sh, (rect.x + 2, rect.y + img.get_height()))
    surf.blit(img, (rect.x, y))


# ───────── 리본 · 뱃지 · 슬롯 ─────────
def ribbon(surf, center, text, size=24, width=None, which="header_4"):
    """리본 머리띠 (Paper UI Headers). 가운데를 늘려 글자 폭에 맞춘다."""
    src = A.raw("ui/paper/" + which)
    f = A.font(size, True)
    t = f.render(text, False, INK)
    sw, sh = src.get_size()
    edge = int(sw * 0.2)
    target_h = max(56, t.get_height() + 44)
    sc = target_h / sh
    need = (width or t.get_width() + 60)
    mid_w = max(10, int(need / sc) - 2 * edge + 40)
    nat = pg.Surface((edge * 2 + mid_w, sh), pg.SRCALPHA)
    nat.blit(src.subsurface((0, 0, edge, sh)), (0, 0))
    nat.blit(pg.transform.scale(src.subsurface((edge, 0, sw - 2 * edge, sh)), (mid_w, sh)), (edge, 0))
    nat.blit(src.subsurface((sw - edge, 0, edge, sh)), (edge + mid_w, 0))
    img = pg.transform.scale(nat, (int(nat.get_width() * sc), target_h))
    x, y = center
    surf.blit(img, (x - img.get_width() // 2, y - img.get_height() // 2))
    bb = t.get_bounding_rect()     # 글자 실제 모양 기준으로 가운데 맞춤
    surf.blit(t, (x - t.get_width() // 2, y - int(target_h * 0.095) - bb.y - bb.h // 2))
    return img.get_rect(center=center)


def keycap(surf, pos, label, size=12):
    """작은 키보드 키 모양 뱃지."""
    f = A.font(size, True)
    t = f.render(label, False, INK)
    w = max(20, t.get_width() + 10)
    h = t.get_height() + 6
    x, y = pos
    r = pg.Rect(x - w // 2, y, w, h)
    pg.draw.rect(surf, (120, 100, 90), r.move(0, 2), border_radius=3)
    pg.draw.rect(surf, (250, 242, 222), r, border_radius=3)
    pg.draw.rect(surf, INK, r, 1, border_radius=3)
    surf.blit(t, (r.centerx - t.get_width() // 2, r.y + 3))
    return r


def slot(surf, rect, hover=False, active=False):
    img = A.raw("ui/paper/holder_5")   # 32x32 모서리 홈 사각형
    r = pg.Rect(rect)
    im = pg.transform.scale(img, r.size)
    surf.blit(im, r.topleft)
    if hover or active:
        hl = pg.Surface(r.inflate(-12, -12).size, pg.SRCALPHA)
        hl.fill((132, 100, 190, 50 if hover else 30))
        surf.blit(hl, r.inflate(-12, -12).topleft)


def paper_bar(surf, rect, frac, kind="red"):
    """Paper UI 진행 막대 조각(16px)으로 막대를 그린다. kind: red / orange."""
    r = pg.Rect(rect)
    n0 = {"red": 1, "orange": 4}[kind]
    # 빈 틀(초록→라벤더 테두리 6~8번)
    for i, (n, w) in enumerate(((6, 16), (7, None), (8, 16))):
        pass
    h = r.h
    s = h / 16
    def piece(n, w):
        return pg.transform.scale(A.raw(f"ui/paper/bar_{n}"), (w, h))
    # 틀
    surf.blit(piece(6, int(16 * s)), (r.x, r.y))
    surf.blit(piece(7, max(1, r.w - int(32 * s))), (r.x + int(16 * s), r.y))
    surf.blit(piece(8, int(16 * s)), (r.right - int(16 * s), r.y))
    fw = int(r.w * max(0, min(1, frac)))
    if fw > 4:
        clip = surf.get_clip()
        surf.set_clip(pg.Rect(r.x, r.y, fw, h).clip(clip) if clip else pg.Rect(r.x, r.y, fw, h))
        surf.blit(piece(n0, int(16 * s)), (r.x, r.y))
        surf.blit(piece(n0 + 1, max(1, r.w - int(32 * s))), (r.x + int(16 * s), r.y))
        surf.blit(piece(n0 + 2, int(16 * s)), (r.right - int(16 * s), r.y))
        surf.set_clip(clip)


def nine_slice(surf, img, rect, m):
    w, h = img.get_size()
    rect = pg.Rect(rect)
    src = [(0, m), (m, w - 2 * m), (w - m, m)]
    srcy = [(0, m), (m, h - 2 * m), (h - m, m)]
    dst = [(rect.left, m), (rect.left + m, rect.w - 2 * m), (rect.right - m, m)]
    dsty = [(rect.top, m), (rect.top + m, rect.h - 2 * m), (rect.bottom - m, m)]
    for i in range(3):
        for j in range(3):
            part = img.subsurface((src[i][0], srcy[j][0], src[i][1], srcy[j][1]))
            if dst[i][1] > 0 and dsty[j][1] > 0:
                surf.blit(pg.transform.scale(part, (dst[i][1], dsty[j][1])), (dst[i][0], dsty[j][0]))


def wrap(text, f, width):
    lines = []
    for para in text.split("\n"):
        cur = ""
        for ch in para:
            if f.size(cur + ch)[0] > width and cur:
                sp = cur.rfind(" ")
                if sp > len(cur) * 0.5:
                    lines.append(cur[:sp])
                    cur = cur[sp + 1:] + ch
                else:
                    lines.append(cur)
                    cur = ch
            else:
                cur += ch
        lines.append(cur)
    return lines


def text(surf, s, pos, size=18, color=INK, bold=False, center=False, width=None, right=False, line_gap=4):
    f = A.font(size, bold)
    lines = wrap(s, f, width) if width else [s]
    x, y = pos
    for ln in lines:
        t = f.render(ln, False, color)
        if center:
            surf.blit(t, (x - t.get_width() // 2, y))
        elif right:
            surf.blit(t, (x - t.get_width(), y))
        else:
            surf.blit(t, (x, y))
        y += f.get_linesize() + line_gap - 2
    return y


def outlined(surf, s, pos, size=16, color=CREAM, outline=(40, 26, 30), center=True, bold=True):
    f = A.font(size, bold)
    t = f.render(s, False, color)
    o = f.render(s, False, outline)
    x, y = pos
    if center:
        x -= t.get_width() // 2
    for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2), (-1, -1), (1, 1), (-1, 1), (1, -1)):
        surf.blit(o, (x + dx, y + dy))
    surf.blit(t, (x, y))


def bar(surf, rect, frac, color, back=(226, 210, 182)):
    """픽셀 막대 (종이 톤 틀 + 색 채움)."""
    r = pg.Rect(rect)
    pg.draw.rect(surf, back, r)
    fw = int((r.w - 4) * max(0, min(1, frac)))
    if fw > 0:
        pg.draw.rect(surf, color, (r.x + 2, r.y + 2, fw, r.h - 4))
        hi = tuple(min(255, c + 40) for c in color[:3])
        pg.draw.rect(surf, hi, (r.x + 2, r.y + 2, fw, max(1, (r.h - 4) // 3)))
    pg.draw.rect(surf, INK, r, 2)

def pill(surf, rect, s, bg=(70, 52, 92), fg=CREAM, size=14):
    """작은 이름표 — 종이 쪽지 모양."""
    rect = pg.Rect(rect)
    pg.draw.rect(surf, (120, 100, 86), rect.move(0, 2), border_radius=4)
    pg.draw.rect(surf, (246, 234, 208), rect, border_radius=4)
    pg.draw.rect(surf, bg, (rect.x, rect.y, 5, rect.h), border_top_left_radius=4, border_bottom_left_radius=4)
    pg.draw.rect(surf, (150, 130, 110), rect, 1, border_radius=4)
    t = A.font(size, True).render(s, False, INK)
    surf.blit(t, (rect.centerx - t.get_width() // 2 + 2, rect.centery - t.get_height() // 2))


def heart(surf, center, r, color=(236, 90, 130)):
    """Paper UI 하이라이터 하트 (가득 / 흐림)."""
    full = color[0] > 220 and color[1] < 120
    img = A.raw("ui/paper/hl_7" if full else "ui/paper/hl_8")
    sz = max(12, int(r * 2.2))
    im = pg.transform.scale(img, (sz, sz))
    surf.blit(im, (center[0] - sz // 2, center[1] - sz // 2))


def tag(surf, rect, fill=PAPER, edge=(120, 96, 78), inner=True, shadow=True):
    """작은 종이 딱지 (Paper UI 색·선 두께를 따라 픽셀 모서리를 깎은 사각형). 높이가 낮은 알림용."""
    r = pg.Rect(rect)
    if shadow:
        sh = pg.Surface((r.w, r.h), pg.SRCALPHA)
        sh.fill((40, 24, 30, 70))
        surf.blit(sh, (r.x + 3, r.y + 4))
    # 깎은 모서리: 2px 단위 계단
    pg.draw.rect(surf, edge, r.inflate(-4, 0))
    pg.draw.rect(surf, edge, r.inflate(0, -4))
    pg.draw.rect(surf, fill, r.inflate(-4, -4).inflate(-2, 2))
    pg.draw.rect(surf, fill, r.inflate(-4, -4).inflate(2, -2))
    if inner and r.h >= 26:
        pg.draw.rect(surf, LINE, r.inflate(-10, -10), 2)
    return r.inflate(-12, -8)


PX_ICON = {"bag": "backpack", "scroll": "script", "letter": "users", "plant": "sofa", "help": "circle-question",
           "cog": "settings-cog", "coins": "coins", "heart": "heart", "crown": "trophy", "moon": "moon", "save": "save",
           "house": "home", "exit": "logout", "book": "book-open", "newbook": "sparkles", "fish": "fish", "star": "star",
           "search": "search", "gift": "gift", "potion": "potion", "map": "map", "music": "music", "leaf": "leaf"}
# v1.2: GPT 일러스트 UI 아이콘 (assets/icons/ui_*.png, 128px)
UI_ICON = {"bag": "bag", "scroll": "goals", "letter": "people", "plant": "decorate", "help": "help", "cog": "menu",
           "coins": "coin", "heart": "heart", "fame": "fame", "crown": "crown", "mana": "mana", "newbook": "newgame",
           "save": "save", "exit": "quit", "house": "shop", "leaf": "gather", "fish": "fish",
           "package": "package"}
GRAYS = {(150, 140, 130), (140, 130, 120), (190, 180, 170), (175, 165, 160)}


def _gray(img):
    """못 쓰는 상태: 회색 + 살짝 밝게 + 반투명 (numpy 없이)."""
    g = pg.transform.grayscale(img)
    g.fill((50, 46, 42, 0), special_flags=pg.BLEND_RGBA_ADD)
    g.fill((255, 255, 255, 190), special_flags=pg.BLEND_RGBA_MULT)
    return g


def icon(name, size, col=None):
    """UI 아이콘. v1.2 일러스트(ui_*)가 있으면 그것을 부드럽게 축소(흐린 색이면 회색 처리),
    없으면 pixelarticons(24px 픽셀 아이콘, MIT) → game-icons 순서."""
    key = ("icon", name, size, col)
    if key in A._cache:
        return A._cache[key]
    ui = UI_ICON.get(name)
    if ui and A.exists("icons/ui_" + ui):
        img = pg.transform.smoothscale(A.raw("icons/ui_" + ui), (size, size))
        if col in GRAYS:
            img = _gray(img)
        A._cache[key] = img
        return img
    if name == "package":                     # v1.4 소포 일러스트가 없을 때: 예전 도트
        img = A.pix("decor/package", 2)
        A._cache[key] = img
        return img
    if name == "fame":
        name = "crown"
    px = PX_ICON.get(name)
    if px and A.exists("icons/px_" + px):
        img = A.raw("icons/px_" + px)
        k = max(1, round(size / 24))
        img = pg.transform.scale(img, (24 * k, 24 * k))
    else:
        img = A.pix("icons/" + name, 1)
        if img.get_width() != size:
            img = pg.transform.scale(img, (size, size))
    img = tint(img, col) if col else img
    A._cache[key] = img
    return img

# -*- coding: utf-8 -*-
"""터치 조작 (v1.6 웹·모바일용).

화면 왼쪽 아래: 가상 조이스틱 (끝까지 밀면 달리기)
화면 오른쪽: 사용(E) · 영업(O) · 루나(H) · 마법(Space, 꾹) · 빨리 감기(Z, 켜기/끄기)

손가락 이벤트(FINGERDOWN/MOTION/UP)로 여러 손가락을 동시에 받는다.
PC 브라우저에서 마우스로 눌러도 똑같이 움직이게 해 두었다.
"""
import math, sys
import pygame as pg
import assets as A
import ui as U

V = pg.Vector2
WEB = sys.platform == "emscripten"

STICK_HOME = V(150, 626)      # 조이스틱 기본 위치
STICK_R = 84                  # 조이스틱 반지름
STICK_ZONE = pg.Rect(0, 380, 560, 420)   # 이 안을 누르면 조이스틱이 그 자리에 생김
RUN_AT = 0.92                 # 이만큼 밀면 달리기


class Touch:
    def __init__(self, g):
        self.g = g
        self.enabled = WEB
        self.used = False             # 한 번이라도 터치했는지 (안내 문구용)
        self.stick_id = None
        self.base = V(STICK_HOME)
        self.knob = V(STICK_HOME)
        self.vec = V(0, 0)
        self.held = {}                # 버튼 이름 → 누르고 있는 손가락
        self.fast_on = False
        self.press_t = {}             # 버튼 눌림 연출

    # ─── 버튼 목록 (상황에 따라 보였다 숨었다) ───
    def buttons(self):
        g = self.g
        out = [("use", (1186, 590), 60, "사용", None)]
        if g.scene != "plaza":
            out.append(("shop", (1062, 634), 42, "마감" if g.shop_open else "영업", "house"))
        if g.luna.distance_to(g.p) < 160:
            out.append(("luna", (1076, 522), 38, "루나", "heart"))
        if g.scene == "outdoor" and g.p.x > g.maps["outdoor"].FOREST_X:
            out.append(("magic", (1186, 452), 50, "마법", "mana"))
        out.append(("fast", (944, 652), 34, "빨리", None))
        return out

    def active(self):
        g = self.g
        return self.enabled and g.mode == "play" and g.menu is None and not g.fade_dir

    def hit_button(self, pos):
        for name, c, r, *_ in self.buttons():
            if V(pos).distance_to(c) <= r + 10:
                return name
        return None

    def claims(self, pos):
        """이 위치를 누르면 터치 조작이 가져가는지 (마우스 흉내 이벤트를 무시하기 위해)."""
        if not self.active():
            return False
        if self.hit_button(pos):
            return True
        if self.g.quick_hit(pos) or self.g.placing:     # 꾸미기 배치 중엔 화면을 눌러 놓아야 하니 비켜 줘요
            return False
        return STICK_ZONE.collidepoint(pos) and not pg.Rect(14, 110, 300, 210).collidepoint(pos)

    # ─── 입력 ───
    def down(self, fid, pos):
        if not self.active():
            return False
        self.used = True
        b = self.hit_button(pos)
        if b:
            self.held[b] = fid
            self.press_t[b] = 0.15
            g = self.g
            if b == "use":
                g.interact()
            elif b == "shop":
                g.key(pg.K_o)
            elif b == "luna":
                g.key(pg.K_h)
            elif b == "fast":
                self.fast_on = not self.fast_on
                g.sfx("click")
            return True
        if self.stick_id is None and self.claims(pos):
            self.stick_id = fid
            self.base = V(max(STICK_R + 10, min(560 - STICK_R, pos[0])), max(380 + STICK_R, min(800 - STICK_R - 6, pos[1])))
            self.knob = V(pos)
            self._update_vec()
            return True
        return False

    def motion(self, fid, pos):
        if fid == self.stick_id:
            self.knob = V(pos)
            self._update_vec()
            return True
        return False

    def up(self, fid):
        used = False
        if fid == self.stick_id:
            self.stick_id = None
            self.vec = V(0, 0)
            self.base = V(STICK_HOME)
            self.knob = V(STICK_HOME)
            used = True
        for b in [k for k, v in self.held.items() if v == fid]:
            del self.held[b]
            used = True
        return used

    def release_all(self):
        self.stick_id = None
        self.held.clear()
        self.vec = V(0, 0)
        self.base = V(STICK_HOME)
        self.knob = V(STICK_HOME)

    def _update_vec(self):
        d = self.knob - self.base
        n = d.length()
        if n > STICK_R:
            d.scale_to_length(STICK_R)
            self.knob = self.base + d
            n = STICK_R
        self.vec = d / STICK_R if n > STICK_R * 0.18 else V(0, 0)

    # ─── 게임에 넘겨줄 값 ───
    def move_vec(self):
        return self.vec if self.active() else V(0, 0)

    def running(self):
        return self.vec.length() >= RUN_AT

    def magic_held(self):
        return "magic" in self.held

    def update(self, dt):
        for k in list(self.press_t):
            self.press_t[k] -= dt
            if self.press_t[k] <= 0:
                del self.press_t[k]
        if not self.active() and (self.stick_id is not None or self.held):
            self.release_all()

    # ─── 그리기 ───
    def draw(self, surf):
        if not self.active():
            return
        # 조이스틱
        base = pg.Surface((STICK_R * 2 + 8, STICK_R * 2 + 8), pg.SRCALPHA)
        c = STICK_R + 4
        on = self.stick_id is not None
        pg.draw.circle(base, (252, 244, 226, 120 if on else 80), (c, c), STICK_R)
        pg.draw.circle(base, (92, 64, 120, 190 if on else 120), (c, c), STICK_R, 4)
        for ang in range(4):                 # 방향 표시 삼각형
            a = ang * math.pi / 2
            tip = V(math.cos(a), math.sin(a)) * (STICK_R - 12) + V(c, c)
            l = V(math.cos(a + 2.6), math.sin(a + 2.6)) * 12 + tip
            r = V(math.cos(a - 2.6), math.sin(a - 2.6)) * 12 + tip
            pg.draw.polygon(base, (92, 64, 120, 150), [tip, l, r])
        surf.blit(base, (self.base.x - c, self.base.y - c))
        kr = 36
        knob = pg.Surface((kr * 2 + 4, kr * 2 + 4), pg.SRCALPHA)
        run = on and self.running()
        pg.draw.circle(knob, (255, 236, 170, 235) if run else (252, 244, 226, 225), (kr + 2, kr + 2), kr)
        pg.draw.circle(knob, (92, 64, 120, 230), (kr + 2, kr + 2), kr, 4)
        surf.blit(knob, (self.knob.x - kr - 2, self.knob.y - kr - 2))
        if run:
            U.outlined(surf, "달리기", (self.knob.x, self.knob.y - kr - 16), 13, U.CREAM, (58, 36, 70))
        elif not self.used:
            U.outlined(surf, "끌어서 이동", (self.base.x, self.base.y - STICK_R - 18), 13, U.CREAM, (58, 36, 70))
        # 버튼
        g = self.g
        near = g.nearest()
        for name, (x, y), r, label, ic in self.buttons():
            pressed = name in self.held or name in self.press_t
            lit = (name == "fast" and self.fast_on) or (name == "use" and near)
            s = pg.Surface((r * 2 + 8, r * 2 + 8), pg.SRCALPHA)
            cc = r + 4
            fill = (255, 226, 150, 240) if lit else (252, 244, 226, 215)
            if pressed:
                fill = (214, 196, 238, 245)
            pg.draw.circle(s, (40, 24, 50, 70), (cc, cc + 4), r)
            pg.draw.circle(s, fill, (cc, cc), r)
            pg.draw.circle(s, (92, 64, 120, 235), (cc, cc), r, 4)
            surf.blit(s, (x - cc, y - cc))
            if ic:
                im = U.icon(ic, int(r * 0.8))
                surf.blit(im, (x - im.get_width() // 2, y - im.get_height() // 2 - 8))
                U.text(surf, label, (x, y + r * 0.32), 13, U.INK, True, center=True)
            else:
                U.text(surf, label, (x, y - 11 if r > 40 else y - 9), 20 if r > 40 else 15, U.INK, True, center=True)

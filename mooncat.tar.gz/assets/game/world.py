# -*- coding: utf-8 -*-
"""지도: 저택 1층(가게), 바깥(텃밭·강가·숲), 달빛 장터 광장."""
import math, random
import pygame as pg
import assets as A
import data as D
import ui as U
import tiles as T

W, H = 1280, 800


def R(x, y, w, h):
    return pg.Rect(x, y, w, h)


# ═══════════════════════════ 저택 1층 ═══════════════════════════
class ShopMap:
    name = "shop"
    size = (W, H)
    WALL_BOTTOM = 212
    DOOR = (470, 772)
    PAY = (470, 330)
    COUNTER = (470, 262)
    BOARD = (645, 110)
    PORTRAIT = (305, 110)
    LOCKED = (95, 206)
    CAULDRON = (1090, 340)
    BED = (1150, 738)
    CURTAIN = (1010, 610)
    LAMPS = [(60, 300), (60, 760), (850, 770), (1222, 300)]
    FLOOR_AREA = R(60, 240, 800, 530)
    BENCH = (1180, 448)          # v1.0 마도석 세공대 (예전 상자 자리)
    DECOR = [(830, 262, "potted"), (70, 452, "potted"),
             (1222, 540, "books"), (330, 772, "potted")]
    DECO_CELL = 64

    def __init__(self):
        self.blockers = [
            R(0, 0, W, self.WALL_BOTTOM),                 # 뒷벽
            R(0, 0, 40, H), R(1240, 0, 40, H),            # 옆벽
            R(0, 782, 430, 30), R(510, 782, 800, 30),     # 앞벽 (문 틈 430~510)
            R(870, 212, 22, 150),                         # 작업실 낮은 칸막이 (위쪽)
            R(880, 460, 360, 22),                         # 리라의 방 윗벽
            R(880, 480, 22, 80), R(880, 660, 22, 130),    # 리라의 방 왼벽 (아치 560~660)
            R(390, 232, 160, 46),                         # 계산대
            R(1050, 300, 90, 48),                         # 솥
            R(1090, 690, 110, 60),                        # 침대
            R(922, 300, 86, 42),                          # 부엌 화덕
            R(1124, 420, 112, 36),                        # v1.0 세공대
        ]

    def shelf_rect(self, i):
        x, y = D.SHELF_SLOTS[i]
        return R(x - 50, y - 26, 100, 30)

    def deco_valid(self, g, cell, ignore=None):
        x, y = cell
        r = R(x - 26, y - 20, 52, 26)
        if not self.FLOOR_AREA.contains(r):
            return False
        if R(410, 230, 120, 560).colliderect(r):        # 문→계산대 통로
            return False
        for sx, sy in D.SHELF_SLOTS:             # 진열대 자리(비어 있어도)와 그 앞
            if R(sx - 64, sy - 140, 128, 200).colliderect(r):
                return False
        for lx, ly in self.LAMPS:
            if R(lx - 20, ly - 20, 40, 30).colliderect(r):
                return False
        for d, pos in g.s.deco_placed.items():
            if d != ignore and pos[0] == "floor" and abs(pos[1] - x) < 40 and abs(pos[2] - y) < 30:
                return False
        return True

    def all_blockers(self, g):
        b = list(self.blockers)
        for i, s in enumerate(g.s.shelves):
            if s:
                b.append(self.shelf_rect(i))
        for d, pos in g.s.deco_placed.items():
            if pos[0] == "floor":
                b.append(R(pos[1] - 22, pos[2] - 16, 44, 18))
        return b

    def objects(self, g):
        o = [
            dict(id="counter", pos=(470, 300), label="계산대 · 가구 주문 · 가격표"),
            dict(id="board", pos=(645, 250), label="마을 게시판"),
            dict(id="cauldron", pos=(1060, 390), label="마법 솥 · 제작"),
            dict(id="stove", pos=(965, 380), label="부엌 화덕 · 요리"),
            dict(id="bed", pos=(1110, 690), label="침대 · 하루 마치기"),
            dict(id="door", pos=(470, 760), label="밖으로 나가기"),
            dict(id="locked", pos=(95, 250), label="잠긴 문"),
            dict(id="portrait", pos=(305, 250), label="할머니 초상화"),
            dict(id="bench", pos=(1180, 400), label="마도석 세공대 · 부스러기 " + str(g.s.shards) if g.s.flags.get("bench") else "낡은 세공대"),
        ]
        for i, s in enumerate(g.s.shelves):
            if s:
                x, y = D.SHELF_SLOTS[i]
                o.append(dict(id=f"shelf{i}", pos=(x, y + 34), label=D.SHELF_TYPES[s["type"]][0]))
        return o

    # ───── 그리기 ─────
    def draw_ground(self, surf, g, cam):
        surf.blit(T.shop(self), (0, 0))   # 도트 바닥·벽지·징두리 (한 번 그려 캐시)
        # 창문
        for wx in (470, 1150):
            night = g.s.hour >= 19 or g.s.hour < 6
            wname = "props/window_night" if night else "props/window_day"
            if A.exists(wname):                       # v0.9: GPT 창문 그림
                win = A.image(wname, height=112)
                surf.blit(win, (wx - win.get_width() // 2, 14))
                continue
            pg.draw.rect(surf, (106, 70, 48), (wx - 50, 26, 100, 96), border_radius=6)
            pg.draw.rect(surf, (40, 50, 96) if night else (170, 214, 236), (wx - 42, 34, 84, 80), border_radius=4)
            pg.draw.line(surf, (106, 70, 48), (wx, 34), (wx, 114), 4)
            pg.draw.line(surf, (106, 70, 48), (wx - 42, 74), (wx + 42, 74), 4)
            pg.draw.rect(surf, (236, 170, 200), (wx - 56, 22, 112, 10), border_radius=4)
            for side in (-1, 1):   # 커튼
                cx0 = wx + side * 46
                pts = [(cx0 - 8 * side, 30), (cx0 + 6 * side, 30), (cx0 + 4 * side, 118), (cx0 - 12 * side, 118)]
                pg.draw.polygon(surf, (190, 150, 210), pts)
                pg.draw.polygon(surf, (150, 110, 170), pts, 2)
                pg.draw.rect(surf, (240, 214, 130), (cx0 - 8, 72, 16, 4))
        # 부엌 벽 선반 (찻주전자 · 바구니)
        pg.draw.rect(surf, (106, 70, 48), (908, 150, 118, 8))
        pg.draw.rect(surf, (80, 52, 36), (914, 158, 6, 12))
        pg.draw.rect(surf, (80, 52, 36), (1014, 158, 6, 12))
        for k, name in enumerate(("teapot", "basket", "candle")):
            ic = A.decor(name)
            surf.blit(ic, (916 + k * 38 + (18 - ic.get_width() // 2 if A.exists("decor_hd/" + name) else 0), 150 - ic.get_height()))
        # 칸막이·방 벽 (윗면 + 앞면)
        self._wall(surf, R(880, 460, 360, 22))
        self._wall(surf, R(880, 480, 22, 80))
        self._wall(surf, R(880, 660, 22, 122))
        # 아치
        pg.draw.arc(surf, (110, 74, 52), (866, 540, 50, 140), -1.2, 1.2, 8)
        self._low_counter(surf, R(868, 222, 26, 146))

    def _wall(self, surf, r):
        pg.draw.rect(surf, (150, 118, 150), r)
        pg.draw.rect(surf, (110, 80, 110), r, 3)
        pg.draw.rect(surf, (190, 164, 196), (r.x, r.y, r.w, 6))

    def _low_counter(self, surf, r):
        pg.draw.rect(surf, (140, 96, 62), r, border_radius=4)
        pg.draw.rect(surf, (92, 60, 40), r, 2, border_radius=4)
        pg.draw.rect(surf, (178, 130, 86), (r.x + 3, r.y + 3, r.w - 6, 10), border_radius=3)

    def draw_wall_items(self, surf, g):
        """벽에 붙는 것들 — 항상 바닥 물체보다 먼저(뒤에) 그린다."""
        door = A.image("props/locked_door", height=150)
        surf.blit(door, (self.LOCKED[0] - door.get_width() // 2, self.LOCKED[1] - door.get_height()))
        por = A.image("props/grandma_portrait", height=96)
        surf.blit(por, (self.PORTRAIT[0] - por.get_width() // 2, self.PORTRAIT[1] - por.get_height() // 2))
        board = A.image("props/notice_board", height=96, color=(150, 110, 70))
        surf.blit(board, (self.BOARD[0] - board.get_width() // 2, self.BOARD[1] - 48))
        for d, pos in g.s.deco_placed.items():
            if pos[0] == "wall":
                x, y = D.WALL_SLOTS[pos[1]]
                img = A.image(D.DECO[d][5], height=84)
                surf.blit(img, (x - img.get_width() // 2, y - img.get_height() // 2))

    def drawables(self, g):
        out = []
        c = A.image("props/counter", height=110)
        out.append((self.COUNTER[1] + 16, c, (self.COUNTER[0] - c.get_width() // 2, self.COUNTER[1] + 20 - c.get_height())))
        cau = A.image("props/cauldron", height=110)
        out.append((self.CAULDRON[1], cau, (self.CAULDRON[0] - cau.get_width() // 2, self.CAULDRON[1] - cau.get_height())))
        bench = A.image("props/merge_bench", height=96)
        out.append((self.BENCH[1], bench, (self.BENCH[0] - bench.get_width() // 2, self.BENCH[1] - bench.get_height())))
        stove = A.image("props/stove", height=128)
        out.append((342, stove, (965 - stove.get_width() // 2, 342 - stove.get_height())))
        for (x, y, name) in self.DECOR:
            img = A.decor(name)
            out.append((y, img, (x - img.get_width() // 2, y - img.get_height())))
        bed = A.image("props/bed", height=130)
        out.append((self.BED[1], bed, (self.BED[0] - bed.get_width() // 2, self.BED[1] - bed.get_height())))
        cur = A.image("props/room_curtain", height=150)
        out.append((self.CURTAIN[1], cur, (self.CURTAIN[0] - cur.get_width() // 2, self.CURTAIN[1] - cur.get_height())))
        lamp = A.image("props/lamp", height=110)
        for lx, ly in self.LAMPS:
            out.append((ly, lamp, (lx - lamp.get_width() // 2, ly - lamp.get_height())))
        for i, s in enumerate(g.s.shelves):
            if not s:
                continue
            x, y = D.SHELF_SLOTS[i]
            t = D.SHELF_TYPES[s["type"]]
            tint = {"bath": (255, 165, 200), "goods": (255, 205, 110), "stone": (150, 185, 255), "magic": (190, 150, 255)}.get(t[1])
            img = A.image_or(t[4], "props/shelf_potion", 130 if s["type"] != "potion2" else 150, tint)
            out.append((y, img, (x - img.get_width() // 2, y - img.get_height())))
            # 진열 제품 아이콘 (최대 3종)
            items = [p for p, n in s["stock"].items() if n > 0][:3]
            for k, p in enumerate(items):
                ic = A.image(f"products/{p}", height=34)
                out.append((y + 0.1, ic, (x - 50 + k * 34, y - 98)))
        for d, pos in g.s.deco_placed.items():
            if pos[0] == "floor":
                img = A.image(D.DECO[d][5], height=70)
                out.append((pos[2], img, (pos[1] - img.get_width() // 2, pos[2] - img.get_height())))
        return out

    def labels(self, surf, g):
        for i, s in enumerate(g.s.shelves):
            if s:
                x, y = D.SHELF_SLOTS[i]
                n = g.s.shelf_count(i)
                cap = g.s.shelf_cap(i)
                col = (90, 60, 60) if n == 0 else (70, 52, 92)
                U.pill(surf, (x - 62, y + 4, 124, 22), f"{D.CATS[D.SHELF_TYPES[s['type']][1]][0]} {n}/{cap}", bg=col, size=13)

    def lamp_glow(self, surf, g):
        if not g.shop_open:
            return
        glow = pg.Surface((140, 140), pg.SRCALPHA)
        for r in range(70, 0, -7):
            pg.draw.circle(glow, (255, 210, 120, int(40 * (1 - r / 70))), (70, 70), r)
        for lx, ly in self.LAMPS:
            surf.blit(glow, (lx - 70, ly - 150))


# ═══════════════════════════ 바깥 ═══════════════════════════
_beds = {}


def plot_bed(size, kind):
    """텃밭 한 칸: 나무 테두리 두둑 + 고랑 (절반 해상도로 그려 2배 확대)."""
    key = (size, kind)
    if key in _beds:
        return _beds[key]
    w, h = size[0] // 2, size[1] // 2
    s = pg.Surface((w, h), pg.SRCALPHA)
    rng = random.Random(5)
    if kind == "locked":
        for x in range(0, w, 4):
            s.set_at((x, 0), (84, 120, 70)); s.set_at((x, h - 1), (84, 120, 70))
        for y in range(0, h, 4):
            s.set_at((0, y), (84, 120, 70)); s.set_at((w - 1, y), (84, 120, 70))
    else:
        wet = kind == "wet"
        soil, dark, light = ((88, 58, 40), (66, 42, 30), (110, 76, 52)) if wet else ((128, 88, 58), (100, 66, 44), (156, 112, 76))
        pg.draw.rect(s, (86, 58, 38), (0, 1, w, h - 1))                  # 테두리 그림자
        pg.draw.rect(s, (150, 106, 66), (0, 0, w, h - 2))                # 나무 테두리
        for x in range(2, w - 2, 7):
            s.set_at((x, 1), (176, 130, 86))
        pg.draw.rect(s, soil, (2, 2, w - 4, h - 6))
        for k in range(3):                                               # 고랑 3줄
            y = 6 + k * (h - 10) // 3
            pg.draw.line(s, light, (3, y), (w - 4, y))
            pg.draw.line(s, dark, (3, y + 2), (w - 4, y + 2))
        for _ in range(w * h // 14):
            s.set_at((rng.randrange(3, w - 3), rng.randrange(3, h - 5)), rng.choice([dark, light]))
        if wet:
            for _ in range(6):
                x, y = rng.randrange(4, w - 6), rng.randrange(4, h - 7)
                pg.draw.line(s, (120, 150, 190), (x, y), (x + 2, y))
    out = pg.transform.scale(s, (w * 2, h * 2))
    _beds[key] = out
    return out


_DEW_CACHE = {}


def dew_sprite(t):
    """테오 퀘스트 '달빛 이슬' — 강가에 맺힌 빛나는 이슬방울 (0.1초 단위 캐시)."""
    import math
    k = int(t * 10) % 40
    if k in _DEW_CACHE:
        return _DEW_CACHE[k]
    ph = k / 40 * math.tau
    S = pg.Surface((72, 90), pg.SRCALPHA)
    glow = 0.75 + 0.25 * math.sin(ph)
    for r, a in ((34, 34), (26, 50), (18, 80)):
        pg.draw.circle(S, (170, 220, 255, int(a * glow)), (36, 50), r)
    bob = int(3 * math.sin(ph))
    cx, cy = 36, 52 + bob
    # 물방울 몸체
    pg.draw.circle(S, (150, 205, 250), (cx, cy + 6), 11)
    pg.draw.polygon(S, (150, 205, 250), [(cx - 10, cy + 2), (cx + 10, cy + 2), (cx, cy - 16)])
    pg.draw.circle(S, (205, 235, 255), (cx, cy + 6), 7)
    pg.draw.circle(S, (255, 255, 255), (cx - 3, cy + 3), 3)
    # 반짝이는 별가루
    for i in range(4):
        a = ph + i * math.tau / 4
        px, py = cx + int(22 * math.cos(a)), cy - 6 + int(12 * math.sin(a))
        c = (255, 244, 190, int(160 + 90 * math.sin(ph * 2 + i)))
        pg.draw.line(S, c, (px - 3, py), (px + 3, py), 1)
        pg.draw.line(S, c, (px, py - 3), (px, py + 3), 1)
    S = pg.transform.smoothscale(S, (94, 117))
    _DEW_CACHE[k] = S
    return S


def bram_here(s):
    """v1.0: 브람은 2장부터 매일 8시~19시 길가에 수레를 세워요."""
    return s.chapter >= 2 and 8 <= s.hour < 19


_SPOT_CACHE = {}


def trap_spot_sprite():
    """빈 통발 자리: 물가 말뚝과 밧줄 고리."""
    if "trap" not in _SPOT_CACHE:
        S = pg.Surface((40, 40), pg.SRCALPHA)
        pg.draw.ellipse(S, (0, 0, 0, 50), (6, 30, 28, 8))
        pg.draw.rect(S, (92, 60, 40), (17, 6, 6, 28))
        pg.draw.rect(S, (140, 96, 62), (18, 6, 3, 26))
        pg.draw.circle(S, (220, 200, 150), (20, 14), 6, 2)
        pg.draw.rect(S, (230, 80, 80), (16, 2, 8, 5))
        _SPOT_CACHE["trap"] = S
    return _SPOT_CACHE["trap"]


def totem_pad_sprite():
    """비어 있는 토템 자리: 동그란 돌받침."""
    if "totem" not in _SPOT_CACHE:
        S = pg.Surface((56, 24), pg.SRCALPHA)
        pg.draw.ellipse(S, (96, 88, 116), (2, 4, 52, 18))
        pg.draw.ellipse(S, (150, 140, 170), (4, 2, 48, 16))
        pg.draw.ellipse(S, (120, 170, 210), (18, 6, 20, 8), 2)
        _SPOT_CACHE["totem"] = S
    return _SPOT_CACHE["totem"]


def gather_sprite(gs):
    """채집 자리 그림 (캐시)."""
    kind = gs["kind"]
    key = ("gather", kind, gs["i"] % 6)
    if key in _beds:
        return _beds[key]
    if kind == "herb":
        img = A.decor("wild_flower" if gs["i"] % 2 else "wild_herb", gs["i"] % 3 == 0)
    elif kind == "fherb":
        img = A.decor("wild_herb", gs["i"] % 2 == 1)
    elif kind == "hive" and A.exists("decor_hd/honey"):     # v1.2: 그루터기 달린 벌집 한 장
        img = A.decor("honey")
    elif kind == "hive":
        stump = A.pix("decor/log", 2)
        honey = A.pix("decor/honey", 2)
        img = pg.Surface((max(stump.get_width(), honey.get_width()), stump.get_height() + honey.get_height() - 8), pg.SRCALPHA)
        img.blit(stump, ((img.get_width() - stump.get_width()) // 2, img.get_height() - stump.get_height()))
        img.blit(honey, ((img.get_width() - honey.get_width()) // 2, 0))
    elif kind == "ore":
        img = A.image("props/crystal_rock", height=54)
    else:   # reed: 모래 둔덕 + 조개 끝
        s = pg.Surface((24, 12), pg.SRCALPHA)
        pg.draw.ellipse(s, (150, 128, 92), (0, 3, 24, 9))
        pg.draw.ellipse(s, (226, 206, 160), (1, 2, 22, 8))
        pg.draw.ellipse(s, (240, 224, 186), (5, 2, 10, 4))
        for x, y in ((7, 7), (14, 6), (18, 8)):
            s.set_at((x, y), (170, 150, 110))
        img = pg.transform.scale(s, (48, 24))
    _beds[key] = img
    return img


class OutdoorMap:
    name = "outdoor"
    size = (2400, 1500)
    MANSION = (380, 420)
    MANSION_DOOR = (380, 440)
    HANS = (560, 600)
    NOEL = (1440, 636)                                   # v1.2: 밤 약초 수레 앞
    FISH = {"fish_n": (1470, 420), "fish_s": (1470, 1120)}
    RIVER = R(1500, 0, 160, 1500)
    BRIDGE = R(1490, 690, 180, 80)
    FOREST_X = 1680
    BERRIES = [(1850, 420), (2050, 1150), (2260, 650)]
    FIREFLY = [(1900, 960), (2150, 380), (2300, 1000), (1980, 600)]
    PLOT0 = (640, 340)
    PATHS = [R(340, 420, 80, 330), R(340, 690, 1160, 80), R(1660, 690, 740, 80), R(520, 560, 520, 40)]
    FARM = R(616, 312, 460, 216)
    YARD = R(300, 436, 160, 56)
    MAILBOX = (300, 474)
    BRAM = (1150, 646)                                   # v1.0 브람 공방 수레
    # v1.2 NPC 거처: 이름 → (밑변 가운데 x, 밑변 y, 화면 높이). 인물은 거처 앞(오른쪽 아래)에 서요.
    HOMES = {"rosemary": (150, 640, 150), "momo": (1260, 1130, 130), "mignon": (950, 905, 140),
             "theo": (1320, 900, 140), "kai": (1790, 950, 140), "cecilia": (640, 900, 140), "noel": (1360, 610, 140)}
    TRAPS = [(1470, 250), (1470, 850), (1470, 1250)]     # 통발 자리 (모두 서쪽 물가)
    TOTEMS = [(1392, 372), (1392, 1072)]                 # 낚시 토템 자리 (북·남 낚시터 옆)

    def __init__(self):
        rng = random.Random(7)
        self.trees = []
        for _ in range(60):
            x = rng.randint(1720, 2380)
            y = rng.randint(60, 1460)
            if abs(y - 730) < 70 or any(math.hypot(x - bx, y - by) < 90 for bx, by in self.BERRIES + self.FIREFLY):
                continue
            if 1640 < x < 1990 and 780 < y < 1140:          # v1.2 카이 야영지 자리
                continue
            if any(math.hypot(x - tx, y - ty) < 110 for tx, ty in self.trees):
                continue
            self.trees.append((x, y))
        for x, y in [(80, 900), (220, 1200), (600, 1300), (900, 1180), (1200, 1350), (1100, 250), (1300, 150), (120, 160), (850, 120), (1250, 560)]:
            self.trees.append((x, y))
        self.blockers = [R(0, 0, 2400, 20), R(0, 0, 20, 1500), R(2380, 0, 20, 1500), R(0, 1480, 2400, 20),
                         R(self.RIVER.x, 0, self.RIVER.w, self.BRIDGE.y), R(self.RIVER.x, self.BRIDGE.bottom, self.RIVER.w, 1500),
                         R(230, 250, 300, 170)]
        for x, y in self.trees:
            self.blockers.append(R(x - 18, y - 16, 36, 20))

    def decor(self):
        """바깥 장식(돌·통나무·꽃·버섯·클로버…) 위치. 길·강·텃밭·저택을 피해 한 번만 만든다."""
        if hasattr(self, "_decor"):
            return self._decor
        rng = random.Random(21)
        bad = self.PATHS + [self.RIVER.inflate(40, 0), self.FARM.inflate(30, 30), R(200, 180, 360, 330), R(480, 500, 160, 140)]
        bad += [R(x - 120, y - h - 10, 240, h + 50) for x, y, h in self.HOMES.values()]     # v1.2 거처
        out = []
        # v0.8: 너무 빽빽하다는 의견 → 개수 150 → 55, 돌·통나무 비중 줄임
        pick = [("rock", 1), ("tulip", 3), ("clover", 5), ("blossom", 3), ("hibiscus", 1), ("log", 0)]
        pickf = [("rock", 1), ("log", 1), ("leaf", 6), ("maple", 4), ("clover", 2)]
        tries = 0
        while len(out) < 55 and tries < 3000:
            tries += 1
            x, y = rng.randrange(40, 2360), rng.randrange(60, 1470)
            r = R(x - 20, y - 20, 40, 30)
            if any(r.colliderect(b) for b in bad) or any(math.hypot(x - tx, y - ty) < 70 for tx, ty in self.trees):
                continue
            if any(abs(x - ox) < 110 and abs(y - oy) < 90 for ox, oy, _ in out):
                continue
            table = pickf if x > self.FOREST_X else pick
            names = [n for n, wgt in table for _ in range(wgt)]
            if not names:
                continue
            out.append((x, y, rng.choice(names)))
        out.append((318, 438, "potted"))
        out.append((446, 438, "potted"))
        self._decor = out
        return out

    def plot_rect(self, i):
        c, r = i % 4, i // 4
        return R(self.PLOT0[0] + c * 104, self.PLOT0[1] + r * 90, 92, 72)

    def home_shown(self, k, s):
        if not A.exists("props/home_" + k):
            return False
        if k == "cecilia":
            return s.npc["cecilia"]["met"]
        if k == "noel":
            return s.noel_here()
        return True

    def home_img(self, k):
        return A.image("props/home_" + k, height=self.HOMES[k][2])

    def all_blockers(self, g):
        out = list(self.blockers)
        if bram_here(g.s):
            out.append(R(1080, 624, 140, 26))
        for k, (x, y, h) in self.HOMES.items():          # v1.2 거처 밑동
            if self.home_shown(k, g.s):
                w = self.home_img(k).get_width()
                out.append(R(x - int(w * 0.4), y - 34, int(w * 0.8), 30))
        return out

    def objects(self, g):
        s = g.s
        o = [dict(id="house", pos=self.MANSION_DOOR, label="가게로 들어가기")]
        for i in range(s.plot_count):
            p = s.plots[i]
            r = self.plot_rect(i)
            if not p["crop"]:
                lab = "씨앗 심기"
            elif p["days"] >= D.CROPS[p["crop"]][0]:
                lab = f"{D.MATS[p['crop']][0]} 수확"
            elif not p["watered"]:
                lab = "물 주기 (기력 1)"
            else:
                lab = "오늘은 물을 줬어요"
            o.append(dict(id=f"plot{i}", pos=r.center, label=lab, radius=80))
        for k, pos in self.FISH.items():
            o.append(dict(id=k, pos=pos, label="낚시하기 (기력 2)"))
        for i, pos in enumerate(self.BERRIES):
            if g.day_flags.get(f"berry{i}") is None:
                o.append(dict(id=f"berry{i}", pos=pos, label="숲딸기 따기"))
        if s.chapter >= 4 and s.hour >= 19:
            for i, pos in enumerate(self.FIREFLY):
                if g.day_flags.get(f"fly{i}") is None:
                    o.append(dict(id=f"fly{i}", pos=pos, label="반딧불 가루 모으기"))
        if s.chapter >= 2 and 7 <= s.hour < 19:
            o.append(dict(id="hans_shop", pos=self.HANS, label="한스네 수레 · 재료 상점"))
        if s.noel_here():
            o.append(dict(id="noel", pos=self.NOEL, label="노엘 · 달밤의 약 가방"))
        if bram_here(s):
            o.append(dict(id="bram", pos=(self.BRAM[0], self.BRAM[1] + 34), label="브람 공방 수레 · 진열장 강화 · 낚시 용품" if s.flags.get("bram_met") else "공방 수레 · 처음 보는 장인", radius=70))
        if s.flags.get("bram_met"):
            for i, pos in enumerate(self.TRAPS):
                t = s.traps[i]
                if t is None:
                    lab = f"통발 놓기 (가진 통발 {s.gear['trap'] + s.gear['trap_iron']}개)"
                elif s.trap_ready(i):
                    lab = "통발 걷기!"
                else:
                    lab = "통발을 놓아 뒀어요 (내일 걷기)"
                o.append(dict(id=f"trap{i}", pos=pos, label=lab, radius=56))
        if s.gear.get("totem"):
            for i, pos in enumerate(self.TOTEMS):
                lab = "낚시 토템 (여기 서 있어요)" if s.totem_at == i else ("토템 자리 · 여기에 세우기" if s.totem_at is None else "토템 자리 · 이쪽으로 옮기기")
                o.append(dict(id=f"totem{i}", pos=pos, label=lab, radius=50))
        mail = s.unread_mail()
        o.append(dict(id="mailbox", pos=self.MAILBOX, label=f"우편함 · 새 편지 {mail}통" if mail else ("우편함 · 버들골 소포" if s.flags.get("neighbor") else "우편함"), radius=64))
        for gs in getattr(g, "gather", []):
            if not g.day_flags.get(f"gather{gs['i']}"):
                o.append(dict(id=f"gather{gs['i']}", pos=gs["pos"], label=D.GATHER_LABEL[gs["kind"]], radius=64))
        if s.npc["theo"]["quest"] == "active" and s.hour >= 20 and not s.flags.get("dew"):
            o.append(dict(id="dew", pos=(1440, 1180), label="달빛 이슬 모으기"))
        return o

    def region(self, pos):
        x, y = pos
        if x > self.FOREST_X:
            return "forest"
        if x > 1300 or (x > 1200 and y > 900):
            return "river"
        if 560 < x < 1100 and 260 < y < 560:
            return "farm"
        return None

    def draw_ground(self, surf, g, cam):
        cx, cy = cam
        surf.blit(T.outdoor(self), (0, 0), pg.Rect(int(cx), int(cy), W, H))   # 도트 풀·길·강·다리 (캐시)
        t = g.t
        for y in range(0, 1500, 60):
            yy = (y + t * 30) % 1500
            pg.draw.line(surf, (160, 210, 236), (self.RIVER.x + 30 - cx, yy - cy), (self.RIVER.x + 70 - cx, yy - cy), 2)
            pg.draw.line(surf, (160, 210, 236), (self.RIVER.x + 90 - cx, yy + 30 - cy), (self.RIVER.x + 130 - cx, yy + 30 - cy), 2)
        # 낚시터 물결
        for k, (x, y) in self.FISH.items():
            for r in (10, 20):
                rr = r + (t * 12) % 12
                pg.draw.ellipse(surf, (220, 240, 250), (x + 60 - rr - cx, y - rr / 3 - cy, rr * 2, rr * 2 / 3), 2)
        # 텃밭 (v0.8: 도트 두둑 + Fluent 새싹 그림)
        for i in range(8):
            r = self.plot_rect(i).move(-cx, -cy)
            if i >= g.s.plot_count:
                surf.blit(plot_bed(r.size, "locked"), r.topleft)
                continue
            p = g.s.plots[i]
            surf.blit(plot_bed(r.size, "wet" if p["watered"] else "dry"), r.topleft)
            if p["crop"]:
                need = D.CROPS[p["crop"]][0]
                stage = 0 if p["days"] == 0 else (2 if p["days"] >= need else 1)
                name = f"crops/{p['crop']}_{stage}"
                if A.exists(name):                    # v0.9: GPT 작물 그림 3포기
                    img = A.image(name, height=58)
                    for k, fx in enumerate((0.22, 0.5, 0.78)):
                        sway = int(math.sin(g.t * 1.6 + k + i) * 1.2)
                        surf.blit(img, (r.x + int(r.w * fx) - img.get_width() // 2 + sway, r.bottom - img.get_height() - 3 - (4 if k == 1 else 0)))
                    if not p["watered"] and stage < 2:
                        dx, dy = r.right - 14, r.y + 6 + math.sin(g.t * 3 + i) * 2
                        pg.draw.circle(surf, (70, 60, 90), (dx, dy + 11), 7)
                        pg.draw.circle(surf, (110, 180, 240), (dx, dy + 11), 6)
                    continue
                for row in range(2):
                    for k in range(3):
                        px = r.x + 18 + k * 28 + (6 if row else 0)
                        py = r.y + 34 + row * 26
                        sway = math.sin(g.t * 1.6 + k + row * 2 + i) * 1.2
                        if stage == 0:
                            img = A.pix("decor/sprout", 2)
                        elif stage == 1:
                            img = A.pix("decor/plant" if p["crop"] in ("herb", "moonherb") else "decor/sprout_big", 2)
                        else:
                            img = A.pix("decor/sprout_big", 2)
                        surf.blit(img, (px - img.get_width() // 2 + sway, py - img.get_height()))
                        if stage == 2:
                            ic = A.mat_icon(p["crop"], 26, D.MATS[p["crop"]][3], D.MATS[p["crop"]][0])
                            bob = int(abs(math.sin(g.t * 2 + k + row)) * 2)
                            surf.blit(ic, (px - 13 + sway, py - img.get_height() - 16 - bob))
                if not p["watered"] and stage < 2:      # 물 필요 표시
                    dx, dy = r.right - 14, r.y + 6 + math.sin(g.t * 3 + i) * 2
                    pg.draw.polygon(surf, (70, 60, 90), [(dx, dy - 1), (dx - 6, dy + 9), (dx + 6, dy + 9)])
                    pg.draw.circle(surf, (70, 60, 90), (dx, dy + 11), 7)
                    pg.draw.polygon(surf, (110, 180, 240), [(dx, dy + 1), (dx - 5, dy + 9), (dx + 5, dy + 9)])
                    pg.draw.circle(surf, (110, 180, 240), (dx, dy + 11), 6)
                    pg.draw.rect(surf, (220, 240, 255), (dx - 3, dy + 8, 2, 3))

    # v1.2: 나무 여러 종류 + 좌우 뒤집기 + 크기 차이 (같은 나무 반복 줄이기)
    TREES_VILLAGE = [("props/tree", 170), ("props/tree_village_round", 168), ("props/tree_village_blossom", 150)]
    TREES_FOREST = [("props/tree_forest_tall", 205), ("props/tree_forest_pine", 196), ("props/tree", 176)]

    def tree_img(self, x, y):
        h = (x * 73856093 ^ y * 19349663) & 0xFFFF
        table = self.TREES_FOREST if x > self.FOREST_X else self.TREES_VILLAGE
        table = [t for t in table if A.exists(t[0])] or [("props/tree", 170)]
        name, base = table[h % len(table)]
        height = int(base * (0.88 + (h >> 4) % 25 / 100))
        flip = (h >> 9) & 1
        key = ("tree_v", name, height, flip)
        if key not in A._cache:
            img = A.image(name, height=height)
            A._cache[key] = pg.transform.flip(img, True, False) if flip else img
        return A._cache[key]

    def drawables(self, g):
        out = []
        cx, cy = g.cam
        m = A.image("props/mansion", height=320)
        out.append((self.MANSION[1], m, (self.MANSION[0] - m.get_width() // 2, self.MANSION[1] - m.get_height())))
        for x, y in self.trees:
            if -240 < x - cx < W + 240 and -50 < y - cy < H + 260:
                tree = self.tree_img(x, y)
                out.append((y, tree, (x - tree.get_width() // 2, y - tree.get_height() + 10)))
        for (x, y, name) in self.decor():
            if -80 < x - cx < W + 80 and -40 < y - cy < H + 80:
                img = A.decor(name, (x * 7 + y) % 3 == 0)
                out.append((y, img, (x - img.get_width() // 2, y - img.get_height())))
        mbn = "props/mailbox_open" if g.s.unread_mail() else "props/mailbox"
        mb = A.image(mbn, height=74) if A.exists(mbn) else A.pix(mbn.replace("props/", "decor/"), 2)
        out.append((self.MAILBOX[1], mb, (self.MAILBOX[0] - mb.get_width() // 2, self.MAILBOX[1] - mb.get_height())))
        for gs in getattr(g, "gather", []):
            if g.day_flags.get(f"gather{gs['i']}"):
                continue
            x, y = gs["pos"]
            if not (-80 < x - cx < W + 80 and -80 < y - cy < H + 80):
                continue
            img = gather_sprite(gs)
            out.append((y, img, (x - img.get_width() // 2, y - img.get_height())))
        s = g.s
        if s.npc["theo"]["quest"] == "active" and s.hour >= 20 and not s.flags.get("dew"):
            x, y = 1440, 1180
            if -80 < x - cx < W + 80 and -80 < y - cy < H + 80:
                img = dew_sprite(pg.time.get_ticks() / 1000)
                if A.exists("props/dew"):                  # v1.1: GPT 달빛 이슬 + 둥실 효과
                    tt = pg.time.get_ticks() / 1000
                    glow = pg.Surface((96, 60), pg.SRCALPHA)       # 뒤쪽 은은한 달빛 원
                    k = 0.75 + 0.25 * math.sin(tt * 2.5)
                    for rr, al in ((46, 30), (34, 45), (22, 60)):
                        pg.draw.ellipse(glow, (170, 220, 255, int(al * k)), (48 - rr, 30 - rr * 0.6, rr * 2, rr * 1.2))
                    leaf = A.image("props/dew", height=58)
                    out.append((y - 1, glow, (x - 48, y - 50)))
                    img = leaf
                    y = y + int(2 * math.sin(tt * 2))
                out.append((y, img, (x - img.get_width() // 2, y - img.get_height() + 8)))
        bush = A.image_or("props/bush_berry", "props/bush_lavender", 70, (255, 170, 170))
        for i, (x, y) in enumerate(self.BERRIES):
            out.append((y, bush, (x - bush.get_width() // 2, y - bush.get_height())))
        for k, (hx, hy, hh) in self.HOMES.items():         # v1.2 NPC 거처
            if self.home_shown(k, g.s) and -300 < hx - cx < W + 300 and -60 < hy - cy < H + 260:
                hi = self.home_img(k)
                out.append((hy, hi, (hx - hi.get_width() // 2, hy - hi.get_height())))
        if g.s.chapter >= 2 and 7 <= g.s.hour < 19:
            c = A.image("props/hans_cart", height=110)
            out.append((self.HANS[1], c, (self.HANS[0] - c.get_width() // 2, self.HANS[1] - c.get_height())))
        s = g.s
        if bram_here(s):                                 # v1.0 브람 공방 수레 + 브람
            c = A.image("props/bram_stall", height=118)
            bx, by = self.BRAM
            out.append((by, c, (bx - c.get_width() // 2, by - c.get_height())))
            b = A.image("npc_world/bram", height=86)
            out.append((by + 22, b, (bx + 78 - b.get_width() // 2, by + 22 - b.get_height())))
        if s.flags.get("bram_met"):
            for i, (x, y) in enumerate(self.TRAPS):
                t = s.traps[i]
                if t is None:
                    img = trap_spot_sprite()
                else:
                    img = A.image("props/trap_full" if s.trap_ready(i) else "props/trap_set", height=60)
                out.append((y, img, (x - img.get_width() // 2, y - img.get_height() + 10)))
        if s.gear.get("totem"):
            for i, (x, y) in enumerate(self.TOTEMS):
                if s.totem_at == i:
                    img = A.image(f"props/totem_{min(2, s.gear['totem'])}", height=96)
                else:
                    img = totem_pad_sprite()
                out.append((y, img, (x - img.get_width() // 2, y - img.get_height() + 6)))
        return out

    def labels(self, surf, g):
        cx, cy = g.cam
        for name, (x, y) in (("마녀의 텃밭", (840, 320)), ("반짝이는 강가", (1580, 250)), ("달빛 숲", (2000, 660))):
            if -100 < x - cx < W + 100 and -50 < y - cy < H:
                U.pill(surf, (x - cx - 60, y - cy, 120, 24), name, bg=(70, 52, 92), size=14)


# ═══════════════════════════ 달빛 장터 광장 ═══════════════════════════
class PlazaMap:
    name = "plaza"
    size = (W, H)
    BOOTH = (640, 470)
    BOOTH_SLOTS = [(520, 452), (600, 452), (680, 452), (760, 452), (560, 488), (720, 488)]
    STALLS = [("은빛 탑 상회", (250, 330), (60, 70, 110)), ("빵집 보리", (1030, 330), (180, 120, 70)),
              ("꽃집 라일락", (250, 640), (170, 110, 170)), ("사탕 가게", (1030, 640), (220, 120, 140))]
    FOUNTAIN = (640, 230)

    def __init__(self):
        self.blockers = [R(0, 0, W, 60), R(0, 0, 30, H), R(1250, 0, 30, H), R(0, 780, W, 20),
                         R(520, 380, 240, 70), R(580, 190, 120, 70)]
        for _, (x, y), _ in self.STALLS:
            self.blockers.append(R(x - 90, y - 70, 180, 70))

    def all_blockers(self, g):
        return self.blockers

    def objects(self, g):
        return [dict(id="booth", pos=(640, 520), label="내 부스 진열 확인")]

    def draw_ground(self, surf, g, cam):
        surf.blit(T.plaza(), (0, 0))   # 도트 돌바닥 · 화단 (캐시)
        # 분수 (빈칸)
        f = A.image("plaza/fountain", height=170, color=(90, 120, 160))
        surf.blit(f, (self.FOUNTAIN[0] - f.get_width() // 2, self.FOUNTAIN[1] + 44 - f.get_height()))
        # 등불 줄
        for k in range(2):
            y0 = 90 + k * 20
            pg.draw.line(surf, (60, 40, 30), (0, y0), (W, y0 + 30), 2)
            for x in range(40, W, 90):
                yy = y0 + 30 * x / W
                col = (255, 200, 110) if (x // 90 + k) % 2 else (240, 150, 190)
                pg.draw.circle(surf, col, (x, int(yy) + 10), 9)
                pg.draw.circle(surf, (255, 240, 200), (x, int(yy) + 8), 3)

    def draw_wall_items(self, surf, g):
        pass

    def drawables(self, g):
        out = []
        booth = A.image("plaza/booth_lira", height=300, color=(140, 100, 170))
        bx, by = self.BOOTH[0] - booth.get_width() // 2, 460 - booth.get_height()
        out.append((450, booth, (bx, by)))
        counter = by + int(booth.get_height() * 0.70)          # 카운터 윗면
        for i, pid in enumerate(g.market_slots):
            if pid:
                ic = A.image(f"products/{pid}", height=38)
                x = self.BOOTH[0] + int((i - 2.5) * 40)
                out.append((451, ic, (x - ic.get_width() // 2, counter + 4 - ic.get_height())))
        for name, (x, y), col in self.STALLS:
            st = A.image(f"plaza/stall_{['silver','bakery','flower','candy'][self.STALLS.index((name,(x,y),col))]}", height=210, color=col)
            out.append((y, st, (x - st.get_width() // 2, y - st.get_height())))
        return out

    def labels(self, surf, g):
        U.pill(surf, (560, 456, 160, 24), "리라의 마법 부스", bg=(120, 80, 150), size=14)
        for name, (x, y), col in self.STALLS:
            U.pill(surf, (x - 70, y + 4, 140, 22), name, bg=col, size=13)

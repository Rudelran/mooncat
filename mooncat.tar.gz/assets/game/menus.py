# -*- coding: utf-8 -*-
"""모든 창(메뉴)과 대화 화면."""
import math, random, sys
import pygame as pg
import assets as A
import data as D
import story as S
import story_extra as E
import ui as U

W, H = 1280, 800
CONFIRM_KEYS = (pg.K_RETURN, pg.K_SPACE, pg.K_e, pg.K_KP_ENTER)


AFF_TALK = D.AFF_TALK      # 대화 선택지 등급 → 호감도 (v0.8: 기본 5 · 등급 1·2·3 → +5 · +7 · +10)


def talk_lines(k):
    """단골의 대본 대화 전체 (기존 대화 뒤에 v0.8 추가분). 순서를 유지해야 저장된 '본 대화' 번호가 맞아요."""
    return S.DIALOGUE.get(k, []) + E.EXTRA_DIALOGUE.get(k, [])


class Menu:
    pause = True

    def __init__(self, g):
        self.g = g
        self.s = g.s

    def close(self):
        self.g.close_menu()

    def key(self, k):
        if k in (pg.K_ESCAPE,):
            self.close()

    def panel(self, surf, title, sub=None, rect=(90, 70, 1100, 660), style="paper"):
        r = pg.Rect(rect)
        inner = self.g.ui.frame(surf, r, style)
        dark = style == "dark"
        U.ribbon(surf, (r.centerx, r.y - 2), title, size=24)
        if sub:
            U.text(surf, sub, (inner.x + 22, inner.y + 46), 15, U.INK_SOFT, width=inner.w - 150)
        if close_button(self.g, surf, (inner.right - 44, inner.y + 2)):
            self.close()
        link = HELP_LINK.get(type(self).__name__)
        if link:
            qr = pg.Rect(inner.right - 98, inner.y + 2, 44, 44)
            U.slot(surf, qr, qr.collidepoint(self.g.ui.mouse))
            surf.blit(U.icon("help", 24, U.LAV_DARK), (qr.centerx - 12, qr.centery - 12))
            U.keycap(surf, (qr.centerx, qr.bottom + 2), "?", 12)
            if self.g.ui.hit(qr):
                self.g.open_menu(Help(self.g, *link))
        return inner


def close_button(g, surf, pos):
    r = pg.Rect(pos[0], pos[1], 44, 44)
    hover = r.collidepoint(g.ui.mouse)
    U.slot(surf, r, hover)
    x = U.P("icon_11", 2)
    surf.blit(x, (r.centerx - x.get_width() // 2, r.centery - x.get_height() // 2))
    U.keycap(surf, (r.centerx, r.bottom + 2), "Esc", 12)
    return g.ui.hit(r)


def portrait_frame(surf, rect):
    """Paper UI 홀더(모서리 홈 사각형)를 초상화 액자로 늘림."""
    src = A.raw("ui/paper/holder_25")      # 32x32
    r = pg.Rect(rect)
    s = 2
    nw, nh = r.w // s, r.h // s
    b = pg.Surface((nw, nh), pg.SRCALPHA)
    c = 8
    xs = [(0, c, 0), (c, nw - 2 * c, c), (nw - c, c, 32 - c)]
    ys = [(0, c, 0), (c, nh - 2 * c, c), (nh - c, c, 32 - c)]
    for dx, dw, sx in xs:
        for dy, dh, sy in ys:
            sw = c if sx != c else 32 - 2 * c
            sh = c if sy != c else 32 - 2 * c
            b.blit(pg.transform.scale(src.subsurface((sx, sy, sw, sh)), (dw, dh)), (dx, dy))
    surf.blit(pg.transform.scale(b, (nw * s, nh * s)), r.topleft)


# ═══════════════════════ 대화 (초상화 왼쪽) ═══════════════════════
BOX = pg.Rect(36, 468, 1208, 312)


def draw_dialogue_box(g, surf, speaker, text, title=None, smile=False, hearts=None, shown=None):
    if title:
        U.ribbon(surf, (W // 2, BOX.y - 120), title, size=30)
    inner = g.ui.frame(surf, BOX, "paper", 16)
    tx = inner.x + 24
    if speaker and speaker != "narr":
        pr = pg.Rect(inner.x + 6, inner.y + 4, 236, inner.h - 8)
        portrait_frame(surf, pr)
        import fallback as FB
        has_smile = A.exists(f"portraits/{speaker}_smile") or f"portraits/{speaker}_smile" in FB.ASPECT
        name = f"portraits/{speaker}_smile" if smile and has_smile else f"portraits/{speaker}"
        if smile and not A.exists(f"portraits/{speaker}_smile"):
            A.missing.add(f"portraits/{speaker}_smile")
        img = A.image(name, height=pr.h - 30)
        if img.get_width() > pr.w - 24:
            img = pg.transform.smoothscale(img, (pr.w - 24, int(img.get_height() * (pr.w - 24) / img.get_width())))
        clip = surf.get_clip()
        surf.set_clip(pr.inflate(-14, -14))
        surf.blit(img, (pr.centerx - img.get_width() // 2, pr.bottom - img.get_height() - 8))
        surf.set_clip(clip)
        if hearts is not None:
            hb = pg.Rect(pr.x + 20, pr.bottom - 40, pr.w - 40, 30)
            pg.draw.rect(surf, (246, 234, 208), hb, border_radius=6)
            pg.draw.rect(surf, U.LINE, hb, 1, border_radius=6)
            for i in range(5):
                full = hearts >= (i + 1) * 20
                U.heart(surf, (hb.x + 20 + i * 38, hb.centery), 10, (236, 90, 130) if full else (190, 170, 170))
        tx = pr.right + 22
        nm = D.SPEAKER.get(speaker, speaker)
        U.ribbon(surf, (tx + A.font(24, True).size(nm)[0] // 2 + 40, BOX.y - 6), nm, size=24)
        ty = inner.y + 24
    else:
        ty = inner.y + 30
    if shown is not None:
        text = text[:int(shown)]
    U.text(surf, text, (tx, ty), 24, U.INK, width=inner.right - tx - 24, line_gap=12)
    return inner, tx


class Dialogue(Menu):
    CPS = 38   # 초당 글자 수 (타자 효과)

    def __init__(self, g, lines, on_done=None, title=None):
        super().__init__(g)
        self.lines = [l for l in lines]
        self.i = 0
        self.on_done = on_done
        self.title = title
        self.shown = 0.0

    def update(self, dt):
        full = len(self.lines[self.i][1])
        if self.shown < full:
            before = int(self.shown)
            self.shown = min(full, self.shown + dt * self.CPS)
            if int(self.shown) // 3 != before // 3:
                self.g.sfx("hover")

    def next(self):
        if self.shown < len(self.lines[self.i][1]):
            self.shown = len(self.lines[self.i][1])
            return
        self.g.sfx("page")
        self.i += 1
        self.shown = 0.0
        if self.i >= len(self.lines):
            self.close()
            if self.on_done:
                self.on_done()

    def key(self, k):
        if k in CONFIRM_KEYS:
            self.next()
        elif k == pg.K_ESCAPE:
            self.i = len(self.lines) - 1
            self.shown = 9999
            self.next()

    def draw(self, surf):
        line = self.lines[self.i]
        sp, text = line[0], line[1]
        smile = len(line) > 2 and line[2] == "smile"      # v0.9: ("mom", "…", "smile") → 웃는 얼굴
        inner, _ = draw_dialogue_box(self.g, surf, sp, text, self.title, smile=smile, shown=self.shown)
        done = self.shown >= len(text)
        if done and int(self.g.t * 2) % 2 == 0:
            tri = [(inner.right - 26, inner.bottom - 38), (inner.right - 12, inner.bottom - 38), (inner.right - 19, inner.bottom - 28)]
            pg.draw.polygon(surf, U.LAV, tri)
        U.text(surf, (f"{self.i + 1}/{len(self.lines)}  ·  화면을 눌러 다음" if self.g.touch.enabled else f"{self.i + 1}/{len(self.lines)}  ·  Enter · 클릭: 다음  ·  Esc: 건너뛰기"), (inner.right - 40, inner.bottom - 22), 12, U.INK_SOFT, right=True)
        if self.g.ui.hit(BOX):
            self.next()


class ChapterCard(Menu):
    """v0.9: 장이 열릴 때 보여 주는 표지 그림 (GPT 삽화). 클릭 · Enter로 넘김."""

    def __init__(self, g, ch):
        super().__init__(g)
        self.ch = ch
        self.t = 0.0

    def update(self, dt):
        self.t += dt

    def key(self, k):
        if (k in CONFIRM_KEYS or k == pg.K_ESCAPE) and self.t > 0.4:
            self.close()

    def draw(self, surf):
        name = f"story/chapter_{self.ch}"
        img = A.image(name, size=(W, H))
        a = min(1.0, self.t / 0.6)
        if a < 1:
            img = img.copy()
            img.set_alpha(int(255 * a))
            surf.fill((20, 16, 30))
        surf.blit(img, (0, 0))
        band = pg.Surface((W, 120), pg.SRCALPHA)
        band.fill((20, 14, 30, 150))
        surf.blit(band, (0, H - 150))
        U.ribbon(surf, (W // 2, H - 150), f"제 {self.ch}장 · {D.CHAPTERS[self.ch - 1][1]}", size=30)
        if self.t > 0.8 and int(self.t * 2) % 2 == 0:
            U.text(surf, "화면을 눌러 이야기 시작" if self.g.touch.enabled else "클릭 · Enter: 이야기 시작", (W // 2, H - 60), 16, U.CREAM, center=True)
        if self.t > 0.4 and self.g.ui.hit(pg.Rect(0, 0, W, H)):
            self.close()


class Choice(Menu):
    def __init__(self, g, speaker, question, options):
        super().__init__(g)
        self.sp, self.q, self.opts = speaker, question, options

    def key(self, k):
        if pg.K_1 <= k <= pg.K_4:
            i = k - pg.K_1
            if i < len(self.opts) and self.opts[i][2]:
                self.pick(i)

    def pick(self, i):
        self.close()
        self.opts[i][1]()

    def draw(self, surf):
        inner, tx = draw_dialogue_box(self.g, surf, self.sp, self.q)
        for i, (label, fn, ok) in enumerate(self.opts):
            r = (tx, inner.y + 150 + i * 50, inner.right - tx - 30, 42)
            if self.g.ui.button(surf, r, f"{i + 1}. {label}", ok, size=17):
                self.pick(i)
                return


class Confirm(Menu):
    def __init__(self, g, text, yes, no=None):
        super().__init__(g)
        self.text, self.yes, self.no = text, yes, no

    def key(self, k):
        if k in (pg.K_RETURN, pg.K_y):
            self.close(); self.yes()
        elif k in (pg.K_ESCAPE, pg.K_n):
            self.close(); self.no and self.no()

    def draw(self, surf):
        r = pg.Rect(W // 2 - 300, H // 2 - 110, 600, 220)
        inner = self.g.ui.frame(surf, r, "paper")
        U.text(surf, self.text, (inner.x + 20, inner.y + 20), 19, U.INK, width=inner.w - 40)
        if self.g.ui.button(surf, (inner.x + 40, inner.bottom - 60, 220, 44), "네 (Enter)", primary=True):
            self.close(); self.yes()
        elif self.g.ui.button(surf, (inner.right - 260, inner.bottom - 60, 220, 44), "아니요 (Esc)"):
            self.close(); self.no and self.no()


# ═══════════════════════ 단골과 대화 ═══════════════════════
class NPCMenu(Menu):
    def __init__(self, g, k):
        super().__init__(g)
        self.k = k
        self.state = "root"
        self.greet = random.choice(S.GREETINGS.get(k, ["안녕하세요."]))
        self.line = None
        self.reply = None
        self.smile = False
        self.info = None

    def data(self):
        return self.s.npc[self.k]

    def next_dialogue(self):
        n = self.data()
        for i, d in enumerate(talk_lines(self.k)):
            if i not in n["seen"] and self.s.chapter >= d["ch"] and n["aff"] >= d["aff"]:
                return i, d
        # 대본이 떨어지면 매일 수다 (반복 가능 · 어제와 다른 것)
        pool = E.CHATTER.get(self.k, [])
        if not pool:
            return None, None
        last = n.get("last_chat", -1)
        idx = random.choice([j for j in range(len(pool)) if j != last] or [0])
        n["last_chat"] = idx
        return -1, pool[idx]

    def key(self, k):
        if k == pg.K_ESCAPE:
            self.close()
        elif self.state in ("reply", "info") and k in CONFIRM_KEYS:
            self.state = "root"
            self.smile = False
        elif self.state == "talk" and pg.K_1 <= k <= pg.K_3:
            self.choose(k - pg.K_1)
        elif self.state == "root" and pg.K_1 <= k <= pg.K_4:
            self.root_pick(k - pg.K_1)

    def root_options(self):
        s, n = self.s, self.data()
        talked = n["talked"] == s.day
        opts = [("대화하기" + (" (오늘은 끝)" if talked else " · 하루 1번"), "talk", not talked)]
        if self.k in D.QUESTS:
            q = n["quest"]
            if q == "none":
                ok = s.quest_available(self.k)
                need = "" if ok else (f" ({D.NPCS[self.k]['quest_ch']}장 · 호감도 30 필요)")
                opts.append(("! 부탁 듣기" + need, "quest", ok))
            elif q == "active":
                opts.append(("✓ 부탁 전달하기" if s.quest_ready(self.k) else "… 부탁 진행 상황", "quest", True))
            else:
                opts.append(("부탁 완료", "quest", False))
        gifted = self.s.flags.get(f"gift_{self.k}") == s.day
        opts.append(("선물하기" + (" (오늘은 끝)" if gifted else ""), "gift", not gifted))
        opts.append(("그만두기", "leave", True))
        return opts

    def root_pick(self, i):
        opts = self.root_options()
        if i >= len(opts) or not opts[i][2]:
            return
        act = opts[i][1]
        s, n = self.s, self.data()
        if act == "talk":
            idx, d = self.next_dialogue()
            n["talked"] = s.day
            if d is None:
                self.state = "info"
                self.info = random.choice(S.GREETINGS.get(self.k, ["…"])) + f" (짧게 인사만 나눴어요 · 호감도 +{D.TALK_BASE})"
                self.s.add_aff(self.k, D.TALK_BASE)
                self.g.floater(self.g.p + pg.Vector2(0, -130), f"호감도 +{D.TALK_BASE}", (255, 170, 190))
                return
            if idx >= 0:
                n["seen"].append(idx)
            self.line = d
            self.order = list(range(len(d["choices"])))
            random.shuffle(self.order)
            self.state = "talk"
        elif act == "quest":
            q = D.QUESTS[self.k]
            if n["quest"] == "none":
                n["quest"] = "active"
                if self.k == "kai":
                    self.g.spawn_slimes()
                self.state = "info"
                self.info = f"「{q['title']}」 {q['text']}"
            elif s.quest_ready(self.k):
                s.finish_quest(self.k)
                deco = D.DECO[q["deco"]][0]
                self.close()
                self.g.push_lines(S.QUEST_DONE[self.k] + [("luna", f"답례품 '{deco}'을(를) 받았어. B(꾸미기)에서 가게에 놓으면 효과가 켜져.")],
                                  title=f"부탁 완료 · {q['title']}")
                self.g.hearts(self.g.p, 8)
                s.save()
            else:
                self.state = "info"
                self.info = self.progress_text()
        elif act == "gift":
            self.state = "gift"
        else:
            self.close()

    def progress_text(self):
        s = self.s
        q = D.QUESTS[self.k]
        parts = [f"「{q['title']}」"]
        if q.get("boss"):
            parts.append("거대 슬라임: " + ("쓰러뜨림 ✓" if s.flags.get("boss_down") else "숲 북동쪽"))
        if q.get("page"):
            parts.append("찢어진 쪽: " + ("찾음 ✓" if s.flags.get("page_found") else "할머니 초상화"))
        if q.get("dew"):
            parts.append("달빛 이슬: " + ("모음 ✓" if s.flags.get("dew") else "밤 8시 이후 남쪽 강가"))
        for p, n in q["need"].items():
            parts.append(f"{D.PROD[p]['name']} {s.products.get(p, 0)}/{n}")
        for m, n in q.get("need_mats", {}).items():
            parts.append(f"{D.MATS[m][0]} {s.materials.get(m, 0)}/{n}")
        return " · ".join(parts)

    def choose(self, i):
        if i >= len(self.order):
            return
        c = self.line["choices"][self.order[i]]
        gain = AFF_TALK.get(c["aff"], D.TALK_BASE)
        self.s.add_aff(self.k, gain)
        self.g.floater(self.g.p + pg.Vector2(0, -130), f"호감도 +{gain}", (255, 170, 190))
        self.reply = c["reply"]
        self.smile = c["aff"] >= 2
        self.state = "reply"
        self.g.hearts(self.g.p + pg.Vector2(0, -20), 2 + c["aff"] * 2)
        # 친해진 단골은 가끔 재료를 건네요 (v0.8 획득처)
        n = self.data()
        gives = [m for m in D.NPC_GIVES.get(self.k, []) if self.s.mat_unlocked(m)]
        if gives and n["aff"] >= 40 and random.random() < 0.35:
            m = random.choice(gives)
            cnt = 1 if m in ("moonherb", "shell", "crystal", "jelly") else 2
            self.s.add_mat(m, cnt, xp=False)
            self.reply += f"  (…{D.MATS[m][0]} {cnt}개를 건네줬어요!)"
            self.g.floater(self.g.p + pg.Vector2(0, -160), f"{D.MATS[m][0]} +{cnt}", U.CREAM, icon=m)

    def give(self, pid):
        s = self.s
        if pid.startswith("d_"):          # v0.8: 만든 요리도 선물
            q = s.take_dish(pid)            # v1.0: 좋은 품질부터, 품질 보너스
            liked = pid in D.DISH_LIKES.get(self.k, [])
            gain = D.GIFT_AFF["dish_like" if liked else "dish"] + D.COOK_Q.get(q, D.COOK_Q[1])[2]
        else:
            s.products[pid] -= 1
            liked = D.PROD[pid]["cat"] in D.likes_of(self.k)
            gain = D.GIFT_AFF["prod_like" if liked else "prod"]
        self.g.floater(self.g.p + pg.Vector2(0, -130), f"호감도 +{gain}", (255, 170, 190))
        s.add_aff(self.k, gain)
        s.flags[f"gift_{self.k}"] = s.day
        self.state = "reply"
        self.smile = liked
        if pid.startswith("d_"):
            self.reply = "우와, 직접 만든 거예요? 이거 정말 좋아해요!" if liked else "직접 만든 요리네요. 잘 먹을게요!"
        else:
            self.reply = "와, 제가 좋아하는 거예요! 고마워요!" if liked else "고마워요. 잘 쓸게요."
        self.g.hearts(self.g.p, 2 + gain * 2)

    def draw(self, surf):
        n = self.data()
        if self.state == "root":
            inner, tx = draw_dialogue_box(self.g, surf, self.k, self.greet, hearts=n["aff"])
            for i, (label, act, ok) in enumerate(self.root_options()):
                r = (tx + (i % 2) * 420, inner.y + 130 + (i // 2) * 56, 400, 46)
                if self.g.ui.button(surf, r, f"{i + 1}. {label}", ok, primary=(act == "talk" and ok), size=17):
                    self.root_pick(i)
                    return
            U.text(surf, f"호감도 {n['aff']}/100", (inner.right - 20, inner.bottom - 30), 14, U.INK_SOFT, right=True)
        elif self.state == "talk":
            inner, tx = draw_dialogue_box(self.g, surf, self.k, self.line["line"], hearts=n["aff"])
            for i, oi in enumerate(self.order):
                c = self.line["choices"][oi]
                if self.g.ui.button(surf, (tx, inner.y + 124 + i * 52, inner.right - tx - 30, 44), f"{i + 1}. {c['text']}", size=17):
                    self.choose(i)
                    return
        elif self.state in ("reply", "info"):
            text = self.reply if self.state == "reply" else self.info
            inner, tx = draw_dialogue_box(self.g, surf, self.k, text, smile=self.smile, hearts=n["aff"])
            U.text(surf, "눌러서 돌아가기" if self.g.touch.enabled else "Enter / 클릭: 돌아가기", (inner.right - 20, inner.bottom - 30), 14, U.INK_SOFT, right=True)
            if self.g.ui.hit(BOX):
                self.state = "root"
                self.smile = False
        elif self.state == "gift":
            g, s = self.g, self.s
            G = D.GIFT_AFF
            inner, tx = draw_dialogue_box(g, surf, self.k, "무엇을 선물할까요? (하루 1번)", hearts=n["aff"])
            tab = getattr(self, "gtab", "prod")
            U.text(surf, f"♥ 좋아하는 것 · 제품 +{G['prod_like']} (그 밖 +{G['prod']}) · 요리 +{G['dish_like']} (그 밖 +{G['dish']})", (tx + 236, inner.y + 92), 14, U.INK_SOFT)
            for j, (key, nm) in enumerate((("prod", "제품"), ("dish", "요리"))):
                if g.ui.button(surf, (tx + j * 110, inner.y + 84, 100, 32), nm, primary=(tab == key), size=15):
                    self.gtab = tab = key
            if tab == "prod":
                have = [p for p in D.PROD_ORDER if s.products[p] > 0]
            else:
                have = [d for d in D.DISH_ORDER if s.dishes.get(d, 0) > 0]
            if not have:
                U.text(surf, "창고에 제품이 없어요." if tab == "prod" else "만든 요리가 없어요. 작업실 화덕에서 요리해 보세요.", (tx, inner.y + 136), 17, U.INK_SOFT)
            likes = D.likes_of(self.k)
            for i, p in enumerate(have[:10]):
                r = pg.Rect(tx + (i % 5) * 176, inner.y + 124 + (i // 5) * 66, 166, 58)
                pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=8)
                if tab == "prod":
                    surf.blit(A.image(f"products/{p}", height=44), (r.x + 6, r.y + 7))
                    nm, cnt, fav = D.PROD[p]["name"], s.products[p], D.PROD[p]["cat"] in likes
                else:
                    surf.blit(A.item_icon("dish:" + p, 44), (r.x + 6, r.y + 7))
                    nm, cnt, fav = D.DISH[p]["name"], s.dishes[p], p in D.DISH_LIKES.get(self.k, [])
                U.text(surf, nm, (r.x + 56, r.y + 6), 13, U.INK, width=106)
                U.text(surf, f"x{cnt}", (r.right - 8, r.bottom - 22), 13, U.INK_SOFT, right=True)
                if fav:
                    U.heart(surf, (r.x + 62, r.bottom - 14), 6)
                if g.ui.hit(r):
                    self.give(p)
                    return
            if g.ui.button(surf, (inner.right - 150, inner.bottom - 50, 130, 38), "돌아가기"):
                self.state = "root"


# ═══════════════════════ 제작 ═══════════════════════
def lock_text(s, pid):
    u = D.PROD[pid]["unlock"]
    if isinstance(u, int):
        return f"{u}장에서 해금"
    if u == "luna60":
        return "루나 호감도 60"
    return f"{D.SPEAKER[u[6:]]}의 부탁"


class CraftMenu(Menu):
    cat = None
    page = 0

    def key(self, k):
        if k == pg.K_ESCAPE:
            self.close()
        elif k in (pg.K_RIGHT, pg.K_d):
            self.page += 1
        elif k in (pg.K_LEFT, pg.K_a):
            self.page = max(0, self.page - 1)

    def draw(self, surf):
        g, s = self.g, self.s
        inner = self.panel(surf, "할머니의 레시피 노트", "한 번 저으면 제품 2개가 완성돼요. 재료 옆 숫자는 보유/필요.", style="book")
        tabs = [(None, "전체")] + [(c, D.CATS[c][0]) for c in D.CAT_ORDER]
        for i, (c, nm) in enumerate(tabs):
            if g.ui.button(surf, (inner.x + 20 + i * 150, inner.y + 84, 140, 36), nm, primary=(CraftMenu.cat == c), size=16):
                CraftMenu.cat, CraftMenu.page = c, 0
        pids = [p for p in D.PROD_ORDER if CraftMenu.cat in (None, D.PROD[p]["cat"])]
        pids.sort(key=lambda p: (not s.unlocked(p), D.PROD_ORDER.index(p)))
        per = 6
        pages = max(1, math.ceil(len(pids) / per))
        CraftMenu.page = min(CraftMenu.page, pages - 1)
        for j, pid in enumerate(pids[CraftMenu.page * per:(CraftMenu.page + 1) * per]):
            r = pg.Rect(inner.x + 20 + (j % 3) * 344, inner.y + 136 + (j // 3) * 214, 330, 200)
            un = s.unlocked(pid)
            pg.draw.rect(surf, U.PAPER_DARK if un else (215, 205, 190), r, border_radius=12)
            pg.draw.rect(surf, U.WOOD, r, 2, border_radius=12)
            p = D.PROD[pid]
            img = A.image(f"products/{pid}", height=64)
            surf.blit(img, (r.x + 12, r.y + 12))
            U.text(surf, p["name"], (r.x + 86, r.y + 12), 18, U.INK, True)
            U.text(surf, f"{D.CATS[p['cat']][0]} · {p['price']:,}원 · 재고 {s.products[pid]}", (r.x + 86, r.y + 40), 14, U.INK_SOFT)
            U.text(surf, p["desc"], (r.x + 86, r.y + 60), 13, U.INK_SOFT, width=232)
            y = r.y + 100
            x = r.x + 12
            for m, n in p["recipe"].items():
                have = s.materials.get(m, 0)
                ic = A.mat_icon(m, 22, D.MATS[m][3], D.MATS[m][0])
                surf.blit(ic, (x, y))
                t = f"{D.MATS[m][0]} {have}/{n}"
                col = (70, 130, 70) if have >= n else U.RED
                U.text(surf, t, (x + 26, y + 1), 13, col, True)
                x += 34 + A.font(13, True).size(t)[0]
                if x > r.right - 90:
                    x = r.x + 12
                    y += 26
            mx = s.max_craft(pid) if un else 0
            if not un:
                g.ui.button(surf, (r.x + 12, r.bottom - 50, r.w - 24, 38), lock_text(s, pid), False, size=15)
            else:
                if g.ui.button(surf, (r.x + 12, r.bottom - 50, 150, 38), "만들기", mx > 0, primary=True, size=16):
                    ok, msg = s.craft(pid, 1)
                    g.sfx("craft")
                    g.toast(msg)
                    g.sparkle(g.p + pg.Vector2(0, -60), (255, 160, 220), 14)
                if g.ui.button(surf, (r.x + 170, r.bottom - 50, 148, 38), f"전부 x{mx}" if mx > 1 else "전부", mx > 1, size=16):
                    ok, msg = s.craft(pid, mx)
                    g.sfx("craft")
                    g.toast(msg)
        if g.ui.button(surf, (inner.right - 250, inner.bottom - 50, 110, 38), "이전", CraftMenu.page > 0):
            CraftMenu.page -= 1
        U.text(surf, f"{CraftMenu.page + 1}/{pages}", (inner.right - 125, inner.bottom - 42), 16, U.INK, center=True)
        if g.ui.button(surf, (inner.right - 105, inner.bottom - 50, 100, 38), "다음", CraftMenu.page < pages - 1):
            CraftMenu.page += 1


# ═══════════════════════ 진열대 ═══════════════════════
class ShelfMenu(Menu):
    def __init__(self, g, i):
        super().__init__(g)
        self.i = i

    def draw(self, surf):
        g, s = self.g, self.s
        sh = s.shelves[self.i]
        t = D.SHELF_TYPES[sh["type"]]
        cat = t[1]
        inner = self.panel(surf, f"{t[0]} Lv.{sh.get('lv', 1)} · {D.CATS[cat][0]}", f"진열 {s.shelf_count(self.i)}/{s.shelf_cap(self.i)} · 같은 분류의 제품을 여러 종류 올릴 수 있어요. 손님은 진열대 여러 곳을 둘러보고 1~4개를 사 가요.")
        U.bar(surf, (inner.x + 22, inner.y + 84, 400, 14), s.shelf_count(self.i) / s.shelf_cap(self.i), U.GOLD)
        U.text(surf, "진열 중", (inner.x + 22, inner.y + 112), 18, U.INK, True)
        y = inner.y + 142
        for pid, n in list(sh["stock"].items()):
            r = pg.Rect(inner.x + 22, y, 500, 56)
            pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=8)
            surf.blit(A.image(f"products/{pid}", height=44), (r.x + 8, r.y + 6))
            U.text(surf, f"{D.PROD[pid]['name']}  x{n}", (r.x + 64, r.y + 8), 17, U.INK, True)
            U.text(surf, f"{int(s.sale_price(pid)):,}원", (r.x + 64, r.y + 32), 13, U.INK_SOFT)
            if g.ui.button(surf, (r.right - 110, r.y + 9, 100, 38), "내리기", size=15):
                s.unstock(self.i, pid)
            y += 62
        if not sh["stock"]:
            U.text(surf, "비어 있어요.", (inner.x + 22, y), 16, U.INK_SOFT)
        U.text(surf, "창고에서 올리기", (inner.x + 560, inner.y + 112), 18, U.INK, True)
        y = inner.y + 142
        cand = [p for p in D.PROD_ORDER if D.PROD[p]["cat"] == cat and s.products[p] > 0]
        full = s.shelf_count(self.i) >= s.shelf_cap(self.i)
        for pid in cand[:7]:
            r = pg.Rect(inner.x + 560, y, 500, 56)
            pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=8)
            surf.blit(A.image(f"products/{pid}", height=44), (r.x + 8, r.y + 6))
            U.text(surf, f"{D.PROD[pid]['name']}", (r.x + 64, r.y + 8), 17, U.INK, True)
            U.text(surf, f"창고 {s.products[pid]}개", (r.x + 64, r.y + 32), 13, U.INK_SOFT)
            if g.ui.button(surf, (r.right - 230, r.y + 9, 70, 38), "+1", not full, size=15):
                s.stock(self.i, pid, 1)
            if g.ui.button(surf, (r.right - 154, r.y + 9, 70, 38), "+5", not full, size=15):
                s.stock(self.i, pid, 5)
            if g.ui.button(surf, (r.right - 78, r.y + 9, 70, 38), "채우기", not full, primary=True, size=14):
                s.stock(self.i, pid, 99)
            y += 62
        if not cand:
            U.text(surf, f"창고에 {D.CATS[cat][0]} 제품이 없어요. 솥에서 만들어 보세요.", (inner.x + 560, y), 16, U.INK_SOFT)
        if g.ui.button(surf, (inner.x + 22, inner.bottom - 54, 300, 42), "모든 진열대 자동 채우기", primary=True):
            n = s.auto_stock()
            g.toast(f"{n}개를 진열했어요." if n else "올릴 제품이 없거나 진열대가 가득 찼어요.")


# ═══════════════════════ 계산대 (가구 주문 · 가격표) ═══════════════════════
class CounterMenu(Menu):
    tab = "shelf"

    def draw(self, surf):
        g, s = self.g, self.s
        inner = self.panel(surf, "계산대", "할머니의 목공소 카탈로그 · 잡화 · 가격표", style="paper")
        tabs = [("shelf", "진열대 주문"), ("place", "진열대 배치"), ("deco", "장식 주문"), ("supply", "잡화"), ("price", "가격표")]
        for i, (k, nm) in enumerate(tabs):
            if g.ui.button(surf, (inner.x + 20 + i * 170, inner.y + 84, 160, 38), nm, primary=(CounterMenu.tab == k), size=16):
                CounterMenu.tab = k
        y0 = inner.y + 140
        if CounterMenu.tab == "place":
            draw_shelf_place(self, g, surf, inner, y0)
        elif CounterMenu.tab == "shelf":
            U.text(surf, f"진열대 자리 {sum(1 for x in s.shelves if x)}/6 · 창고 {len(s.shelf_store)}개 (자리가 차면 창고로 가요 · [진열대 배치]에서 바꿔 놓기)", (inner.x + 22, y0), 16, U.INK_SOFT)
            for j, (k, t) in enumerate([(k, t) for k, t in D.SHELF_TYPES.items() if t[3] > 0]):
                r = pg.Rect(inner.x + 20 + (j % 3) * 340, y0 + 30 + (j // 3) * 190, 326, 176)
                pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=10)
                tint = {"bath": (255, 165, 200), "goods": (255, 205, 110), "stone": (150, 185, 255), "magic": (190, 150, 255)}.get(t[1])
                img = A.image_or(t[4], "props/shelf_potion", 110, tint)
                surf.blit(img, (r.x + 10, r.y + 10))
                U.text(surf, t[0], (r.x + 110, r.y + 14), 18, U.INK, True, width=206)
                U.text(surf, f"{D.CATS[t[1]][0]} · 용량 {t[2]}", (r.x + 110, r.y + 64), 14, U.INK_SOFT)
                owned = sum(1 for x in s.shelves if x and x["type"] == k) + sum(1 for x in s.shelf_store if x["type"] == k)
                U.text(surf, f"보유 {owned}", (r.x + 110, r.y + 86), 14, U.INK_SOFT)
                if g.ui.button(surf, (r.x + 110, r.bottom - 50, 200, 38), f"{t[3]:,}원 주문", s.gold >= t[3], primary=True, size=15):
                    ok, msg = s.buy_shelf(k)
                    g.toast(msg)
                    s.save()
        elif CounterMenu.tab == "deco":
            items = [(k, d) for k, d in D.DECO.items() if d[4] > 0]
            for j, (k, d) in enumerate(items):
                r = pg.Rect(inner.x + 20 + j * 340, y0 + 30, 326, 200)
                pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=10)
                surf.blit(A.image(d[5], height=110), (r.x + 10, r.y + 10))
                U.text(surf, d[0], (r.x + 130, r.y + 14), 18, U.INK, True, width=186)
                U.text(surf, f"{'벽' if d[1] == 'wall' else '바닥'} 장식 · {d[3]}", (r.x + 130, r.y + 70), 14, U.INK_SOFT, width=186)
                own = k in s.deco_owned
                if g.ui.button(surf, (r.x + 130, r.bottom - 50, 180, 38), "보유 중" if own else f"{d[4]:,}원", not own and s.gold >= d[4], primary=True, size=15):
                    s.gold -= d[4]
                    s.deco_owned.append(k)
                    g.toast(f"{d[0]}을(를) 샀어요. B(꾸미기)에서 배치하세요.")
            U.text(surf, "단골의 부탁을 들어주면 특별한 답례 장식품을 받을 수 있어요.", (inner.x + 22, y0 + 250), 16, U.INK_SOFT)
        elif CounterMenu.tab == "supply":
            U.text(surf, "한스네 수레(2장)보다 20% 비싸지만 언제든 살 수 있어요.", (inner.x + 22, y0), 16, U.INK_SOFT)
            for j, m in enumerate(["bottle", "salt"]):
                price = int(D.HANS[m][0] * 1.2)
                r = pg.Rect(inner.x + 20, y0 + 36 + j * 80, 700, 68)
                pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=10)
                surf.blit(A.mat_icon(m, 44, D.MATS[m][3], D.MATS[m][0]), (r.x + 12, r.y + 12))
                U.text(surf, f"{D.MATS[m][0]}  ·  {price:,}원  ·  보유 {s.materials[m]}", (r.x + 70, r.y + 22), 17, U.INK, True)
                for q_i, q in enumerate((1, 5, 10)):
                    if g.ui.button(surf, (r.right - 250 + q_i * 82, r.y + 14, 74, 40), f"x{q}", s.gold >= price * q, size=15):
                        s.gold -= price * q
                        s.add_mat(m, q, xp=False)
        else:
            U.text(surf, "판매 가격을 바꾸면 손님이 물건을 집을 확률도 달라져요.", (inner.x + 22, y0), 16, U.INK_SOFT)
            for j, (pm, desc) in enumerate([(90, "90% · 구매 확률 +15%"), (100, "100% · 기본"), (120, "120% · 구매 확률 -20%")]):
                if g.ui.button(surf, (inner.x + 22 + j * 260, y0 + 40, 240, 60), desc, primary=(s.price_mode == pm), size=16):
                    s.price_mode = pm


# ═══════════════════════ 게시판 ═══════════════════════
class BoardMenu(Menu):
    def __init__(self, g):
        super().__init__(g)
        g.s.refresh_orders(g.rng)

    def draw(self, surf):
        g, s = self.g, self.s
        inner = self.panel(surf, "마을 게시판", "마을 사람들의 대량 주문과 공고가 붙어요. 납품 금액은 누적 매출에 들어가요.", style="cork")
        y = inner.y + 90
        if s.chapter < 5:
            U.text(surf, "아직 붙은 쪽지가 없어요. (5장부터 대량 주문이 들어와요)", (inner.x + 24, y), 18, U.INK)
            y += 50
        for i, o in enumerate(s.orders):
            r = pg.Rect(inner.x + 24, y, 700, 76)
            pg.draw.rect(surf, (250, 240, 214), r, border_radius=6)
            pg.draw.circle(surf, (200, 60, 60), (r.x + 16, r.y + 12), 6)
            surf.blit(A.image(f"products/{o['pid']}", height=52), (r.x + 30, r.y + 12))
            U.text(surf, f"{D.SPEAKER[o['npc']]} · {D.PROD[o['pid']]['name']}", (r.x + 94, r.y + 10), 17, U.INK, True)
            U.text(surf, f"{s.products[o['pid']]}/{o['qty']}개 · 보상 {o['reward']:,}원 (단가 125%)", (r.x + 94, r.y + 40), 15, U.INK_SOFT)
            if g.ui.button(surf, (r.right - 140, r.y + 18, 124, 40), "완료" if o["done"] else "납품", not o["done"] and s.products[o["pid"]] >= o["qty"], primary=True, size=16):
                ok, msg = s.fulfill_order(i)
                g.toast(msg)
                s.save()
            y += 86
        # 장터
        x = inner.x + 760
        r = pg.Rect(x, inner.y + 90, 300, 300)
        pg.draw.rect(surf, (250, 240, 214), r, border_radius=6)
        pg.draw.circle(surf, (60, 90, 200), (r.x + 16, r.y + 12), 6)
        U.text(surf, "달빛 장터 공고", (r.x + 20, r.y + 20), 20, U.INK, True)
        m = s.market
        if s.chapter < 6:
            U.text(surf, "보름달 밤의 장터. 6장에서 열려요.", (r.x + 20, r.y + 60), 15, U.INK_SOFT, width=260)
        elif m["done"]:
            U.text(surf, f"올해 장터 결과: {'1위!' if m['rank'] == 1 else '2위'}\n다음 장터는 자유 경영 모드에서 계절마다 열릴 예정이에요.", (r.x + 20, r.y + 60), 15, U.INK_SOFT, width=260)
        elif m["signed"]:
            U.text(surf, f"참가 신청 완료! {m['day']}일 아침에 수레에 실을 제품을 고르고, 저녁 6시에 광장으로 가요.", (r.x + 20, r.y + 60), 15, U.INK_SOFT, width=260)
        else:
            U.text(surf, "참가하면 다음 날 저녁 6시~자정, 광장 부스에서 판매해요. 손님 2배, 은빛 탑 상회와 순위 경쟁!", (r.x + 20, r.y + 60), 15, U.INK_SOFT, width=260)
            if g.ui.button(surf, (r.x + 20, r.bottom - 60, 260, 44), "참가 신청", primary=True):
                m["signed"] = True
                m["day"] = s.day + 1
                g.toast("달빛 장터 참가 신청 완료! 내일 저녁이에요.")
                s.save()


# ═══════════════════════ 우편함 (v0.8) ═══════════════════════
class MailMenu(Menu):
    tab = "mail"

    def key(self, k):
        if k == pg.K_ESCAPE:
            self.close()
        elif k in (pg.K_LEFT, pg.K_RIGHT, pg.K_TAB) and self.s.flags.get("neighbor"):
            MailMenu.tab = "parcel" if MailMenu.tab == "mail" else "mail"

    def read(self, m):
        g, s = self.g, self.s
        m["read"] = True
        self.close()
        if m["kind"] == "neighbor":
            def done():
                s.flags["neighbor"] = True
                s.refresh_parcels(g.rng)
                MailMenu.tab = "parcel"
                g.toast("버들골 소포 주문이 열렸어요! 우편함에서 상자를 포장해 보내요.", 5)
                s.save()
            g.push_lines(E.NEIGHBOR["intro"], on_done=done, title="버들골에서 온 편지")
        else:
            who = D.SPEAKER.get(m["sp"], "")
            g.push_lines([("narr", f"우편함에서 {who}의 편지를 꺼내 펼쳤다."), (m["sp"], m["line"])], title="집에서 온 편지")
        s.save()

    def draw(self, surf):
        g, s = self.g, self.s
        nb = s.flags.get("neighbor")
        if not nb:
            MailMenu.tab = "mail"
        sub = ("부모님 편지는 3일마다 도착해요. 지난 편지도 언제든 다시 읽을 수 있어요." if MailMenu.tab == "mail"
               else "버들골 주문: 제품을 상자에 빈틈없이 담아 보내요. 같은 분류끼리 붙이면 정리 보너스! (새 주문은 2일마다)")
        inner = self.panel(surf, "저택 앞 우편함", sub, style="paper")
        tabs = [("mail", f"편지함 ({s.unread_mail()})" if s.unread_mail() else "편지함")]
        if nb:
            tabs.append(("parcel", "버들골 소포"))
        for j, (key, nm) in enumerate(tabs):
            if g.ui.button(surf, (inner.x + 22 + j * 170, inner.y + 76, 160, 36), nm, primary=(MailMenu.tab == key), size=16):
                MailMenu.tab = key
        if MailMenu.tab == "mail":
            self.draw_mail(surf, inner)
        else:
            self.draw_parcels(surf, inner)

    def draw_mail(self, surf, inner):
        g, s = self.g, self.s
        mails = sorted(enumerate(s.mail), key=lambda im: (im[1]["read"], -im[0]))[:7]
        if not mails:
            U.text(surf, "아직 도착한 편지가 없어요. 부모님은 3일마다 편지를 보내요.", (inner.x + 24, inner.y + 136), 17, U.INK_SOFT)
        y = inner.y + 126
        for i, m in mails:
            r = pg.Rect(inner.x + 22, y, 1000, 62)
            pg.draw.rect(surf, (250, 240, 214) if not m["read"] else U.PAPER_DARK, r, border_radius=6)
            sp = m["sp"]
            if A.exists(f"portraits/{sp}"):
                surf.blit(A.portrait(sp, 54), (r.x + 8, r.y + 4))
            else:
                surf.blit(U.icon("package", 44), (r.x + 10, r.y + 9))
            if m["kind"] == "neighbor":
                head = "버들골 잡화점 우르술라의 편지 (낯선 마을 도장)"
                prev = "옆 마을에서 물건을 보내 달라는 부탁인 것 같아요…"
            else:
                head = f"{D.SPEAKER.get(sp, '')}의 편지 · {m['day']}일째"
                prev = m["line"][:30] + ("…" if len(m["line"]) > 30 else "")
            U.text(surf, head, (r.x + 76, r.y + 8), 16, U.INK, True)
            U.text(surf, prev if m["read"] else "(아직 뜯지 않았어요)", (r.x + 76, r.y + 34), 14, U.INK_SOFT)
            if not m["read"]:
                pg.draw.circle(surf, (220, 70, 80), (r.x + 66, r.y + 10), 6)
            if g.ui.button(surf, (r.right - 130, r.y + 11, 116, 40), "읽기" if not m["read"] else "다시 읽기", primary=not m["read"], size=15):
                self.read(m)
                return
            y += 70

    def draw_parcels(self, surf, inner):
        g, s = self.g, self.s
        y = inner.y + 126
        if not s.parcels:
            U.text(surf, "지금은 주문이 없어요. 내일 다시 확인해 보세요.", (inner.x + 24, y + 10), 17, U.INK_SOFT)
        for i, o in enumerate(s.parcels):
            r = pg.Rect(inner.x + 22, y, 1000, 220)
            pg.draw.rect(surf, (250, 240, 214), r, border_radius=6)
            surf.blit(U.icon("package", 48), (r.x + 12, r.y + 10))
            U.text(surf, o["sender"], (r.x + 70, r.y + 12), 18, U.INK, True)
            U.text(surf, f"「{o['note']}」", (r.x + 70, r.y + 42), 15, U.INK_SOFT, width=640)
            x = r.x + 70
            for pid, n in o["items"].items():
                surf.blit(A.image(f"products/{pid}", height=56), (x, r.y + 84))
                have = s.products.get(pid, 0)
                U.text(surf, D.PROD[pid]["name"], (x + 62, r.y + 88), 14, U.INK, True, width=150)
                U.text(surf, f"{have}/{n}개", (x + 62, r.y + 114), 14, (70, 130, 70) if have >= n else (190, 70, 70), True)
                cells = len(D.PACK_SHAPES[D.PROD[pid]["cat"]])
                U.text(surf, f"상자 {cells}칸 × {n}", (x + 62, r.y + 134), 12, U.INK_SOFT)
                x += 230
            U.text(surf, f"기본 보상 {o['reward']:,}원 (단가 {int(D.PACK_REWARD * 100)}%) + 포장 보너스", (r.x + 70, r.bottom - 40), 15, U.LAV_DARK, True)
            if o["done"]:
                U.text(surf, "보냄 ✓", (r.right - 100, r.y + 20), 20, (70, 130, 70), True)
            elif g.ui.button(surf, (r.right - 190, r.bottom - 64, 170, 46), "포장하기", s.parcel_ready(i), primary=True, size=17):
                g.open_menu(PackingGame(g, i))
                return
            y += 232


# ═══════════════════════ 소포 포장 미니게임 (백팩 히어로 느낌) ═══════════════════════
def rot_cells(cells, r):
    for _ in range(r % 4):
        cells = [(-y, x) for x, y in cells]
    mx, my = min(x for x, y in cells), min(y for x, y in cells)
    return sorted((x - mx, y - my) for x, y in cells)


class PackingGame(Menu):
    CELL = 60

    def __init__(self, g, idx, seed=None):
        super().__init__(g)
        self.idx = idx
        o = self.s.parcels[idx]
        rng = random.Random(seed if seed is not None else (self.s.day * 31 + idx * 7 + len(o["items"])))
        self.pieces = []
        for pid, n in o["items"].items():
            cat = D.PROD[pid]["cat"]
            for _ in range(n):
                self.pieces.append(dict(pid=pid, cat=cat, rot=rng.randrange(4), at=None))
        self.build_crate(rng)
        self.held = None
        self.done = False
        self.msg = ""

    def cells(self, pc, rot=None):
        return rot_cells(D.PACK_SHAPES[pc["cat"]], pc["rot"] if rot is None else rot)

    def build_crate(self, rng):
        total = sum(len(D.PACK_SHAPES[p["cat"]]) for p in self.pieces)
        for slack in (1, 2, 3, 4, 5, 6, 8, 10, 12):
            area = total + slack
            for w in range(max(4, int(area ** 0.5)), 9):
                h = -(-area // w)
                if h > 7 or h < 4:
                    continue
                for _ in range(80):
                    grid = set()
                    ok = True
                    sol = {}
                    for pc in sorted(self.pieces, key=lambda p: -len(D.PACK_SHAPES[p["cat"]])):
                        placed = False
                        spots = [(x, y, r) for x in range(w) for y in range(h) for r in range(4)]
                        rng.shuffle(spots)
                        for x, y, r in spots:
                            cs = [(x + a, y + b) for a, b in self.cells(pc, r)]
                            if all(0 <= a < w and 0 <= b < h and (a, b) not in grid for a, b in cs):
                                grid |= set(cs)
                                sol[id(pc)] = (x, y, r)
                                placed = True
                                break
                        if not placed:
                            ok = False
                            break
                    if ok:
                        free = [(x, y) for x in range(w) for y in range(h) if (x, y) not in grid]
                        rng.shuffle(free)
                        nblock = max(0, len(free) - 2)          # 빈칸은 2칸만 남기고 칸막이로
                        self.gw, self.gh = w, h
                        self.blocked = set(free[:nblock])
                        self.solution = [sol[id(p)] for p in self.pieces]     # 풀 수 있다는 보증 (시험용)
                        return
        self.gw, self.gh, self.blocked = 8, 7, set()

    def origin(self):
        c = self.CELL
        return pg.Rect(700 - self.gw * c // 2, 400 - self.gh * c // 2 + 20, self.gw * c, self.gh * c)

    def occupied(self, skip=None):
        occ = {}
        for i, pc in enumerate(self.pieces):
            if pc["at"] is not None and i != skip:
                for a, b in self.cells(pc):
                    occ[(pc["at"][0] + a, pc["at"][1] + b)] = i
        return occ

    def fits(self, pc, at, skip=None):
        occ = self.occupied(skip)
        for a, b in self.cells(pc):
            x, y = at[0] + a, at[1] + b
            if not (0 <= x < self.gw and 0 <= y < self.gh) or (x, y) in self.blocked or (x, y) in occ:
                return False
        return True

    def cursor_cell(self):
        box = self.origin()
        mx, my = self.g.ui.mouse
        return ((mx - box.x) // self.CELL, (my - box.y) // self.CELL)

    def rotate(self):
        if self.held is not None:
            pc = self.pieces[self.held]
            pc["rot"] = (pc["rot"] + 1) % 4
            self.g.sfx("click")

    def rclick(self, pos):
        self.rotate()

    def wheel(self, dy):
        self.rotate()

    def key(self, k):
        if k == pg.K_ESCAPE:
            if self.held is not None:
                self.held = None
            else:
                self.g.open_menu(MailMenu(self.g))
        elif k in (pg.K_r, pg.K_q):
            self.rotate()
        elif k in (pg.K_RETURN, pg.K_SPACE) and self.all_placed():
            self.ship()

    def all_placed(self):
        return all(pc["at"] is not None for pc in self.pieces)

    def bonus(self):
        """같은 분류 상자끼리 맞닿은 쌍마다 +5% (최대 +30%)."""
        owner = self.occupied()
        pairs = set()
        for (x, y), i in owner.items():
            for dx, dy in ((1, 0), (0, 1)):
                j = owner.get((x + dx, y + dy))
                if j is not None and j != i and self.pieces[i]["cat"] == self.pieces[j]["cat"]:
                    pairs.add((min(i, j), max(i, j)))
        free = self.gw * self.gh - len(self.blocked) - len(owner)
        adj = min(0.30, 0.05 * len(pairs))
        return adj, 0, len(pairs), free

    def ship(self):
        g, s = self.g, self.s
        adj, full, _, _ = self.bonus()
        pay = s.ship_parcel(self.idx, adj + full)
        g.sfx("coin")
        g.close_menu()
        g.floater(g.p + pg.Vector2(0, -120), f"+{pay:,}원", icon="coin")
        g.push_lines([("narr", "상자를 끈으로 꽁꽁 묶어 우편함에 넣었다. 버들골 행 우편 마차가 곧 들른다."),
                      ("ursula", random.choice(E.NEIGHBOR["thanks"]))], title=f"소포 발송 · +{pay:,}원")
        s.save()

    def draw_piece(self, surf, pc, x0, y0, cell, alpha=255, bad=False):
        col = D.CATS[pc["cat"]][1]
        dark = tuple(max(0, c - 70) for c in col)
        cs = self.cells(pc)
        lay = pg.Surface((cell * 4, cell * 4), pg.SRCALPHA)
        for a, b in cs:
            r = pg.Rect(a * cell + 2, b * cell + 2, cell - 4, cell - 4)
            pg.draw.rect(lay, (200, 80, 80) if bad else col, r, border_radius=6)
            pg.draw.rect(lay, dark, r, 2, border_radius=6)
            pg.draw.line(lay, tuple(min(255, c + 50) for c in col), (r.x + 4, r.y + 3), (r.right - 5, r.y + 3), 2)
        bw = (max(a for a, b in cs) + 1) * cell
        bh = (max(b for a, b in cs) + 1) * cell
        # 상자 가운데 칸에 제품 그림
        a0, b0 = cs[len(cs) // 2]
        img = A.image(f"products/{pc['pid']}", height=int(cell * 0.78))
        lay.blit(img, (a0 * cell + cell // 2 - img.get_width() // 2, b0 * cell + cell // 2 - img.get_height() // 2))
        if alpha < 255:
            lay.set_alpha(alpha)
        surf.blit(lay, (x0, y0))
        return bw, bh

    def draw(self, surf):
        g, s = self.g, self.s
        o = s.parcels[self.idx]
        inner = self.panel(surf, "소포 포장하기", "상자를 클릭해 집고 · R / 오른쪽 클릭 / 휠로 돌리고 · 칸에 클릭해 넣어요. 넣은 상자를 다시 클릭하면 빼요.", style="wood")
        box = self.origin()
        c = self.CELL
        # 나무 상자
        pg.draw.rect(surf, (96, 62, 40), box.inflate(28, 28), border_radius=6)
        pg.draw.rect(surf, (150, 104, 64), box.inflate(18, 18), border_radius=4)
        for yy in range(box.y - 9, box.bottom + 9, 14):
            pg.draw.line(surf, (126, 86, 54), (box.x - 9, yy), (box.right + 8, yy))
        pg.draw.rect(surf, (226, 206, 168), box)
        for x in range(self.gw):
            for y in range(self.gh):
                r = pg.Rect(box.x + x * c, box.y + y * c, c, c)
                if (x, y) in self.blocked:
                    pg.draw.rect(surf, (120, 82, 52), r)
                    pg.draw.rect(surf, (96, 62, 40), r, 2)
                    pg.draw.line(surf, (96, 62, 40), r.topleft, r.bottomright, 2)
                    pg.draw.line(surf, (96, 62, 40), r.topright, r.bottomleft, 2)
                else:
                    pg.draw.rect(surf, (206, 184, 146), r, 1)
                    for k in range(3):            # 완충재(짚)
                        sx = r.x + 10 + (x * 17 + y * 11 + k * 19) % (c - 20)
                        sy = r.y + 10 + (x * 13 + y * 7 + k * 23) % (c - 20)
                        pg.draw.line(surf, (232, 212, 150), (sx, sy), (sx + 8, sy + 3))
        # 놓인 상자
        for i, pc in enumerate(self.pieces):
            if pc["at"] is not None and i != self.held:
                self.draw_piece(surf, pc, box.x + pc["at"][0] * c, box.y + pc["at"][1] * c, c)
        # 주문 쪽지 + 남은 상자 (왼쪽)
        tray = pg.Rect(inner.x + 16, inner.y + 96, 300, inner.h - 110)
        pg.draw.rect(surf, (238, 222, 190), tray, border_radius=8)
        U.text(surf, o["sender"], (tray.x + 12, tray.y + 10), 15, U.INK, True, width=276)
        U.text(surf, "남은 상자 (클릭해서 집기)", (tray.x + 12, tray.y + 40), 13, U.INK_SOFT)
        ty, tx = tray.y + 64, tray.x + 12
        small = 26
        rowh = 0
        for i, pc in enumerate(self.pieces):
            if pc["at"] is not None or i == self.held:
                continue
            cs = self.cells(pc)
            bw = (max(a for a, b in cs) + 1) * small
            bh = (max(b for a, b in cs) + 1) * small
            if tx + bw > tray.right - 8:
                tx, ty = tray.x + 12, ty + rowh + 10
                rowh = 0
            r = pg.Rect(tx - 3, ty - 3, bw + 6, bh + 6)
            if r.collidepoint(g.ui.mouse):
                pg.draw.rect(surf, (255, 244, 200), r, border_radius=6)
            self.draw_piece(surf, pc, tx, ty, small)
            if g.ui.hit(r) and self.held is None:
                self.held = i
            tx += bw + 12
            rowh = max(rowh, bh)
        # 보너스 · 발송
        adj, full, npairs, free = self.bonus()
        yb = tray.bottom - 150
        U.text(surf, f"정리 보너스: 같은 분류 맞닿음 {npairs}쌍 → +{int(adj * 100)}%", (tray.x + 12, yb), 13, U.INK, True, width=276)
        U.text(surf, f"남는 칸 {free}칸 (여유 칸이 조금 있어요)", (tray.x + 12, yb + 42), 13, U.INK_SOFT, width=276)
        pay = int(o["reward"] * (1 + adj + full) / 10) * 10
        U.text(surf, f"받을 돈: {pay:,}원", (tray.x + 12, yb + 70), 16, U.LAV_DARK, True)
        if g.ui.button(surf, (tray.x + 12, tray.bottom - 54, 276, 44), "발송하기 (Enter)" if self.all_placed() else "상자를 모두 넣어 주세요", self.all_placed(), primary=True, size=15):
            self.ship()
            return
        if self.held is not None and g.ui.button(surf, (box.centerx - 90, box.bottom + 22, 180, 42), "돌리기 (R)", size=15, icon="cog"):
            self.rotate()
        # 집은 상자: 커서를 따라다님
        cx, cy = self.cursor_cell()
        if self.held is not None:
            pc = self.pieces[self.held]
            inside = 0 <= cx < self.gw and 0 <= cy < self.gh
            if inside:
                ok = self.fits(pc, (cx, cy), skip=self.held)
                self.draw_piece(surf, pc, box.x + cx * c, box.y + cy * c, c, alpha=190, bad=not ok)
                if g.ui.click and box.collidepoint(g.ui.click):
                    g.ui.click = None
                    if ok:
                        pc["at"] = (cx, cy)
                        self.held = None
                        g.sfx("pop")
                    else:
                        g.sfx("error")
            else:
                mx, my = g.ui.mouse
                self.draw_piece(surf, pc, mx - c // 2, my - c // 2, c, alpha=200)
                if g.ui.click and tray.collidepoint(g.ui.click):   # 쟁반에 내려놓기
                    g.ui.click = None
                    self.held = None
        elif g.ui.click and box.collidepoint(g.ui.click):
            occ = self.occupied()
            i = occ.get((cx, cy))
            g.ui.click = None
            if i is not None:
                self.pieces[i]["at"] = None
                self.held = i
                g.sfx("click")


# ═══════════════════════ 한스네 수레 ═══════════════════════
class HansMenu(Menu):
    tab = "buy"

    def draw(self, surf):
        g, s = self.g, self.s
        s.refresh_hans()
        disc = "" if s.npc["hans"]["aff"] < 50 else (" · 단골 할인 10%" if s.npc["hans"]["aff"] >= 100 else " · 단골 할인 5%")
        inner = self.panel(surf, "한스네 수레", "\"기력 없을 땐 억지로 나가지 마라.\" 매일 아침 새로 들어와요. 되팔기는 반값." + disc, style="wood")
        surf.blit(A.portrait("hans", 150), (inner.right - 330, inner.y + 4))
        for i, (k, nm) in enumerate([("buy", "사기"), ("sell", "되팔기")]):
            if g.ui.button(surf, (inner.x + 20 + i * 150, inner.y + 84, 140, 38), nm, primary=(HansMenu.tab == k), size=16):
                HansMenu.tab = k
        mats = [m for m in D.MAT_ORDER if s.mat_unlocked(m)]
        for j, m in enumerate(mats):
            r = pg.Rect(inner.x + 20 + (j % 3) * 344, inner.y + 140 + (j // 3) * 66, 332, 58)
            pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=8)
            surf.blit(A.mat_icon(m, 40, D.MATS[m][3], D.MATS[m][0]), (r.x + 8, r.y + 9))
            if HansMenu.tab == "buy":
                left = s.hans_stock.get(m, 0)
                U.text(surf, D.MATS[m][0], (r.x + 56, r.y + 6), 16, U.INK, True)
                U.text(surf, f"{s.hans_price(m):,}원 · 남은 {left} · 보유 {s.materials[m]}", (r.x + 56, r.y + 31), 13, U.INK_SOFT)
                if g.ui.button(surf, (r.right - 124, r.y + 10, 56, 38), "+1", left > 0, size=14):
                    ok, msg = s.buy_hans(m, 1); g.toast(msg)
                if g.ui.button(surf, (r.right - 62, r.y + 10, 56, 38), "+5", left > 0, size=14):
                    ok, msg = s.buy_hans(m, 5); g.toast(msg)
            else:
                U.text(surf, D.MATS[m][0], (r.x + 56, r.y + 6), 16, U.INK, True)
                U.text(surf, f"{D.HANS[m][0] // 2:,}원 · 보유 {s.materials[m]}", (r.x + 56, r.y + 31), 13, U.INK_SOFT)
                if g.ui.button(surf, (r.right - 124, r.y + 10, 56, 38), "-1", s.materials[m] > 0, size=14):
                    ok, msg = s.sell_hans(m, 1); g.toast(msg)
                if g.ui.button(surf, (r.right - 62, r.y + 10, 56, 38), "-5", s.materials[m] > 0, size=14):
                    ok, msg = s.sell_hans(m, 5); g.toast(msg)


# ═══════════════════════ 노엘 ═══════════════════════
class NoelMenu(Menu):
    def draw(self, surf):
        g, s = self.g, self.s
        inner = self.panel(surf, "달밤의 약 가방", "영구 기력 물약. 종류마다 평생 한 병. 레벨이 오를 때도 최대 기력이 1씩 늘어요.", style="dark")
        surf.blit(A.portrait("noel", 170), (inner.right - 300, inner.y + 10))
        for j, (tid, name, plus, price, ch) in enumerate(D.TONICS):
            r = pg.Rect(inner.x + 20, inner.y + 110 + j * 92, 760, 82)
            pg.draw.rect(surf, (70, 56, 96), r, border_radius=10)
            surf.blit(A.image(f"items/{tid}", size=(60, 60), color=(120, 90, 160)), (r.x + 10, r.y + 11))
            U.text(surf, f"{name}  ·  최대 기력 +{plus}", (r.x + 84, r.y + 12), 19, U.CREAM, True)
            U.text(surf, f"{price:,}원  ·  {ch}장부터", (r.x + 84, r.y + 44), 15, (210, 200, 230))
            owned = tid in s.tonics
            label = "마심 ✓" if owned else (f"{ch}장부터" if s.chapter < ch else "구매")
            if g.ui.button(surf, (r.right - 160, r.y + 20, 140, 42), label, not owned and s.chapter >= ch and s.gold >= price, primary=True, size=16):
                ok, msg = s.buy_tonic(tid)
                g.toast(msg)
                if ok:
                    g.sparkle(g.p + pg.Vector2(0, -60), (200, 255, 200), 20)
                s.save()
        U.text(surf, f"최대 기력 = 16 + (레벨-1) + 물약 보너스  →  지금 {s.max_energy}", (inner.x + 20, inner.bottom - 40), 16, U.LAV_DARK, True)
        if g.ui.button(surf, (inner.right - 300, inner.y + 200, 240, 44), "노엘과 대화하기", primary=True, size=16):
            g.open_menu(NPCMenu(g, "noel"))


class SeedMenu(Menu):
    def __init__(self, g, i):
        super().__init__(g)
        self.i = i

    def draw(self, surf):
        g, s = self.g, self.s
        inner = self.panel(surf, "무엇을 심을까요?", "씨앗은 공짜예요. 매일 물을 주면(기력 1) 자고 일어날 때 하루씩 자라요.", rect=(240, 200, 800, 420), style="paper")
        crops = [c for c in D.CROPS if s.mat_unlocked(c)]
        for j, c in enumerate(crops):
            days, yld = D.CROPS[c]
            r = pg.Rect(inner.x + 20 + (j % 3) * 250, inner.y + 100 + (j // 3) * 90, 236, 78)
            pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=10)
            surf.blit(A.mat_icon(c, 44, D.MATS[c][3], D.MATS[c][0]), (r.x + 10, r.y + 16))
            U.text(surf, D.MATS[c][0], (r.x + 64, r.y + 12), 17, U.INK, True)
            U.text(surf, f"{days}일 · 수확 {yld}개", (r.x + 64, r.y + 42), 14, U.INK_SOFT)
            if g.ui.hit(r):
                s.plots[self.i] = {"crop": c, "days": 0, "watered": False}
                g.toast(f"{D.MATS[c][0]}을(를) 심었어요. 물을 주세요!")
                self.close()
                return


# ═══════════════════════ 낚시 ═══════════════════════
FISH_TABLE = [("waterweed", 1, 34, 0.26, 0.9), ("scale", 1, 34, 0.20, 1.0), ("jelly", 3, 14, 0.14, 1.4),
              ("clay", 3, 14, 0.22, 1.0), ("shell", 4, 5, 0.10, 1.6)]


class Fishing(Menu):
    def __init__(self, g, spot=None):
        super().__init__(g)
        self.spot = spot
        self.casts = 3
        self.got = []
        self.new_cast()

    def new_cast(self):
        s = self.s
        table = [f for f in FISH_TABLE if s.chapter >= f[1]]
        tot = sum(f[2] for f in table)
        r = random.uniform(0, tot)
        for f in table:
            r -= f[2]
            if r <= 0:
                break
        self.fish = f
        w = min(0.8, f[3] * s.totem_mult(self.spot))     # v1.0: 낚시 토템
        self.zw = w
        self.zl = random.uniform(0.05, 0.95 - w)
        self.t = random.uniform(0, 3)
        self.phase = "wait"
        self.wait = random.uniform(0.6, 1.6) * (0.55 if s.totem_mult(self.spot) >= D.TOTEM_BONUS[2] else 1)
        self.result = None
        self.res_t = 0

    def marker(self):
        return (math.sin(self.t * 2.4 * self.fish[4]) + 1) / 2

    def update(self, dt):
        if self.phase == "wait":
            self.wait -= dt
            if self.wait <= 0:
                self.phase = "bar"
        elif self.phase == "bar":
            self.t += dt
        elif self.phase == "result":
            self.res_t -= dt
            if self.res_t <= 0:
                if self.casts <= 0:
                    self.phase = "done"
                else:
                    self.new_cast()

    def reel(self):
        s = self.s
        if self.phase != "bar":
            return
        m = self.marker()
        self.casts -= 1
        if self.zl <= m <= self.zl + self.zw:
            c = self.zl + self.zw / 2
            perfect = abs(m - c) <= self.zw * 0.15
            n = 2 if perfect else 1
            if s.placed("pebble") and random.random() < 0.2:
                n *= 2
            mid = self.fish[0]
            s.add_mat(mid, n)
            s.stat("gathered", n)
            if mid == "scale":
                s.stat("fish_scale", n)
            self.got.append((mid, n))
            self.result = ("완벽해요! " if perfect else "낚았다! ") + f"{D.MATS[mid][0]} +{n}"
            if random.random() < (0.6 if perfect else 0.4):
                s.add_food("fish", 1)
                self.got.append(("food:fish", 1))
                self.result += "  · 덤: 강 송어 +1"
            self.g.sfx("splash")
            self.g.sfx("sparkle" if perfect else "pop")
        else:
            self.result = "놓쳤어요…"
            self.g.sfx("error")
        self.phase = "result"
        self.res_t = 0.9

    def key(self, k):
        if k in CONFIRM_KEYS:
            if self.phase == "done":
                self.close()
            else:
                self.reel()
        elif k == pg.K_ESCAPE:
            self.close()

    def draw(self, surf):
        g, t = self.g, self.g.t
        r = pg.Rect(W // 2 - 400, 130, 800, 540)
        inner = g.ui.frame(surf, r, "paper")
        U.ribbon(surf, (r.centerx, r.y - 2), "반짝이는 강가 · 낚시", size=24)
        if close_button(g, surf, (inner.right - 44, inner.y + 2)):
            self.close()
            return
        # ── 물 장면 (픽셀 띠 그라데이션 + 물결 + 갈대 + 찌)
        scene = pg.Rect(inner.x + 16, inner.y + 70, inner.w - 32, 196)
        night = self.s.hour >= 18
        top, bot = ((40, 52, 110), (20, 30, 70)) if night else ((96, 170, 214), (44, 110, 168))
        for i in range(0, scene.h, 6):
            k = i / scene.h
            c = tuple(int(top[j] * (1 - k) + bot[j] * k) for j in range(3))
            pg.draw.rect(surf, c, (scene.x, scene.y + i, scene.w, 6))
        for i in range(9):   # 반짝이는 물결
            wx = scene.x + (i * 97 + t * 18 * (1 + i % 3)) % scene.w
            wy = scene.y + 20 + (i * 53) % (scene.h - 40)
            pg.draw.rect(surf, (200, 230, 250) if not night else (140, 160, 220), (wx, wy, 14, 2))
            pg.draw.rect(surf, (200, 230, 250) if not night else (140, 160, 220), (wx + 4, wy - 2, 6, 2))
        for side in (0, 1):  # 갈대
            for k in range(5):
                x = scene.x + 10 + k * 9 if side == 0 else scene.right - 14 - k * 9
                hgt = 50 + (k * 17) % 30
                sway = math.sin(t * 1.5 + k) * 3
                pg.draw.line(surf, (70, 120, 70), (x, scene.bottom), (x + sway, scene.bottom - hgt), 3)
                pg.draw.rect(surf, (140, 100, 60), (x + sway - 2, scene.bottom - hgt - 10, 5, 12))
        # 물고기 그림자 (입질 대상)
        cx, cy = scene.centerx, scene.centery + 10
        if self.phase in ("wait", "bar"):
            a = t * (0.8 if self.phase == "wait" else 2.2)
            rad = 70 if self.phase == "wait" else 26
            fx, fy = cx + math.cos(a) * rad, cy + 30 + math.sin(a) * rad * 0.35
            sh = pg.Surface((56, 22), pg.SRCALPHA)
            pg.draw.ellipse(sh, (10, 20, 50, 90), (0, 4, 44, 14))
            pg.draw.polygon(sh, (10, 20, 50, 90), [(40, 11), (55, 3), (55, 19)])
            if math.cos(a) > 0:
                sh = pg.transform.flip(sh, True, False)
            surf.blit(sh, (fx - 28, fy - 11))
        # 찌
        bob = math.sin(t * 3) * 2
        dip = 0
        if self.phase == "bar":
            dip = 6 + math.sin(t * 18) * 3
            rr = int(18 + (t * 40) % 30)
            pg.draw.ellipse(surf, (220, 240, 255), (cx - rr, cy + 8 - rr // 4, rr * 2, rr // 2), 2)
        by = cy + bob + dip
        pg.draw.line(surf, (230, 230, 230), (cx, scene.y), (cx, by - 14), 1)
        pg.draw.rect(surf, (40, 30, 40), (cx - 6, by - 14, 12, 16))
        pg.draw.rect(surf, (230, 70, 80), (cx - 5, by - 13, 10, 7))
        pg.draw.rect(surf, (250, 250, 250), (cx - 5, by - 6, 10, 7))
        pg.draw.ellipse(surf, (200, 230, 250), (cx - 14, cy + 4, 28, 6), 1)
        if self.phase == "bar":
            U.tag(surf, (cx + 16, by - 50, 34, 34), fill=(255, 226, 120), edge=U.INK, inner=False)
            tt = A.font(24, True).render("!", False, U.INK)
            surf.blit(tt, (cx + 33 - tt.get_width() // 2, by - 48))
        elif self.phase == "wait":
            U.outlined(surf, "찌를 바라보는 중…", (cx, scene.bottom - 22), 16, U.CREAM, (20, 30, 60))
        pg.draw.rect(surf, U.INK, scene, 2)
        # ── 캐스팅 남은 횟수
        U.text(surf, "남은 캐스팅", (inner.x + 20, scene.bottom + 16), 15, U.INK, True)
        for i in range(3):
            ok = i < self.casts
            ic = U.icon("fish", 24, (70, 130, 190) if ok else (190, 180, 170))
            surf.blit(ic, (inner.x + 130 + i * 30, scene.bottom + 12))
        U.text(surf, "초록 칸에서 Space · 클릭!  가운데 금색이면 2개", (inner.right - 20, scene.bottom + 16), 15, U.INK_SOFT, right=True)
        # ── 타이밍 막대 (종이 칸)
        bar = pg.Rect(inner.x + 40, scene.bottom + 92, inner.w - 80, 34)
        pg.draw.rect(surf, (120, 100, 90), bar.move(0, 3))
        pg.draw.rect(surf, (226, 210, 182), bar)
        if self.phase in ("bar", "result"):
            z = pg.Rect(bar.x + bar.w * self.zl, bar.y, bar.w * self.zw, bar.h)
            pg.draw.rect(surf, (130, 200, 130), z)
            pg.draw.rect(surf, (90, 160, 100), (z.x, z.y, z.w, 4))
            c = pg.Rect(z.centerx - z.w * 0.15, bar.y, z.w * 0.3, bar.h)
            pg.draw.rect(surf, (246, 206, 90), c)
            mx = bar.x + bar.w * self.marker()
            ic = A.mat_icon(self.fish[0], 32, D.MATS[self.fish[0]][3], D.MATS[self.fish[0]][0])
            surf.blit(ic, (mx - 16, bar.y - 40 + math.sin(t * 10) * 2))
            pg.draw.polygon(surf, U.INK, [(mx - 7, bar.y - 8), (mx + 7, bar.y - 8), (mx, bar.y + 2)])
            pg.draw.rect(surf, U.INK, (mx - 2, bar.y, 4, bar.h))
        pg.draw.rect(surf, U.INK, bar, 2)
        if self.result:
            ok = not self.result.startswith("놓")
            U.text(surf, self.result, (bar.centerx, bar.bottom + 14), 20, U.LAV_DARK if ok else (150, 90, 100), True, center=True)
        # ── 잡은 것 (슬롯)
        U.text(surf, "잡은 것", (inner.x + 20, inner.bottom - 58), 15, U.INK, True)
        for i, (mid, n) in enumerate(self.got[:9]):
            sr = pg.Rect(inner.x + 96 + i * 60, inner.bottom - 72, 52, 52)
            U.slot(surf, sr)
            surf.blit(A.item_icon(mid, 32), (sr.x + 10, sr.y + 8))
            U.text(surf, f"x{n}", (sr.right - 6, sr.bottom - 18), 12, U.INK, True, right=True)
        if self.phase == "done":
            if g.ui.button(surf, (inner.right - 200, inner.bottom - 60, 180, 44), "돌아가기", primary=True):
                self.close()
        elif g.ui.hit(scene) or g.ui.hit(bar.inflate(0, 60)):
            self.reel()


# ═══════════════════════ 부엌 · 요리 (v0.7) ═══════════════════════
def draw_food_panel(g, surf, inner, y0, cook=False):
    """요리 재료 줄 + 요리 카드 6장. cook=True면 [요리하기] 버튼도."""
    s = g.s
    U.text(surf, "요리 재료", (inner.x + 22, y0), 16, U.INK, True)
    x = inner.x + 120
    for f in D.FOOD_ORDER:
        r = pg.Rect(x, y0 - 10, 150, 40)
        pg.draw.rect(surf, U.PAPER_DARK, r)
        surf.blit(A.item_icon("food:" + f, 30), (r.x + 6, r.y + 5))
        U.text(surf, f"{D.FOODS[f][0]} {s.food.get(f, 0)}", (r.x + 42, r.y + 12), 13, U.INK, True)
        x += 158
    U.text(surf, f"오늘 먹은 횟수 {s.eaten_today}/{D.EAT_PER_DAY} · 기력 {s.energy}/{s.max_energy}", (inner.right - 24, y0 + 40), 14, U.LAV_DARK, True, right=True)
    for j, did in enumerate(D.DISH_ORDER):
        d = D.DISH[did]
        r = pg.Rect(inner.x + 20 + (j % 3) * 344, y0 + 66 + (j // 3) * 200, 330, 188)
        pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=12)
        pg.draw.rect(surf, U.WOOD, r, 2, border_radius=12)
        surf.blit(A.item_icon("dish:" + did, 64), (r.x + 12, r.y + 12))
        U.text(surf, d["name"], (r.x + 88, r.y + 12), 18, U.INK, True)
        q = s.dq(did)
        qtxt = "".join(f" {D.COOK_Q[k + 1][3]}{q[k]}" for k in (2, 1) if q[k])
        U.text(surf, f"기력 +{d['energy']} · 가진 것 {s.dishes.get(did, 0)}{qtxt}", (r.x + 88, r.y + 40), 14, U.LAV_DARK, True)
        U.text(surf, d["desc"], (r.x + 88, r.y + 62), 13, U.INK_SOFT, width=232)
        x, y = r.x + 12, r.y + 96
        for f, n in d["need"].items():
            have = s.food.get(f, 0)
            surf.blit(A.item_icon("food:" + f, 22), (x, y))
            t = f"{D.FOODS[f][0]} {have}/{n}"
            U.text(surf, t, (x + 26, y + 3), 13, (70, 130, 70) if have >= n else U.RED, True)
            x += 34 + A.font(13, True).size(t)[0]
            if x > r.right - 110:
                x, y = r.x + 12, y + 24
        bw = 150 if cook else r.w - 24
        if cook and g.ui.button(surf, (r.x + 12, r.bottom - 48, bw, 38), "요리하기", s.max_cook(did) > 0, primary=True, size=15):
            if s.cook_take(did):                      # v1.0: 냄비 젓기 미니게임으로 품질 결정
                g.sfx("pop")
                g.open_menu(StirGame(g, did))
                return
        can_eat = s.dishes.get(did, 0) > 0 and s.eaten_today < D.EAT_PER_DAY and s.energy < s.max_energy
        ex = r.x + 12 + (bw + 8 if cook else 0)
        if g.ui.button(surf, (ex, r.bottom - 48, (r.w - 24 - bw - 8) if cook else bw, 38), "먹기", can_eat, size=15):
            ok, msg = s.eat(did)
            g.toast(msg)
            if ok:
                g.sfx("heart")
                g.floater(g.p + pg.Vector2(0, -110), msg.split(". ")[-1], (255, 170, 190), icon="dish:" + did)


class CookMenu(Menu):
    def draw(self, surf):
        g, s = self.g, self.s
        inner = self.panel(surf, "리라의 부엌", "요리 재료는 재료를 모을 때 '덤'으로 생겨요 (텃밭 · 낚시 · 숲 · 한스네 수레). 먹으면 기력이 차요. 하루 3번까지!", style="paper")
        draw_food_panel(g, surf, inner, inner.y + 100, cook=True)


# ═══════════════════════ 가방 · 도감 ═══════════════════════
class Bag(Menu):
    tab = "mats"

    def draw(self, surf):
        g, s = self.g, self.s
        inner = self.panel(surf, "가방", f"{s.day}일째 · 기력 {s.energy}/{s.max_energy} · 보유금 {s.gold:,}원", style="book")
        for i, (k, nm) in enumerate([("mats", "재료"), ("prods", "제품"), ("food", "요리"), ("dex", "도감")]):
            if g.ui.button(surf, (inner.x + 20 + i * 150, inner.y + 84, 140, 38), nm, primary=(Bag.tab == k), size=16):
                Bag.tab = k
        y0 = inner.y + 138
        if Bag.tab == "mats":
            for j, m in enumerate(D.MAT_ORDER):
                r = pg.Rect(inner.x + 20 + (j % 4) * 258, y0 + (j // 4) * 90, 246, 80)
                un = s.mat_unlocked(m)
                pg.draw.rect(surf, U.PAPER_DARK if un else (215, 205, 190), r, border_radius=10)
                surf.blit(A.mat_icon(m, 48, D.MATS[m][3], D.MATS[m][0]), (r.x + 10, r.y + 16))
                U.text(surf, D.MATS[m][0] if un else "???", (r.x + 68, r.y + 12), 17, U.INK, True)
                U.text(surf, f"보유 {s.materials[m]}" if un else f"{D.MATS[m][2]}장에서 발견", (r.x + 68, r.y + 36), 14, U.INK_SOFT)
                if un:
                    U.text(surf, D.MAT_SOURCES.get(m, ""), (r.x + 68, r.y + 56), 11, U.LAV_DARK, width=172)
            U.text(surf, f"마력 부스러기 주머니 {s.shards}개 · 작업실 마도석 세공대에서 합쳐요 (숲 슬라임 · 마력 바위 · 통발)", (inner.x + 22, inner.bottom - 30), 14, U.LAV_DARK, True)
        elif Bag.tab == "food":
            draw_food_panel(g, surf, inner, y0)
        elif Bag.tab == "prods":
            have = [p for p in D.PROD_ORDER if s.products[p] > 0]
            if not have:
                U.text(surf, "창고에 제품이 없어요.", (inner.x + 22, y0), 17, U.INK_SOFT)
            for j, p in enumerate(have[:24]):
                r = pg.Rect(inner.x + 20 + (j % 4) * 258, y0 + (j // 4) * 74, 246, 66)
                pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=10)
                surf.blit(A.image(f"products/{p}", height=52), (r.x + 8, r.y + 7))
                U.text(surf, D.PROD[p]["name"], (r.x + 68, r.y + 8), 15, U.INK, True, width=170)
                U.text(surf, f"x{s.products[p]} · {D.PROD[p]['price']:,}원", (r.x + 68, r.y + 38), 13, U.INK_SOFT)
        else:
            made = [p for p in D.PROD_ORDER if s.stats.get("craft:" + p)]
            U.text(surf, f"제품 도감 {len(made)}/30 · 재료 {sum(1 for m in D.MAT_ORDER if s.materials[m] or s.mat_unlocked(m))}/18", (inner.x + 22, y0 - 4), 17, U.INK, True)
            for j, p in enumerate(D.PROD_ORDER):
                r = pg.Rect(inner.x + 20 + (j % 10) * 104, y0 + 30 + (j // 10) * 130, 96, 120)
                pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=8)
                img = A.image(f"products/{p}", height=62)
                if p not in made:
                    img = img.copy()
                    img.fill((40, 30, 40, 255), special_flags=pg.BLEND_RGBA_MIN)
                surf.blit(img, (r.centerx - img.get_width() // 2, r.y + 8))
                U.text(surf, D.PROD[p]["name"] if p in made else "???", (r.centerx, r.y + 76), 12, U.INK, center=True, width=90)


# ═══════════════════════ 장 목표 ═══════════════════════
class Goals(Menu):
    def draw(self, surf):
        g, s = self.g, self.s
        ch = s.chapter
        inner = self.panel(surf, f"제 {ch}장 · {D.CHAPTERS[ch - 1][1]}", "장 목표는 진행을 막지 않는 추가 보상이에요. 다음 장은 누적 매출로 열려요.", style="book")
        nxt = next((c for c in D.CHAPTERS if c[0] == ch + 1), None)
        y = inner.y + 96
        if nxt:
            U.text(surf, f"다음 장 「{nxt[1]}」까지: 누적 매출 {s.total_revenue:,} / {nxt[2]:,}원", (inner.x + 22, y), 18, U.INK, True)
            U.bar(surf, (inner.x + 22, y + 32, 700, 16), s.total_revenue / nxt[2], U.GOLD)
        else:
            U.text(surf, "모든 장을 열었어요. 자유 경영 모드!" if s.free else "마지막 장이에요.", (inner.x + 22, y), 18, U.INK, True)
        if ch == 6 and not s.market["done"]:
            U.text(surf, "※ 마지막 장은 누적 매출 200만 원 + 달빛 장터를 마친 뒤 열려요.", (inner.x + 22, y + 54), 14, U.LAV_DARK, True)
        y += 80
        goals = D.GOALS.get(ch, [])
        for desc, key, n in goals:
            v = min(n, s.goal_value(key))
            r = pg.Rect(inner.x + 22, y, 700, 52)
            pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=8)
            U.text(surf, ("✓ " if v >= n else "□ ") + desc, (r.x + 14, r.y + 13), 18, (70, 130, 70) if v >= n else U.INK, True)
            U.text(surf, f"{v}/{n}", (r.right - 16, r.y + 14), 17, U.INK_SOFT, right=True)
            y += 60
        if goals:
            claimed = ch in s.goals_claimed
            rew = D.GOAL_REWARD[ch][0]
            if g.ui.button(surf, (inner.x + 22, y + 10, 400, 46), "보상 받음 ✓" if claimed else f"보상 받기 · {rew}", s.goals_done(ch) and not claimed, primary=True, size=16):
                name = s.claim_goals(ch)
                g.toast(f"장 목표 보상: {name}")
                if ch == 1:
                    g.toast("오늘부터 3일마다 저녁, 저택 앞 등불 아래에 누군가 찾아온대요.")
                s.save()
        # 지난 장 목표 중 못 받은 보상
        y = inner.y + 96
        x = inner.x + 760
        U.text(surf, "지난 장 보상", (x, y), 18, U.INK, True)
        for c in range(1, ch):
            if c in D.GOALS:
                done = s.goals_done(c)
                cl = c in s.goals_claimed
                lab = f"{c}장 · {'받음' if cl else ('받기' if done else '미완료')}"
                if g.ui.button(surf, (x, y + 36 + (c - 1) * 48, 280, 40), lab, done and not cl, size=15):
                    g.toast(f"장 목표 보상: {s.claim_goals(c)}")
        # v0.8: 지난 장 이야기도 모두 다시 볼 수 있어요
        U.text(surf, "이야기 다시 보기", (x, inner.bottom - 172), 16, U.INK, True)
        for c in range(1, 8):
            rr = (x + ((c - 1) % 4) * 70, inner.bottom - 142 + ((c - 1) // 4) * 50, 64, 42)
            if g.ui.button(surf, rr, f"{c}장", c in s.story_seen, size=15):
                self.close()
                if A.exists(f"story/chapter_{c}"):
                    g.queue.append(lambda c=c: g.open_menu(ChapterCard(g, c)))
                g.push_lines(S.CHAPTER_SCRIPT[c], title=f"제 {c}장 · {D.CHAPTERS[c - 1][1]}")


# ═══════════════════════ 인물 목록 (R) ═══════════════════════
class Notebook(Menu):
    """v0.8: 단골 수첩 → 인물 목록. [주변인] 엄마·아빠·할머니·루나·노엘 / [단골] 기존 수첩."""
    tab = "near"

    def key(self, k):
        if k == pg.K_ESCAPE or k == pg.K_r:
            self.close()
        elif k in (pg.K_LEFT, pg.K_RIGHT, pg.K_TAB, pg.K_a, pg.K_d):
            Notebook.tab = "regular" if Notebook.tab == "near" else "near"

    def draw(self, surf):
        g, s = self.g, self.s
        sub = ("가족과 가게 식구들. 루나를 쓰다듬으면(H) 루나 레벨이 올라 리라의 마법이 진화해요." if Notebook.tab == "near"
               else "호감도와 부탁 진행 상황. 대화는 하루 1번 · 기본 호감도 +5, 좋은 대답은 더 올라요.")
        inner = self.panel(surf, "인물 목록", sub, style="book")
        for j, (key, nm) in enumerate((("near", "주변인"), ("regular", "단골"))):
            if g.ui.button(surf, (inner.x + 22 + j * 150, inner.y + 76, 140, 36), nm, primary=(Notebook.tab == key), size=16):
                Notebook.tab = key
        U.text(surf, "← → 탭 바꾸기", (inner.x + 330, inner.y + 86), 13, U.INK_SOFT)
        if Notebook.tab == "near":
            self.draw_near(surf, inner)
        else:
            self.draw_regular(surf, inner)

    def card(self, surf, inner, j):
        r = pg.Rect(inner.x + 20 + (j % 3) * 344, inner.y + 124 + (j // 3) * 246, 330, 232)
        pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=12)
        return r

    def draw_near(self, surf, inner):
        s = self.s
        people = [("mom", "엄마", "portraits/mom"), ("dad", "아빠", "portraits/dad"), ("grandma", "할머니", "props/grandma_portrait"),
                  ("luna", "루나", "portraits/luna"), ("noel", "노엘 브라이어", "portraits/noel"), ("bram", "브람 코퍼", "portraits/bram")]
        for j, (k, name, pic) in enumerate(people):
            r = self.card(surf, inner, j)
            if k == "noel" and not s.noel_met:
                U.text(surf, "???", (r.x + 20, r.y + 20), 22, U.INK_SOFT, True)
                U.text(surf, "1장 목표를 마치면 만나요", (r.x + 20, r.y + 60), 15, U.INK_SOFT)
                continue
            if k == "bram" and not s.flags.get("bram_met"):
                U.text(surf, "???", (r.x + 20, r.y + 20), 22, U.INK_SOFT, True)
                U.text(surf, "2장부터 마을 길가 공방 수레에서 만나요", (r.x + 20, r.y + 60), 15, U.INK_SOFT, width=290)
                continue
            img = A.image(pic, height=130)
            if img.get_width() > 120:
                img = pg.transform.smoothscale(img, (120, int(img.get_height() * 120 / img.get_width())))
            surf.blit(img, (r.x + 8, r.y + 24))
            x = r.x + 136
            U.text(surf, name, (x, r.y + 14), 19, U.INK, True)
            y = r.y + 48
            if k in ("mom", "dad"):
                got = sum(1 for m in s.mail if m["kind"] == "letter" and m["sp"] == k)
                U.text(surf, f"받은 편지 {got}통", (x, y), 14, U.LAV_DARK, True)
                nxt = max(0, D.LETTER_EVERY - (s.day - s.last_letter_day))
                U.text(surf, "다음 편지: " + ("내일 아침쯤" if nxt <= 1 else f"{nxt}일 뒤"), (x, y + 22), 13, U.INK_SOFT)
                y += 48
            elif k == "grandma":
                seen = len(s.story_seen)
                U.text(surf, f"읽은 이야기 {seen}/7장", (x, y), 14, U.LAV_DARK, True)
                y += 26
            elif k == "luna":
                lv, tier = s.luna_level, s.magic_tier
                U.text(surf, f"루나 Lv.{lv} · 호감도 {s.luna}", (x, y), 14, U.LAV_DARK, True)
                U.bar(surf, (x, y + 22, 170, 8), (s.luna % 10) / 10 if lv < 10 else 1, (236, 90, 130))
                T = D.MAGIC_TIERS[tier]
                U.text(surf, f"마법: {T[1]} ({T[2]}타)", (x, y + 36), 13, U.INK)
                if tier + 1 < len(D.MAGIC_TIERS):
                    N = D.MAGIC_TIERS[tier + 1]
                    U.text(surf, f"다음: Lv.{N[0]} {N[1]} ({N[2]}타)", (x, y + 56), 12, U.INK_SOFT, width=186)
                U.text(surf, "오늘 쓰다듬기: " + ("했어요" if s.luna_petted else "아직 (H)"), (x, y + 78), 12, U.INK_SOFT)
                y += 100
            elif k == "bram":
                U.text(surf, f"호감도 {s.npc['bram']['aff']}", (x, y), 14, U.LAV_DARK, True)
                U.text(surf, "매일 8시~19시, 텃밭 아래 길가 공방 수레", (x, y + 22), 12, U.INK_SOFT, width=186)
                y += 48
            elif k == "noel":
                U.text(surf, f"산 기력 물약 {len(s.tonics)}/{len(D.TONICS)}", (x, y), 14, U.LAV_DARK, True)
                U.text(surf, "3일마다 저녁 6시~, 저택 앞 등불 아래", (x, y + 22), 12, U.INK_SOFT, width=186)
                y += 48
            for line in E.FAMILY.get(k, [])[:3]:
                y = U.text(surf, line, (x, y), 12, U.INK_SOFT, width=186) + 3
                if y > r.bottom - 16:
                    break

    def draw_regular(self, surf, inner):
        s = self.s
        for j, k in enumerate(D.NPC_ORDER):
            n = s.npc[k]
            r = self.card(surf, inner, j)
            if not n["met"]:
                pg.draw.rect(surf, (215, 205, 190), r, border_radius=12)
                U.text(surf, "???", (r.x + 20, r.y + 20), 22, U.INK_SOFT, True)
                U.text(surf, f"{D.NPCS[k]['met']}장에서 만나요", (r.x + 20, r.y + 60), 15, U.INK_SOFT)
                continue
            surf.blit(A.portrait(k, 140), (r.x + 8, r.y + 20))
            x = r.x + 130
            U.text(surf, D.NPCS[k]["name"], (x, r.y + 14), 19, U.INK, True)
            for i in range(5):
                U.heart(surf, (x + 12 + i * 30, r.y + 56), 9, (236, 90, 130) if n["aff"] >= (i + 1) * 20 else (190, 170, 170))
            U.text(surf, f"호감도 {n['aff']}", (x, r.y + 72), 14, U.INK_SOFT)
            U.text(surf, "좋아해요: " + ", ".join(D.CATS[c][0] for c in D.NPCS[k]["likes"]), (x, r.y + 92), 13, U.INK_SOFT, width=190)
            U.text(surf, "좋아하는 요리: " + ", ".join(D.DISH[d]["name"] for d in D.DISH_LIKES.get(k, [])), (x, r.y + 112), 12, U.INK_SOFT, width=190)
            q = n["quest"]
            qs = {"none": "부탁: 아직" if not s.quest_available(k) else "부탁: 들을 수 있어요!", "active": "부탁: 진행 중", "done": "부탁: 완료 ✓"}[q]
            U.text(surf, qs, (x, r.y + 152), 14, U.LAV_DARK, True, width=190)
            U.text(surf, "오늘 대화: " + ("했어요" if n["talked"] == s.day else "아직"), (x, r.y + 176), 13, U.INK_SOFT)
            U.text(surf, f"집: {'텃밭 옆' if k == 'hans' else '강가 남쪽' if k == 'momo' else '길가' if k == 'mignon' else '숲 입구' if k == 'kai' else '다리 옆' if k == 'theo' else '저택 정원'}", (x, r.y + 196), 13, U.INK_SOFT)


# ═══════════════════════ 꾸미기 ═══════════════════════
class Decorate(Menu):
    def draw(self, surf):
        g, s = self.g, self.s
        inner = self.panel(surf, "우리 가게 꾸미기", f"명성 {s.rep} · 장식 효과는 가게에 놓았을 때만 켜져요. 벽 장식은 뒷벽 걸이 칸에, 바닥 장식은 매장 격자에.", style="paper")
        if not s.deco_owned:
            U.text(surf, "아직 장식품이 없어요. 단골 부탁을 들어주거나 계산대에서 주문하세요.", (inner.x + 22, inner.y + 100), 17, U.INK_SOFT)
        for j, d in enumerate(s.deco_owned):
            info = D.DECO[d]
            r = pg.Rect(inner.x + 20 + (j % 3) * 344, inner.y + 96 + (j // 3) * 150, 330, 140)
            pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=12)
            surf.blit(A.image(info[5], height=100), (r.x + 10, r.y + 20))
            U.text(surf, info[0], (r.x + 120, r.y + 12), 17, U.INK, True, width=200)
            U.text(surf, f"{'벽' if info[1] == 'wall' else '바닥'} · 명성 +{info[2]}\n{info[3]}", (r.x + 120, r.y + 42), 13, U.INK_SOFT, width=200)
            placed = d in s.deco_placed
            if g.ui.button(surf, (r.x + 120, r.bottom - 44, 96, 36), "옮기기" if placed else "배치", primary=True, size=14):
                g.placing = d
                self.close()
                return
            if g.ui.button(surf, (r.x + 224, r.bottom - 44, 96, 36), "보관", placed, size=14):
                del s.deco_placed[d]


# ═══════════════════════ 하루 결산 ═══════════════════════
WHY = {"noshelf": "그 분류 진열대가 없어서", "empty": "진열대가 비어서", "expensive": "너무 비싸서", "browse": "둘러보기만 하고"}


class Report(Menu):
    def key(self, k):
        if k in (pg.K_RETURN, pg.K_KP_ENTER):
            self.sleep()
        elif k == pg.K_ESCAPE:
            self.close()

    def sleep(self):
        self.close()
        self.g.do_sleep()

    def draw(self, surf):
        g, s = self.g, self.s
        L = s.log
        inner = self.panel(surf, f"{s.day}일째 · 리라의 영업 일지", "잠들면 기력이 회복되고, 물을 준 작물이 자라요.", style="book")
        U.text(surf, f"오늘 매출 {L['revenue']:,}원", (inner.x + 22, inner.y + 96), 30, U.LAV_DARK, True)
        U.text(surf, f"손님 {L['visitors']}명 · 판매 {sum(L['sold'].values())}개 · 누적 {s.total_revenue:,}원", (inner.x + 24, inner.y + 140), 17, U.INK)
        y = inner.y + 180
        U.text(surf, "팔린 제품", (inner.x + 22, y), 18, U.INK, True)
        x = inner.x + 22
        y += 30
        for p, n in sorted(L["sold"].items(), key=lambda kv: -kv[1])[:12]:
            surf.blit(A.image(f"products/{p}", height=36), (x, y))
            U.text(surf, f"x{n}", (x + 40, y + 8), 15, U.INK, True)
            x += 90
            if x > inner.x + 600:
                x = inner.x + 22
                y += 44
        if not L["sold"]:
            U.text(surf, "—", (x, y), 16, U.INK_SOFT)
        y += 56
        U.text(surf, "그냥 돌아간 손님", (inner.x + 22, y), 18, U.INK, True)
        y += 30
        if not L["missed"]:
            U.text(surf, "없어요! 모두 뭔가를 사 갔어요.", (inner.x + 22, y), 15, U.INK_SOFT)
        for k, n in list(L["missed"].items())[:5]:
            cat, why = k.split("|")
            U.text(surf, f"· {D.CATS.get(cat, ('?',))[0]}을(를) 찾던 손님 {n}명 — {WHY.get(why, why)}", (inner.x + 22, y), 15, U.INK)
            y += 24
        # 오른쪽: 단골
        x = inner.x + 700
        U.text(surf, "오늘 온 단골", (x, inner.y + 96), 18, U.INK, True)
        yy = inner.y + 130
        for k, n, gain in L["regulars"]:
            surf.blit(A.portrait(k, 48), (x, yy))
            U.text(surf, f"{D.NPCS[k]['name']} · {n}개 구매" + (f" · 호감도 +{gain}" if gain else ""), (x + 50, yy + 12), 15, U.INK)
            yy += 56
        if not L["regulars"]:
            U.text(surf, "—", (x, yy), 15, U.INK_SOFT)
        nxt = s.next_chapter_due()
        if nxt:
            U.text(surf, f"✦ 잠들면 제 {nxt}장이 시작돼요!", (x, inner.bottom - 110), 18, U.LAV_DARK, True)
        if g.ui.button(surf, (inner.right - 300, inner.bottom - 60, 280, 48), "잠들기 (Enter)", primary=True):
            self.sleep()


# ═══════════════════════ 장터 ═══════════════════════
class MarketPrep(Menu):
    def __init__(self, g):
        super().__init__(g)
        self.cart = {}
        self.helpers = []

    def key(self, k):
        pass

    def confirm(self):
        s = self.s
        for p, n in self.cart.items():
            s.products[p] -= n
        s.market["cart"] = dict(self.cart)
        s.market["helpers"] = list(self.helpers)
        self.close()
        self.g.toast("수레 준비 완료! 저녁 6시에 광장으로 출발해요.")
        s.save()

    def draw(self, surf):
        g, s = self.g, self.s
        inner = self.panel(surf, "달빛 장터 준비", "수레에 실을 제품 최대 6종(종류당 10개)과 도와줄 단골 2명을 골라요. 오늘 저녁 6시에 광장으로 가요.", style="wood")
        have = [p for p in D.PROD_ORDER if s.products[p] > 0]
        for j, p in enumerate(have[:18]):
            r = pg.Rect(inner.x + 20 + (j % 3) * 238, inner.y + 96 + (j // 3) * 70, 228, 62)
            sel = self.cart.get(p, 0)
            pg.draw.rect(surf, (236, 214, 250) if sel else U.PAPER_DARK, r, border_radius=8)
            surf.blit(A.image(f"products/{p}", height=46), (r.x + 6, r.y + 8))
            U.text(surf, D.PROD[p]["name"], (r.x + 58, r.y + 6), 13, U.INK, True, width=160)
            U.text(surf, f"실음 {sel} / 창고 {s.products[p]}", (r.x + 58, r.y + 36), 12, U.INK_SOFT)
            if g.ui.hit(r):
                cap = min(10, s.products[p])
                if sel < cap and (sel or len(self.cart) < 6):
                    self.cart[p] = min(cap, sel + 5)
                elif sel:
                    self.cart.pop(p)
        x = inner.x + 740
        U.text(surf, "도와줄 단골 (호감도 50+)", (x, inner.y + 96), 17, U.INK, True)
        eff = {"hans": "21시 재고 보충", "momo": "손님 +20%", "mignon": "굿즈 +20%", "kai": "손님 이동↑", "theo": "조명 쇼 손님↑", "rosemary": "부자 손님·팁↑"}
        for j, k in enumerate(D.NPC_ORDER):
            ok = s.npc[k]["aff"] >= 50
            on = k in self.helpers
            r = (x, inner.y + 130 + j * 52, 330, 44)
            if g.ui.button(surf, r, f"{'✓ ' if on else ''}{D.NPCS[k]['name']} · {eff[k]}", ok, primary=on, size=14):
                if on:
                    self.helpers.remove(k)
                elif len(self.helpers) < 2:
                    self.helpers.append(k)
        U.text(surf, "클릭할 때마다 5개씩 실어요 (최대 10개, 한 번 더 누르면 비워져요).", (inner.x + 22, inner.bottom - 50), 14, U.INK_SOFT)
        if g.ui.button(surf, (inner.right - 260, inner.bottom - 60, 240, 48), "준비 완료", bool(self.cart), primary=True):
            self.confirm()


class MarketBooth(Menu):
    def draw(self, surf):
        g = self.g
        inner = self.panel(surf, "리라의 마법 부스", "남은 재고", rect=(290, 200, 700, 400), style="wood")
        for j, p in enumerate([p for p in g.market_slots if p]):
            surf.blit(A.image(f"products/{p}", height=50), (inner.x + 24 + (j % 3) * 210, inner.y + 96 + (j // 3) * 90))
            U.text(surf, f"{D.PROD[p]['name']}\n남은 {g.market_stock.get(p, 0)}개", (inner.x + 84 + (j % 3) * 210, inner.y + 100 + (j // 3) * 90), 14, U.INK, width=130)


# ═══════════════════════ 저택 복원 ═══════════════════════
class RoomsMenu(Menu):
    def draw(self, surf):
        g, s = self.g, self.s
        inner = self.panel(surf, "잠긴 문 너머 · 저택 복원", "엔딩 후 자유 경영: 방을 하나씩 되살리면 기능과 할머니의 편지가 열려요.", style="paper")
        for j, (k, (name, cost, mats, desc)) in enumerate(D.ROOMS.items()):
            r = pg.Rect(inner.x + 20, inner.y + 96 + j * 120, 1000, 108)
            pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=10)
            surf.blit(A.image(f"rooms/{k}", size=(160, 90), color=(120, 100, 140)), (r.x + 10, r.y + 9))
            U.text(surf, name, (r.x + 180, r.y + 12), 20, U.INK, True)
            need = f"{cost:,}원" + "".join(f" · {D.MATS[m][0]} {n}" for m, n in mats.items())
            U.text(surf, f"{desc}\n필요: {need}", (r.x + 180, r.y + 44), 14, U.INK_SOFT, width=600)
            done = k in s.rooms
            ok = (not done and s.gold >= cost and all(s.materials[m] >= n for m, n in mats.items())
                  and (k != "terrace" or s.npc["mignon"]["aff"] >= 100)
                  and (k != "library" or all(x in s.rooms for x in ("workshop", "greenhouse", "terrace"))))
            if g.ui.button(surf, (r.right - 180, r.y + 30, 160, 46), "복원됨 ✓" if done else "복원하기", ok, primary=True, size=16):
                s.gold -= cost
                for m, n in mats.items():
                    s.materials[m] -= n
                s.rooms.append(k)
                if k == "greenhouse":
                    s.plot_count = 8
                if k == "workshop":
                    s.workshop_recipe = "p_sun"
                if k == "library":
                    self.close()
                    g.push_lines([("narr", "서재 책상 위에 봉투가 하나 놓여 있었다. 리라에게, 라고 적혀 있다."),
                                  ("narr", "'리라야. 이 편지를 읽는다면 너는 모든 방을 열었겠구나. 이 저택은 원래 이렇게 시끄러운 곳이었단다.'"),
                                  ("narr", "'솥은 태워도 괜찮아. 사람만 태우지 마라. 사랑한다. — 할머니'")], title="할머니의 마지막 편지")
                    return
                g.toast(f"{name}을(를) 복원했어요!")
                s.save()
        if "workshop" in s.rooms:
            U.text(surf, f"공방 자동 제작: {D.PROD[s.workshop_recipe]['name'] if s.workshop_recipe else '없음'} (솥에서 마지막으로 바꾼 제품으로 변경은 추후)", (inner.x + 22, inner.bottom - 40), 14, U.INK_SOFT)


# ═══════════════════════ 일시정지 · 도움말 · 빈칸 목록 ═══════════════════════
class Pause(Menu):
    def draw(self, surf):
        g = self.g
        r = pg.Rect(W // 2 - 230, 120, 460, 580)
        inner = g.ui.frame(surf, r, "paper")
        U.ribbon(surf, (r.centerx, r.y - 2), "잠깐 쉬어요", size=24)
        if close_button(g, surf, (inner.right - 44, inner.y + 2)):
            self.close()
            return
        items = [("계속하기", self.close, "moon"), ("저장하기", lambda: g.toast("저장했어요." if g.s.save() else "저장 실패"), "save"),
                 ("도움말 (F1)", lambda: g.open_menu(Help(g)), "help"), ("빈칸 그림 목록 (F9)", lambda: g.open_menu(ImageTodo(g)), "book"),
                 ("저장하고 타이틀로", self.to_title, "house"), ("저장하고 끝내기", g.quit, "exit")]
        if sys.platform == "emscripten":
            items[-1] = ("터치 버튼 끄기" if g.touch.enabled else "터치 버튼 켜기", self.toggle_touch, "cog")
        for i, (label, fn, ic) in enumerate(items):
            if g.ui.button(surf, (inner.x + 40, inner.y + 56 + i * 56, inner.w - 80, 44), label, primary=(i == 0), icon=ic):
                fn()
                return
        # 소리 설정
        y = inner.y + 56 + 6 * 56 + 8
        a = g.audio
        for j, (kind, name) in enumerate((("bgm", "배경음"), ("sfx", "효과음"))):
            yy = y + j * 44
            U.text(surf, name, (inner.x + 44, yy + 10), 16, U.INK, True)
            v = a.settings[kind]
            if g.ui.button(surf, (inner.x + 140, yy, 44, 36), "-", v > 0, size=16):
                a.set_volume(kind, round(v - 0.2, 1))
                g.sfx("click")
            U.paper_bar(surf, (inner.x + 194, yy + 8, 150, 20), v, "orange")
            if g.ui.button(surf, (inner.x + 354, yy, 44, 36), "+", v < 1, size=16):
                a.set_volume(kind, round(v + 0.2, 1))
                g.sfx("click")

    def toggle_touch(self):
        g = self.g
        g.touch.enabled = not g.touch.enabled
        g.touch.release_all()
        g.toast("터치 버튼을 켰어요." if g.touch.enabled else "터치 버튼을 껐어요. 키보드로 움직여요.")

    def to_title(self):
        g = self.g
        g.s.save()

        def go():
            g.menu = None
            g.queue = []
            g.mode = "title"
            g.title = Title(g)
        g.fade_to(go)


# ═══════════════════════ 그림 도움말 ═══════════════════════
# (분류, 아이콘, [(쪽 제목, [(그림, 제목, 설명), ...]), ...])  그림 = assets/help/<이름>.png (게임 화면을 찍은 것)
HELP_BOOK = [
    ("처음 시작", "newbook", [
        ("움직이기 · 화면 보기", [
            ("move", "걷고 · 사용하기", "WASD나 방향키로 걷고 Shift로 달려요. 무언가 가까이 가면 머리 위에 [E] 표시가 떠요. 그때 E를 누르면 사용·대화!"),
            ("hud_top", "하루 시계", "왼쪽 위 하늘 창이 시간 따라 바뀌어요. 7시에 일어나 9~18시에 가게를 열고, 밤엔 침대에서 하루를 마쳐요."),
            ("hud_right", "돈 · 기력 · 목표", "오른쪽 위: 돈, 레벨, 기력(빨강), 누적 매출(주황). 누적 200만 원을 모으고 달빛 장터를 마치면 저택이 리라의 것!"),
        ]),
        ("목표판 · 빠른 메뉴", [
            ("tracker", "오늘의 목표", "왼쪽 목표판에 이번 장 목표와 '지금 할 일'이 보여요. T 키나 클릭으로 접었다 펼 수 있어요."),
            ("quickbar", "빠른 메뉴", "가방 I · 목표 J · 인물 R · 꾸미기 B · 도움말 F1 · 메뉴 Esc. 빨간 점이 뜨면 확인할 일이 있다는 뜻이에요."),
            ("save", "저장 · 소리", "하루를 마칠 때 자동 저장돼요. Esc 메뉴에서 저장·소리 조절. 기다리기 지루하면 Z를 꾹 누르면 시간이 4배로 흘러요!"),
        ]),
    ]),
    ("가게 운영", "house", [
        ("만들고 진열하기", [
            ("craft", "솥에서 만들기", "마법 솥 앞에서 E. 재료가 충분하면 [만들기]로 제품 2개가 완성! [전부]로 한꺼번에 만들 수도 있어요."),
            ("shelf", "진열하기", "진열대 앞에서 E. 진열대 분류에 맞는 제품을 올려요. [모든 진열대 자동 채우기]가 편해요."),
            ("open", "영업 시작", "9시부터 O 키로 가게를 열어요. 도장이 OPEN으로 바뀌고 문 종이 울리면 손님이 들어와요."),
        ]),
        ("부엌 · 요리", [
            ("kitchen", "리라의 부엌", "작업실의 화덕 앞에서 E. 요리 재료로 요리를 만들고, 먹으면 기력이 차요 (하루 3번까지)."),
            ("food", "요리 재료는 '덤'", "텃밭 수확 → 감자·당근·밀, 낚시 → 강 송어, 숲딸기·반딧불·슬라임 → 숲 버섯, 한스네 수레 → 우유. 요리는 단골에게 선물할 수도 있어요!"),
            ("mush", "버섯돌이", "숲에 사는 통통 뛰는 버섯 몬스터. 쓰러뜨리면 숲 버섯과 반딧불 가루를 떨어뜨려요. 몇 번 때려야 하는지는 루나 레벨에 달렸어요."),
        ]),
        ("손님 · 결산", [
            ("customer", "손님", "손님은 진열대 2~4곳을 둘러보고 1~4개를 사요. 원하는 분류가 없으면 말풍선을 띄우고 돌아가요."),
            ("counter", "계산대 · 가격표", "계산대에서 진열대를 늘리고 가격표(90/100/120%)를 바꿔요. 비싸면 덜 사고, 싸면 더 사요."),
            ("report", "하루 결산", "침대에서 하루를 마치면 매출과 '그냥 돌아간 손님'의 이유를 알려 줘요. 다음 날 진열을 바꿀 힌트!"),
        ]),
    ]),
    ("재료 모으기", "leaf", [
        ("텃밭 · 강가 · 숲", [
            ("farm", "텃밭", "씨앗은 공짜예요. 심고 매일 물(기력 1)을 주면 자고 일어날 때 하루씩 자라요."),
            ("fishing", "낚시", "강가 낚시터에서 E (기력 2). 찌에 '!'가 뜨면 초록 칸에서 Space! 가운데 금색이면 2개."),
            ("forest", "숲 · 마법", "숲에 들어가면 기력 3 (하루 한 번). Space로 마법을 쏴서 몬스터를 잡으면 재료를 떨어뜨려요. 루나 Lv.1은 10번, Lv.3은 7번, Lv.5는 5번, Lv.10은 한 방!"),
        ]),
        ("사고팔기 · 가방", [
            ("hans", "한스네 수레", "2장부터 저택 앞 수레에서 재료를 사요. 남는 재료는 반값에 되팔 수 있어요."),
            ("bag", "가방", "I 키. 재료 · 제품 · 도감을 한눈에. 어디서 나는 재료인지도 적혀 있어요."),
        ]),
        ("채집 · 루나의 마법", [
            ("gather", "채집 자리", "반짝이는 들풀·숲 약초·강가 모래·야생 벌집·마력 바위는 매일 아침 새로 돋아요. E로 캐면 기력 없이 재료를 얻어요."),
            ("magic", "마법 진화 · 기력", "루나 레벨(호감도 10마다 1)이 오르면 마법이 진화해요: 반짝 별탄 → 푸른 별탄(Lv.3) → 쌍둥이 금별탄(Lv.5) → 보름달 일격(Lv.10). 마법은 마력 3칸마다 기력 1, 거대 슬라임 앞에선 1발마다 기력 1!"),
        ]),
    ]),
    ("단골 · 루나", "heart", [
        ("단골과 친해지기", [
            ("npc", "머리 위 표시", "♥ 오늘 아직 대화 안 함 · ! 새 부탁 · ✓ 부탁 완료 가능. 가까이 가서 E로 말을 걸어요."),
            ("talk", "대화 · 부탁 · 선물", "대화는 하루 한 번, 기본 호감도 +5 (좋은 답이면 +7·+10). 선물은 제품(좋아하는 분류 +8)이나 요리(좋아하는 요리 +12)! 부탁을 들어주면 +30."),
            ("luna", "루나", "H 키로 하루 한 번 쓰다듬기(+8). 은빛 비늘이 있으면 간식도 줄 수 있어요(+3, 하루 2번). 루나 호감도 10마다 루나 레벨이 올라요."),
        ]),
        ("인물 목록 · 노엘", [
            ("notebook", "인물 목록", "R 키. [주변인] 탭엔 엄마·아빠·할머니·루나·노엘, [단골] 탭엔 호감도·좋아하는 것·부탁 진행 상황이 있어요."),
            ("noel", "노엘의 약 가방", "3일마다 저녁, 저택 앞 등불 아래에 노엘이 와요. 영구 기력 물약은 종류마다 평생 한 병!"),
        ]),
    ]),
    ("공방 · 세공 (v1.0)", "cog", [
        ("브람 공방 수레", [
            ("bram", "브람 코퍼", "2장부터 매일 8시~19시, 텃밭 아래 길가에 공방 수레가 와요. 진열장 강화 · 통발 · 낚시 토템 · 구리 냄비 · 세공대 도구를 팔아요. 대화 · 선물도 돼요."),
            ("shelf_up", "진열장 강화", "가게에 놓인 진열장을 Lv.2(+4칸) · Lv.3(+8칸)으로 손봐요. Lv.3엔 마력 조각 2개가 필요해요."),
            ("place", "진열대 배치", "가게 계산대 › [진열대 배치]. 진열장을 회수해 창고에 넣고, 자리를 바꾸고, 창고에서 꺼내 놓아요. 자리가 차도 새 진열장을 살 수 있어요(창고로)."),
        ]),
        ("통발 · 낚시 토템", [
            ("trap", "통발", "강가 통발 자리(빨간 깃 말뚝) 3곳에 놓고, 다음 날 걷으면 송어 · 비늘 · 물풀 · 점토 · 해파리 · 조개, 가끔 마력 부스러기! 통발은 소모품, 튼튼한 통발은 계속 써요."),
            ("totem", "낚시 토템", "3장 목표 보상 또는 브람에게서. 낚시터 옆 돌받침에 세우면 그 낚시터의 노란 영역이 넓어져요(+25% · 달빛 토템 +45%·입질 빨라짐). 다른 받침에서 E로 옮겨요."),
        ]),
        ("마도석 세공대 · 냄비 젓기", [
            ("bench", "마도석 세공대 (머지)", "작업실 세공대. 숲 슬라임 · 마력 바위 · 통발에서 모은 부스러기를 올리고, 같은 단계 두 개를 겹치면 한 단계 위로! 조각 → 원석 → 월광 마도석까지. [꺼내기]로 마력 조각이나 판매용 마도석을 얻어요."),
            ("stir", "냄비 젓기 (요리 품질)", "화덕에서 요리하면 냄비 젓기! 바늘이 금색 구간에 올 때 Space. 전부 맞히면 ★최고(기력 ×1.6 · 선물 +5), 절반 이상이면 ◆좋음(×1.3 · +2). 구리 냄비는 금색 구간 +40%."),
        ]),
    ]),
    ("장터 · 꾸미기", "crown", [
        ("달빛 장터", [
            ("board", "게시판", "5장부터 가게 게시판에서 의뢰와 달빛 장터 참가 신청을 해요."),
            ("plaza", "달빛 장터", "장터 날 18시에 광장으로 가요. 부스에서 팔고, 왼쪽 순위판으로 다른 가게와 겨뤄요."),
        ]),
        ("우편함 · 버들골 소포", [
            ("mailbox", "우편함", "저택 앞 우편함. 부모님 편지가 3일마다 와요. 깃발이 서 있고 '!'가 뜨면 새 편지! 지난 편지도 다시 읽을 수 있어요."),
            ("packing", "소포 포장", "누적 매출 50만 원부터 옆 마을 버들골 주문이 와요. 상자를 돌려(R) 나무 상자에 모두 넣으면 발송! 같은 분류끼리 붙이면 보너스."),
        ]),
        ("가게 꾸미기", [
            ("deco", "꾸미기", "B 키. 받은 장식품을 벽 걸이 칸이나 바닥에 놓아요. 놓아야 효과가 켜져요."),
        ]),
    ]),
]
# 창 이름 → (분류, 쪽) : 창 오른쪽 위 '?'로 바로 가기
HELP_LINK = {"CookMenu": (1, 1), "CraftMenu": (1, 0), "ShelfMenu": (1, 0), "CounterMenu": (1, 2), "Report": (1, 2), "HansMenu": (2, 1),
             "Bag": (2, 1), "NPCMenu": (3, 0), "Notebook": (3, 1), "NoelMenu": (3, 1), "BoardMenu": (5, 0),
             "MarketPrep": (5, 0), "Decorate": (5, 2), "Goals": (0, 1), "MailMenu": (5, 1), "PackingGame": (5, 1),
             "BramMenu": (4, 0), "MergeMenu": (4, 2)}


class Help(Menu):
    def __init__(self, g, cat=0, page=0):
        super().__init__(g)
        self.cat, self.page = cat, page

    def pages(self):
        return HELP_BOOK[self.cat][2]

    def key(self, k):
        if k == pg.K_ESCAPE:
            self.close()
        elif k in (pg.K_RIGHT, pg.K_d):
            self.turn(1)
        elif k in (pg.K_LEFT, pg.K_a):
            self.turn(-1)
        elif k in (pg.K_UP, pg.K_w):
            self.set_cat((self.cat - 1) % len(HELP_BOOK))
        elif k in (pg.K_DOWN, pg.K_s):
            self.set_cat((self.cat + 1) % len(HELP_BOOK))

    def set_cat(self, c):
        self.cat, self.page = c, 0
        self.g.sfx("page")

    def turn(self, d):
        n = len(self.pages())
        if 0 <= self.page + d < n:
            self.page += d
            self.g.sfx("page")
        elif self.page + d >= n and self.cat < len(HELP_BOOK) - 1:   # 다음 분류로 넘기기
            self.set_cat(self.cat + 1)
        elif self.page + d < 0 and self.cat > 0:
            self.set_cat(self.cat - 1)
            self.page = len(self.pages()) - 1

    def draw(self, surf):
        g = self.g
        r = pg.Rect(70, 60, 1140, 680)
        inner = g.ui.frame(surf, r, "paper")
        U.ribbon(surf, (r.centerx, r.y - 2), "리라의 가게 안내서", size=24)
        if close_button(g, surf, (inner.right - 44, inner.y + 2)):
            self.close()
            return
        # ── 왼쪽: 분류 목록 (선택한 분류는 쪽 제목까지 펼침)
        side = pg.Rect(inner.x + 8, inner.y + 12, 250, inner.h - 24)
        pg.draw.rect(surf, (226, 210, 182), side)
        pg.draw.rect(surf, U.LINE, side, 2)
        y = side.y + 10
        for ci, (name, ic, pages) in enumerate(HELP_BOOK):
            row = pg.Rect(side.x + 8, y, side.w - 16, 44)
            sel = ci == self.cat
            hover = row.collidepoint(g.ui.mouse)
            if sel:
                pg.draw.rect(surf, U.LAV, row)
                pg.draw.rect(surf, U.LAV_DARK, row, 2)
            elif hover:
                pg.draw.rect(surf, (240, 228, 204), row)
            surf.blit(U.icon(ic, 24, U.CREAM if sel else U.INK), (row.x + 10, row.y + 10))
            U.text(surf, ("▾ " if sel else "▸ ") + name, (row.x + 42, row.y + 11), 17, U.CREAM if sel else U.INK, True)
            if g.ui.hit(row) and not sel:
                self.set_cat(ci)
            y += 50
            if sel:
                for pi, (ptitle, _) in enumerate(pages):
                    pr = pg.Rect(side.x + 22, y, side.w - 34, 30)
                    on = pi == self.page
                    if on:
                        pg.draw.rect(surf, (246, 236, 214), pr)
                        pg.draw.rect(surf, U.LAV, (pr.x, pr.y + 4, 4, pr.h - 8))
                    U.text(surf, "· " + ptitle, (pr.x + 12, pr.y + 7), 13, U.LAV_DARK if on else U.INK_SOFT, on)
                    if g.ui.hit(pr):
                        self.page = pi
                        g.sfx("page")
                    y += 32
                y += 6
        U.text(surf, "↑↓ 분류 · ←→ 쪽 넘기기", (side.centerx, side.bottom - 26), 12, U.INK_SOFT, center=True)
        # ── 오른쪽: 쪽 (그림 카드 1~3장)
        area = pg.Rect(side.right + 18, inner.y + 12, inner.right - side.right - 30, inner.h - 24)
        ptitle, cards = self.pages()[self.page]
        U.text(surf, ptitle, (area.x + 6, area.y + 4), 24, U.LAV_DARK, True)
        pg.draw.line(surf, U.LINE, (area.x, area.y + 40), (area.right, area.y + 40), 2)
        ch = 168
        for i, (img, title, desc) in enumerate(cards):
            cr = pg.Rect(area.x, area.y + 54 + i * (ch + 10), area.w, ch)
            pg.draw.rect(surf, (242, 230, 206), cr)
            pg.draw.rect(surf, U.LINE, cr, 2)
            th = pg.Rect(cr.x + 10, cr.y + 10, 264, ch - 20)
            portrait_frame(surf, th)
            pic = A.image("help/" + img)
            box = th.inflate(-16, -16)
            sc = min(box.w / pic.get_width(), box.h / pic.get_height())
            pic2 = pg.transform.smoothscale(pic, (max(1, int(pic.get_width() * sc)), max(1, int(pic.get_height() * sc))))
            pg.draw.rect(surf, (60, 48, 62), box)
            surf.blit(pic2, (box.centerx - pic2.get_width() // 2, box.centery - pic2.get_height() // 2))
            tx = th.right + 18
            pg.draw.rect(surf, U.LAV, (tx, cr.y + 18, 6, 20))
            U.text(surf, title, (tx + 14, cr.y + 16), 20, U.INK, True)
            U.text(surf, desc, (tx, cr.y + 52), 15, U.INK, width=cr.right - tx - 16, line_gap=8)
        # ── 쪽 넘기기
        total = sum(len(c[2]) for c in HELP_BOOK)
        idx = sum(len(c[2]) for c in HELP_BOOK[:self.cat]) + self.page + 1
        by = area.bottom - 34
        if g.ui.button(surf, (area.x, by - 6, 120, 40), "◀ 이전", idx > 1, size=15):
            self.turn(-1)
        U.text(surf, f"{idx} / {total}", (area.centerx, by + 4), 18, U.INK, True, center=True)
        if g.ui.button(surf, (area.right - 120, by - 6, 120, 40), "다음 ▶", idx < total, primary=True, size=15):
            self.turn(1)


class ImageTodo(Menu):
    def draw(self, surf):
        inner = self.panel(surf, "빈칸 그림 목록 (이번 실행 중 발견)", "assets 폴더에 같은 이름의 PNG를 넣으면 바로 교체돼요. 전체 목록은 '이미지_제작_목록.md' 참고.", style="paper")
        names = sorted(A.missing)
        col = 0
        for i, n in enumerate(names[:90]):
            U.text(surf, "· " + n + ".png", (inner.x + 24 + (i // 30) * 350, inner.y + 90 + (i % 30) * 17), 13, U.INK)
        if not names:
            U.text(surf, "빈칸이 없어요!", (inner.x + 24, inner.y + 90), 17, U.INK)


# ═══════════════════════ 타이틀 ═══════════════════════
TITLE_ITEMS = [("new", "처음하기", "newbook"), ("continue", "이어하기", "save"), ("credits", "크레딧", "crown"), ("quit", "종료", "exit")]
if sys.platform == "emscripten":        # 웹 버전: 브라우저 창은 게임이 닫을 수 없어서 '종료' 대신 없앰
    TITLE_ITEMS = TITLE_ITEMS[:3]

CREDITS = [
    ("title", "달빛 고양이 상점 · 리라의 유산"),
    ("sub", "클로드 수정판 v1.6"),
    ("gap", ""),
    ("head", "기획 · 원안"),
    ("line", "HEI"),
    ("head", "게임 제작 도움"),
    ("line", "Claude (Anthropic)"),
    ("head", "캐릭터 · 제품 · 소품 그림"),
    ("line", "v0.3 오리지널 그림 (ImageGen 생성)"),
    ("line", "v0.9 추가 그림 71종 — 맵 인물 · 진열대 · 몬스터 · 장터 · 작물 · 장 표지 (ChatGPT 이미지 생성)"),
    ("line", "v1.0 — 공방 장인 브람 · 마도석 세공대 · 통발 · 낚시 토템 · 냄비 젓기"),
    ("line", "v1.1 추가 그림 36종 — 브람 · 공방 소품 · 보석 7단계 · 요리 · 요리 재료 · 버섯돌이 · 달빛 이슬 (ChatGPT 이미지 생성)"),
    ("line", "v1.2 추가 그림 47종 — UI 아이콘 · 바깥 장식 · 동물 · 나무 4종 · NPC 거처 7곳 (ChatGPT 이미지 생성)"),
    ("line", "v1.3 추가 그림 18종 — 재료 아이콘 (ChatGPT 이미지 생성)"),
    ("line", "v1.4 추가 그림 — 소포 상자 아이콘 (ChatGPT 이미지 생성)"),
    ("line", "v1.5 추가 그림 — 인물 13명 4방향 걷기 스프라이트 시트 (ChatGPT 이미지 생성)"),
    ("line", "v1.6 — 웹 · 모바일 버전 (pygbag, MIT) · 터치 조작"),
    ("head", "종이 UI"),
    ("line", "Humble Pixel — Humble Gift · Paper UI System v1.1"),
    ("small", "humblepixel.itch.io · @Humblepixel · 색은 게임 톤에 맞게 바꿈"),
    ("head", "아이콘"),
    ("line", "game-icons.net — Lorc, Delapouite (CC BY 3.0)"),
    ("head", "재료 · 장터 물건 아이콘"),
    ("line", "Microsoft Fluent Emoji (MIT) — 픽셀로 줄여 사용"),
    ("head", "주민 · 요리 · 장식 · 동물 · 텃밭 · 채집 · 우편 그림"),
    ("line", "Microsoft Fluent Emoji (MIT) — 픽셀로 줄여 사용"),
    ("head", "UI 픽셀 아이콘"),
    ("line", "pixelarticons — Gerrit Halfmann (MIT)"),
    ("head", "파티클"),
    ("line", "Kenney — Particle Pack (CC0)"),
    ("head", "글꼴"),
    ("line", "갈무리 Galmuri — Minseo Lee / quiple (SIL OFL 1.1)"),
    ("head", "효과음 · 배경음"),
    ("line", "게임 안에서 직접 합성한 오르골 음원 (자체 제작)"),
    ("head", "엔진"),
    ("line", "Python 3.14 · pygame-ce 2.5.8 (LGPL 2.1) · SDL2"),
    ("gap", ""),
    ("head", "그리고"),
    ("line", "리라와 루나를 찾아와 준 당신에게"),
    ("gap", ""),
]


class Title:
    """타이틀 화면. g.mode == 'title' 일 때 그려진다."""

    def __init__(self, g):
        self.g = g
        self.sel = 0
        self.sub = None          # None / 'credits' / 'confirm_new' / 'confirm_quit'
        self.scroll = 0.0
        self.info = None
        from state import State
        self.save = State.load()
        if self.save:
            self.sel = 1
        self.stars = [(random.uniform(0, W), random.uniform(0, H * 0.6), random.uniform(0, 6)) for _ in range(40)]

    def enabled(self, key):
        return key != "continue" or self.save is not None

    def activate(self, key):
        g = self.g
        if not self.enabled(key):
            g.sfx("error")
            return
        g.sfx("click")
        if key == "new":
            if self.save:
                self.sub = "confirm_new"
            else:
                g.fade_to(g.new_game)
        elif key == "continue":
            g.fade_to(g.continue_game)
        elif key == "credits":
            self.sub = "credits"
            self.scroll = 470.0
        elif key == "quit":
            self.sub = "confirm_quit"

    def key(self, k):
        if self.sub == "credits":
            if k in (pg.K_ESCAPE, pg.K_RETURN, pg.K_SPACE):
                self.sub = None
            return
        if self.sub in ("confirm_new", "confirm_quit"):
            if k in (pg.K_RETURN, pg.K_y):
                self.confirm_yes()
            elif k in (pg.K_ESCAPE, pg.K_n):
                self.sub = None
            return
        if k in (pg.K_UP, pg.K_w):
            self.move(-1)
        elif k in (pg.K_DOWN, pg.K_s):
            self.move(1)
        elif k in (pg.K_RETURN, pg.K_SPACE, pg.K_e):
            self.activate(TITLE_ITEMS[self.sel][0])
        elif k == pg.K_ESCAPE:
            self.sub = "confirm_quit"

    def move(self, d):
        for _ in range(4):
            self.sel = (self.sel + d) % len(TITLE_ITEMS)
            if self.enabled(TITLE_ITEMS[self.sel][0]):
                break
        self.g.sfx("hover")

    def confirm_yes(self):
        g = self.g
        if self.sub == "confirm_new":
            self.sub = None
            g.fade_to(g.new_game)
        else:
            g.running = False

    def draw(self, surf):
        g = self.g
        t = g.t
        img = A.image("title", size=(W, H))
        surf.blit(img, (0, 0))
        ov = A._cache.get("title_ov")        # 어둡게 덮는 그라데이션은 한 번만 만들어 둬요
        if ov is None:
            ov = pg.Surface((W, H), pg.SRCALPHA)
            for y in range(0, H, 4):
                a = int(40 + 90 * (y / H) ** 1.6)
                pg.draw.rect(ov, (24, 14, 36, a), (0, y, W, 4))
            A._cache["title_ov"] = ov
        surf.blit(ov, (0, 0))
        # 반짝이는 별 (Kenney 파티클)
        star = A.raw("fx/star_06")
        for x, y, ph in self.stars:
            a = (math.sin(t * 1.6 + ph) + 1) / 2
            sz = int(10 + 10 * a)
            key = ("title_star", sz)
            if key not in A._cache:
                A._cache[key] = pg.transform.smoothscale(star, (sz, sz))
            st = A._cache[key].copy()
            st.set_alpha(int(60 + 160 * a))
            surf.blit(st, (x - sz // 2, y - sz // 2))
        # 제목 리본
        bob = math.sin(t * 1.2) * 3
        arch = U.P("header_1", 1)
        ax, ay = W // 2 - arch.get_width() // 2, 40 + bob
        surf.blit(arch, (ax, ay))
        tt = A.font(36, True).render("달빛 고양이 상점", False, U.INK)
        surf.blit(tt, (W // 2 - tt.get_width() // 2, ay + 62 - tt.get_height() // 2))
        U.outlined(surf, "리라의 유산", (W // 2, 188), 24, U.CREAM, (58, 36, 70))
        U.outlined(surf, "MOONCAT ATELIER", (W // 2, 222), 12, U.GOLD, (58, 36, 70))
        # 메뉴 (종이 한 장 위에 버튼 4개)
        panel = pg.Rect(W // 2 - 210, 290, 420, 50 + 90 * len(TITLE_ITEMS))
        g.ui.frame(surf, panel, "paper")
        for i, (key, label, icon) in enumerate(TITLE_ITEMS):
            r = pg.Rect(panel.x + 44, panel.y + 34 + i * 88, panel.w - 88, 60)
            ok = self.enabled(key)
            moved = getattr(self, "_last_mouse", None) != g.ui.mouse
            if moved and r.collidepoint(g.ui.mouse) and ok and self.sub is None and self.sel != i:
                self.sel = i
                g.sfx("hover")
            draw_title_button(surf, r, label, icon, ok, self.sel == i and self.sub is None, t)
            if key == "continue":
                note = self.save_note() if ok else "저장된 기록이 없어요"
                U.text(surf, note, (r.centerx + 20, r.bottom + 8), 12, U.INK_SOFT if ok else (170, 150, 140), center=True)
            if self.sub is None and g.ui.hit(r):
                self.activate(key)
        self._last_mouse = g.ui.mouse
        U.text(surf, "버튼을 눌러 시작해요" if g.touch.enabled else "↑↓ 선택 · Enter 결정 · Esc 종료", (W // 2, H - 34), 12, (230, 220, 240), center=True)
        U.text(surf, "v1.6" + (" 웹" if sys.platform == "emscripten" else ""), (W - 16, H - 24), 12, (200, 190, 210), right=True)
        if self.sub == "credits":
            self.draw_credits(surf)
        elif self.sub in ("confirm_new", "confirm_quit"):
            self.draw_confirm(surf)

    def save_note(self):
        s = self.save
        return f"{s.chapter}장 · {s.day}일째 · 누적 {s.total_revenue / 10000:,.1f}만 원"

    def draw_confirm(self, surf):
        g = self.g
        dim = pg.Surface((W, H), pg.SRCALPHA)
        dim.fill((20, 10, 30, 140))
        surf.blit(dim, (0, 0))
        r = pg.Rect(W // 2 - 300, H // 2 - 120, 600, 240)
        inner = g.ui.frame(surf, r, "paper")
        if self.sub == "confirm_new":
            U.ribbon(surf, (r.centerx, r.y - 2), "처음부터 할까요?", size=24)
            msg = f"저장된 기록({self.save_note()})이 새 게임으로 덮어써져요."
        else:
            U.ribbon(surf, (r.centerx, r.y - 2), "게임을 끝낼까요?", size=24)
            msg = "진행은 하루를 마칠 때마다 자동으로 저장돼요."
        U.text(surf, msg, (r.centerx, inner.y + 50), 15, U.INK, center=True, width=inner.w - 20)
        if g.ui.button(surf, (inner.x + 30, inner.bottom - 64, 220, 50), "네 (Enter)", primary=True):
            self.confirm_yes()
        elif g.ui.button(surf, (inner.right - 250, inner.bottom - 64, 220, 50), "아니요 (Esc)"):
            self.sub = None

    def draw_credits(self, surf):
        g = self.g
        dim = pg.Surface((W, H), pg.SRCALPHA)
        dim.fill((20, 10, 30, 160))
        surf.blit(dim, (0, 0))
        r = pg.Rect(W // 2 - 360, 70, 720, 650)
        inner = g.ui.frame(surf, r, "paper")
        U.ribbon(surf, (r.centerx, r.y - 2), "크레딧", size=30)
        self.scroll += g.dt_last * 28
        total = 0
        for kind, _ in CREDITS:
            total += {"title": 44, "sub": 30, "head": 40, "line": 28, "small": 26, "gap": 30}[kind]
        view = pg.Rect(inner.x, inner.y + 40, inner.w, inner.h - 100)
        if self.scroll > total + view.h:
            self.scroll = 0
        clip = surf.get_clip()
        surf.set_clip(view)
        y = view.bottom - self.scroll
        for kind, txt in CREDITS:
            if kind == "title":
                U.text(surf, txt, (r.centerx, y), 24, U.LAV_DARK, True, center=True); y += 44
            elif kind == "sub":
                U.text(surf, txt, (r.centerx, y), 15, U.INK_SOFT, center=True); y += 30
            elif kind == "head":
                y += 10
                U.text(surf, "— " + txt + " —", (r.centerx, y), 15, U.LAV_DARK, center=True); y += 30
            elif kind == "line":
                U.text(surf, txt, (r.centerx, y), 15, U.INK, center=True); y += 28
            elif kind == "small":
                U.text(surf, txt, (r.centerx, y), 12, U.INK_SOFT, center=True); y += 26
            else:
                y += 30
        surf.set_clip(clip)
        cat = A.image("npc_world/luna" if A.exists("npc_world/luna") else "props/luna_sprite", height=60)
        surf.blit(cat, (inner.right - cat.get_width() - 10, inner.bottom - 60 + math.sin(g.t * 3) * 2))
        if g.ui.button(surf, (r.centerx - 110, inner.bottom - 54, 220, 46), "돌아가기 (Esc)", primary=True):
            self.sub = None


def draw_title_button(surf, r, label, icon, enabled, selected, t):
    """Paper UI 'Sliced' 버튼(동그라미 보석 + 종이 몸통 + 쉐브론)을 3배로 늘려 만든 타이틀 버튼."""
    s = 3
    names = ("btn_19", "btn_20", "btn_21") if selected else ("btn_16", "btn_17", "btn_18")
    L, M_, R = (A.raw("ui/paper/" + n) for n in names)
    h = 32
    nw = r.w // s
    body = pg.Surface((nw, h), pg.SRCALPHA)
    body.blit(L, (0, 0))
    body.blit(pg.transform.scale(M_, (nw - 64, h)), (32, 0))
    body.blit(R, (nw - 32, 0))
    img = pg.transform.scale(body, (nw * s, h * s))
    if not enabled:
        g = pg.Surface(img.get_size(), pg.SRCALPHA)
        g.fill((175, 165, 160, 255))
        img.blit(g, (0, 0), special_flags=pg.BLEND_RGBA_MULT)
    x = r.x + (8 if selected else 0) + (math.sin(t * 6) * 2 if selected else 0)
    y = r.centery - img.get_height() // 2
    surf.blit(img, (x, y))
    # 보석 칸: 선택되면 라벤더, 아니면 크림색으로 채우고 아이콘
    cx, cy = x + 7 * s + 1, y + 15 * s + 1
    fill = U.LAV if selected else ((236, 221, 192) if enabled else (190, 180, 170))
    pg.draw.circle(surf, fill, (cx, cy), 5 * s)
    ic = U.icon(icon, 24, U.CREAM if selected else (U.INK if enabled else (140, 130, 120)))
    surf.blit(ic, (cx - 12, cy - 12))
    f = A.font(24, True)
    col = U.INK if enabled else (150, 136, 122)
    tt = f.render(label, False, col)
    surf.blit(tt, (x + 20 * s + 8, cy - tt.get_height() // 2))


# ═══════════════════════════════════════════════════════════════════
#                                v1.0
# ═══════════════════════════════════════════════════════════════════
_GEM_CACHE = {}


def gem_img(tier, size):
    """마도석 세공대 조각 그림. assets/items/gem_<단계>.png가 있으면 그걸 써요."""
    name = f"items/gem_{tier}"
    if A.exists(name):
        return px_icon(name, size)
    A.missing.add(name)
    key = (tier, size)
    if key in _GEM_CACHE:
        return _GEM_CACHE[key]
    col = D.MERGE_TIERS[tier][1]
    dk = tuple(max(0, c - 70) for c in col)
    lt = tuple(min(255, c + 60) for c in col)
    hs = size // 2
    S = pg.Surface((hs, hs), pg.SRCALPHA)
    c = hs // 2
    if tier == 1:                               # 부스러기: 작은 알갱이 셋
        for dx, dy, r in ((-5, 3, 3), (4, -2, 4), (2, 6, 2)):
            pg.draw.circle(S, dk, (c + dx, c + dy), r + 1)
            pg.draw.circle(S, col, (c + dx, c + dy), r)
        S.set_at((c + 3, c - 4), (255, 255, 255))
    elif tier == 2:                             # 조각: 길쭉한 수정
        pts = [(c, c - 11), (c + 6, c - 2), (c + 3, c + 10), (c - 3, c + 10), (c - 6, c - 2)]
        pg.draw.polygon(S, dk, [(x + 1, y + 1) for x, y in pts])
        pg.draw.polygon(S, col, pts)
        pg.draw.line(S, lt, (c, c - 9), (c - 2, c + 7), 2)
    elif tier == 7:                             # 보름달 원석: 빛나는 구슬
        pg.draw.circle(S, (255, 250, 220, 90), (c, c), c - 1)
        pg.draw.circle(S, dk, (c + 1, c + 1), c - 5)
        pg.draw.circle(S, col, (c, c), c - 5)
        pg.draw.circle(S, (250, 236, 150), (c + 3, c - 1), c - 10)
        pg.draw.circle(S, col, (c + 6, c - 3), c - 11)
        pg.draw.circle(S, (255, 255, 255), (c - 5, c - 5), 3)
    else:                                       # 원석: 단계가 오를수록 크고 면이 많아요
        r = 7 + (tier - 3) * 2
        n = 5 + (tier - 3)
        pts = [(c + r * math.cos(k * math.tau / n - math.pi / 2), c + r * math.sin(k * math.tau / n - math.pi / 2)) for k in range(n)]
        pg.draw.polygon(S, dk, [(x + 1, y + 1) for x, y in pts])
        pg.draw.polygon(S, col, pts)
        pg.draw.polygon(S, lt, [(c, c), pts[-1], pts[0], pts[1]])
        for p in pts:
            pg.draw.line(S, dk, (c, c), p, 1)
        pg.draw.polygon(S, dk, pts, 1)
        if tier >= 5:
            S.set_at((int(c - r * 0.5), int(c - r * 0.6)), (255, 255, 255))
            S.set_at((int(c + r * 0.7), int(c - r * 0.2)), (255, 255, 230))
    img = pg.transform.scale(S, (size, size))
    _GEM_CACHE[key] = img
    return img


def px_icon(name, size):
    """픽셀 아이콘(Fluent Emoji 도트 변환 등)을 흐려지지 않게 최근접 확대 · 비율 유지."""
    key = ("pxicon", name, size)
    if key not in A._cache:
        img = A.raw(name)
        sc = size / max(img.get_size())
        if max(img.get_size()) > 64:                # GPT 일러스트 아이콘 → 부드럽게 줄이기
            A._cache[key] = pg.transform.smoothscale(img, (max(1, round(img.get_width() * sc)), max(1, round(img.get_height() * sc))))
        else:
            k = int(sc) if sc >= 2 else sc
            A._cache[key] = pg.transform.scale(img, (max(1, round(img.get_width() * k)), max(1, round(img.get_height() * k))))
    return A._cache[key]


def gear_art(k, size):
    """브람 공방 상품 그림: assets/items/gear_<id>.png → 없으면 임시 그림."""
    if k in ("totem1", "totem2") and not A.exists(f"items/gear_{k}") and A.exists(f"props/totem_{k[-1]}"):
        return A.image(f"props/totem_{k[-1]}", height=size)
    if k in ("board6", "board7") and A.exists("items/gear_board"):
        return px_icon("items/gear_board", size)
    if A.exists(f"items/gear_{k}"):
        return px_icon(f"items/gear_{k}", size)
    return A.image(f"items/gear_{k}", size=(size, size))


def merge_out_text(tier):
    out = D.MERGE_TIERS[tier][2]
    if not out:
        return "합쳐서 써요"
    kind, k, n = out
    return f"{D.MATS[k][0] if kind == 'mat' else D.PROD[k]['name']} {n}개"


# ═══════════════════════ 요리 미니게임 · 냄비 젓기 ═══════════════════════
class StirGame(Menu):
    """바늘이 금색 구간에 올 때 젓기! 박자 수 = 재료 종류 + 1 (2~4박)."""

    def __init__(self, g, did):
        super().__init__(g)
        self.did = did
        self.beats = max(2, min(4, len(D.DISH[did]["need"]) + 1))
        self.res = []
        self.ang = random.uniform(0, math.tau)
        self.gold = 0.62 * (1.4 if g.s.gear.get("pot") else 1)
        self.phase = "play"
        self.fb, self.fb_t = None, 0
        self.q = None
        self.new_zone()

    def new_zone(self):
        self.zc = random.uniform(0, math.tau)
        self.speed = 3.0 * (1 + 0.18 * len(self.res)) * random.choice((1, -1))
        # 금색 구간이 바늘 바로 앞에 생기지 않게
        if abs((self.zc - self.ang + math.pi) % math.tau - math.pi) < 1.2:
            self.zc = (self.zc + math.pi) % math.tau

    def update(self, dt):
        if self.phase == "play":
            self.ang = (self.ang + self.speed * dt) % math.tau
        elif self.phase == "fb":
            self.fb_t -= dt
            if self.fb_t <= 0:
                if len(self.res) >= self.beats:
                    self.finish()
                else:
                    self.phase = "play"
                    self.new_zone()

    def press(self):
        if self.phase != "play":
            return
        diff = abs((self.ang - self.zc + math.pi) % math.tau - math.pi)
        half = self.gold / 2
        if diff <= half:
            r = "perfect"
            self.g.sfx("sparkle")
        elif diff <= half + 0.42:
            r = "good"
            self.g.sfx("pop")
        else:
            r = "miss"
            self.g.sfx("error")
        self.res.append(r)
        self.fb = {"perfect": "딱 좋아!", "good": "괜찮아!", "miss": "앗, 눌었다…"}[r]
        self.phase, self.fb_t = "fb", 0.55

    def quality(self):
        p = self.res.count("perfect")
        gd = self.res.count("good")
        if p == self.beats:
            return 3
        if p * 2 + gd >= self.beats:
            return 2
        return 1

    def finish(self, skip=False):
        if self.q is not None:
            return
        self.q = 1 if skip else self.quality()
        msg = self.s.cook_finish(self.did, self.q)
        self.phase = "done"
        self.g.toast(msg)
        self.g.sfx("craft")
        self.g.sparkle(self.g.p + pg.Vector2(0, -60), (255, 230, 150) if self.q == 3 else (255, 210, 150), 10 + self.q * 6)

    def close(self):
        if self.q is None:          # 도중에 닫으면 재료는 이미 썼으니 보통 품질로 완성
            self.finish(skip=True)
        self.g.menu = CookMenu(self.g)

    def key(self, k):
        if k == pg.K_ESCAPE:
            self.close()
        elif k in CONFIRM_KEYS:
            if self.phase == "done":
                self.close()
            else:
                self.press()

    def draw(self, surf):
        g, s = self.g, self.s
        d = D.DISH[self.did]
        r = pg.Rect(W // 2 - 330, 90, 660, 620)
        inner = g.ui.frame(surf, r, "paper")
        U.ribbon(surf, (r.centerx, r.y - 2), f"냄비 젓기 · {d['name']}", size=24)
        U.text(surf, "바늘이 금색 구간에 올 때 Space · 클릭!  전부 '딱 좋아'면 ★최고 품질", (r.centerx, inner.y + 20), 15, U.INK_SOFT, center=True)
        cx, cy, R = r.centerx, inner.y + 250, 150
        # 냄비 (원판)
        pg.draw.circle(surf, (90, 60, 50), (cx, cy), R + 22)
        pg.draw.circle(surf, (196, 116, 70) if s.gear.get("pot") else (120, 110, 120), (cx, cy), R + 16, 8)
        pg.draw.circle(surf, (238, 214, 170), (cx, cy), R)
        box = pg.Rect(cx - R + 10, cy - R + 10, (R - 10) * 2, (R - 10) * 2)
        if self.phase in ("play", "fb"):
            half = self.gold / 2
            a0 = (self.zc - half - 0.42) % math.tau
            pg.draw.arc(surf, (246, 224, 150), box, a0, a0 + self.gold + 0.84, 18)
            a1 = (self.zc - half) % math.tau
            pg.draw.arc(surf, (230, 170, 40), box, a1, a1 + self.gold, 18)
        dish = A.item_icon("dish:" + self.did, 96)
        bob = math.sin(g.t * 3) * 3
        surf.blit(dish, (cx - dish.get_width() // 2, cy - dish.get_height() // 2 + bob))
        # 바늘 (주걱)
        tip = (cx + math.cos(self.ang) * (R - 4), cy - math.sin(self.ang) * (R - 4))
        pg.draw.line(surf, (110, 74, 52), (cx, cy), tip, 6)
        pg.draw.circle(surf, (168, 116, 72), (int(tip[0]), int(tip[1])), 11)
        pg.draw.circle(surf, U.INK, (int(tip[0]), int(tip[1])), 11, 2)
        # 박자 표시
        by = cy + R + 44
        for i in range(self.beats):
            x = cx - (self.beats - 1) * 26 + i * 52
            res = self.res[i] if i < len(self.res) else None
            col = {"perfect": (230, 170, 40), "good": (150, 190, 120), "miss": (190, 120, 120)}.get(res, (220, 208, 190))
            pg.draw.circle(surf, col, (x, by), 15)
            pg.draw.circle(surf, U.INK, (x, by), 15, 2)
            if res == "perfect":
                U.text(surf, "★", (x, by - 11), 16, U.CREAM, True, center=True)
        if self.phase == "fb" and self.fb:
            U.outlined(surf, self.fb, (cx, cy - R - 24), 24, (255, 236, 170) if self.res[-1] == "perfect" else U.CREAM)
        if self.phase == "done":
            qn = D.COOK_Q[self.q]
            U.text(surf, f"{qn[3]} {qn[0]} 품질 완성!", (cx, by + 30), 24, U.LAV_DARK, True, center=True)
            U.text(surf, f"먹으면 기력 +{s.dish_energy(self.did, self.q)} · 선물하면 호감도 +{qn[2]} 더", (cx, by + 64), 15, U.INK_SOFT, center=True)
            if g.ui.button(surf, (cx - 110, inner.bottom - 60, 220, 46), "부엌으로 (Enter)", primary=True):
                self.close()
                return
        else:
            U.text(surf, "보통 ×1.0 · ◆좋음 ×1.3 · ★최고 ×1.6 (기력 회복)" + (" · 구리 냄비: 금색 +40%" if s.gear.get("pot") else ""),
                   (cx, by + 30), 14, U.INK_SOFT, center=True)
            if g.ui.button(surf, (cx - 250, inner.bottom - 60, 240, 46), "젓기! (Space)", self.phase == "play", primary=True):
                self.press()
                return
            if g.ui.button(surf, (cx + 10, inner.bottom - 60, 240, 46), "넘어가기 (보통 품질)", size=16):
                self.finish(skip=True)
                return
            if g.ui.hit(pg.Rect(cx - R, cy - R, R * 2, R * 2)):
                self.press()


# ═══════════════════════ 마도석 세공대 (머지) ═══════════════════════
class MergeMenu(Menu):
    """같은 단계 두 개를 겹치면 한 단계 위로. 조각(2단계)부터 꺼내 쓸 수 있어요."""

    def __init__(self, g):
        super().__init__(g)
        self.sel = None
        self.pop = {}           # 칸 → 반짝 시작 시각

    def key(self, k):
        if k == pg.K_ESCAPE:
            self.close()
        elif k in (pg.K_SPACE, pg.K_f):
            self.spawn(1)
        elif k == pg.K_x and self.sel is not None:
            self.extract()

    def spawn(self, n):
        s = self.s
        if s.shards <= 0:
            self.g.toast("부스러기가 없어요. 숲 슬라임 · 마력 바위 · 통발에서 모아요.")
            return
        if not s.merge_empty():
            self.g.toast("세공대에 빈칸이 없어요. 합치거나 꺼내 주세요.")
            return
        made = s.merge_spawn(n, self.g.rng)
        self.g.sfx("pop")
        if made:
            self.g.toast(f"부스러기 {made}개를 올렸어요.")

    def extract(self):
        s = self.s
        ok, msg = s.merge_extract(self.sel)
        self.g.toast(msg)
        if ok:
            self.g.sfx("craft")
            self.g.sparkle(self.g.p + pg.Vector2(0, -60), (200, 180, 255), 16)
            self.sel = None
            s.save()

    def click_cell(self, idx):
        s = self.s
        if self.sel is None:
            if s.merge[idx]:
                self.sel = idx
                self.g.sfx("click")
            return
        if idx == self.sel:
            self.sel = None
            return
        res = s.merge_move(self.sel, idx, self.g.rng)
        if res in ("merge", "hammer"):
            self.pop[idx] = self.g.t
            self.g.sfx("sparkle")
            t = s.merge[idx]
            if res == "hammer":
                self.g.toast(f"세공 망치! 단번에 {D.MERGE_TIERS[t][0]}!")
            elif t >= 5:
                self.g.toast(f"{D.MERGE_TIERS[t][0]} 완성!")
            self.sel = idx
        elif res == "move":
            self.sel = None
        elif res == "swap":
            self.sel = None
        else:
            self.sel = None

    def draw(self, surf):
        g, s = self.g, self.s
        inner = self.panel(surf, "마도석 세공대",
                           "같은 조각 두 개를 차례로 클릭해 겹치면 한 단계 위로! 조각(2단계)부터 [꺼내기]로 재료·마도석이 돼요. (Space 부스러기 올리기 · X 꺼내기)")
        n = s.board_n
        cs = min(80, 540 // n)
        bx, by = inner.x + 24, inner.y + 96
        board = pg.Rect(bx - 8, by - 8, cs * n + 16, cs * n + 16)
        pg.draw.rect(surf, (70, 52, 60), board, border_radius=8)
        pg.draw.rect(surf, (110, 80, 60), board, 3, border_radius=8)
        for idx in s.merge_cells():
            rr, cc = divmod(idx, 7)
            cell = pg.Rect(bx + cc * cs, by + rr * cs, cs - 4, cs - 4)
            hover = cell.collidepoint(g.ui.mouse)
            pg.draw.rect(surf, (104, 84, 126) if hover else (88, 70, 106), cell, border_radius=6)
            t = s.merge[idx]
            sel_t = s.merge[self.sel] if self.sel is not None else 0
            if self.sel is not None and idx != self.sel and t and t == sel_t and t < D.MERGE_MAX:
                pg.draw.rect(surf, (250, 220, 120), cell, 2, border_radius=6)       # 합칠 수 있는 짝
            if t:
                sz = cs - 14
                p0 = self.pop.get(idx)
                if p0 is not None and g.t - p0 < 0.3:
                    sz = int(sz * (1 + 0.35 * (1 - (g.t - p0) / 0.3)))
                img = gem_img(t, sz)
                surf.blit(img, (cell.centerx - img.get_width() // 2, cell.centery - img.get_height() // 2))
                U.text(surf, str(t), (cell.right - 6, cell.bottom - 18), 12, U.CREAM, True, right=True)
            if idx == self.sel:
                pg.draw.rect(surf, (255, 240, 170), cell.inflate(4, 4), 3, border_radius=8)
            if g.ui.hit(cell):
                self.click_cell(idx)
        # ── 오른쪽 조작판
        x = board.right + 28
        w = inner.right - x - 20
        U.text(surf, "마력 부스러기 주머니", (x, inner.y + 96), 17, U.INK, True)
        surf.blit(gem_img(1, 40), (x, inner.y + 124))
        U.text(surf, f"x{s.shards}", (x + 48, inner.y + 132), 22, U.LAV_DARK, True)
        empty = len(s.merge_empty())
        if g.ui.button(surf, (x + 130, inner.y + 124, 120, 40), "1개 올리기", s.shards > 0 and empty > 0, primary=True, size=15):
            self.spawn(1)
        if g.ui.button(surf, (x + 258, inner.y + 124, min(150, w - 258), 40), "가득 올리기", s.shards > 0 and empty > 0, size=15):
            self.spawn(99)
        crys = s.materials.get("crystal", 0)
        if g.ui.button(surf, (x, inner.y + 176, min(408, w), 38), f"가방의 마력 조각 올리기 (보유 {crys})", crys > 0 and empty > 0, size=14):
            ok, msg = s.merge_put_crystal(g.rng)
            g.toast(msg)
        # 고른 조각
        y = inner.y + 232
        pg.draw.line(surf, U.LINE, (x, y), (x + w, y), 2)
        y += 12
        if self.sel is not None and s.merge[self.sel]:
            t = s.merge[self.sel]
            surf.blit(gem_img(t, 56), (x, y))
            U.text(surf, f"{t}단계 · {D.MERGE_TIERS[t][0]}", (x + 66, y + 4), 18, U.INK, True)
            U.text(surf, "꺼내면: " + merge_out_text(t), (x + 66, y + 32), 14, U.LAV_DARK, True)
            if g.ui.button(surf, (x, y + 66, 200, 40), "꺼내기 (X)", t >= 2, primary=True, size=15):
                self.extract()
            U.text(surf, "같은 단계 조각을 클릭하면 합쳐져요." if t < D.MERGE_MAX else "최고 단계예요!", (x + 210, y + 78), 12, U.INK_SOFT, width=w - 210)
        else:
            U.text(surf, "조각을 클릭해 고르세요. 빈칸을 누르면 옮겨지고, 같은 단계면 합쳐져요.", (x, y + 6), 14, U.INK_SOFT, width=w)
        # 단계표
        y = inner.y + 370
        U.text(surf, "세공 단계", (x, y), 16, U.INK, True)
        for t in range(1, D.MERGE_MAX + 1):
            yy = y + 26 + (t - 1) * 30
            surf.blit(gem_img(t, 26), (x, yy))
            made = s.stats.get(f"merge_t{t}", 0) > 0 or t <= 2
            U.text(surf, f"{t}. {D.MERGE_TIERS[t][0] if made else '???'}", (x + 32, yy + 5), 13, U.INK, True)
            U.text(surf, "→ " + merge_out_text(t) if made else "", (x + 170, yy + 5), 13, U.INK_SOFT)
        extra = []
        if s.gear.get("hammer"):
            extra.append("세공 망치: 10% 확률로 두 단계")
        if n < 7:
            extra.append("브람 공방에서 판을 넓힐 수 있어요")
        U.text(surf, " · ".join(extra), (inner.x + 24, inner.bottom - 30), 13, U.INK_SOFT)


# ═══════════════════════ 브람 공방 수레 ═══════════════════════
class BramMenu(Menu):
    tab = "shelf"

    def draw(self, surf):
        g, s = self.g, self.s
        inner = self.panel(surf, "브람 공방 수레", "\"대충 만든 건 대충 부서진다.\" 진열장 손보기 · 통발 · 낚시 토템 · 세공대 도구.", style="wood")
        surf.blit(A.portrait("bram", 150), (inner.right - 330, inner.y + 4))
        for i, (k, nm, _) in enumerate(D.BRAM_TABS):
            if g.ui.button(surf, (inner.x + 20 + i * 160, inner.y + 84, 150, 38), nm, primary=(BramMenu.tab == k), size=16):
                BramMenu.tab = k
        talked = s.npc["bram"]["talked"] == s.day
        if g.ui.button(surf, (inner.x + 520, inner.y + 84, 170, 38), "대화 · 선물" + (" ✓" if talked else ""), size=15):
            g.open_menu(NPCMenu(g, "bram"))
            return
        y0 = inner.y + 140
        if BramMenu.tab == "shelf":
            U.text(surf, "진열장을 튼튼하게 손보면 칸이 늘어요. Lv.2 +4칸 · Lv.3 +8칸 (가게에 놓인 진열장만)", (inner.x + 22, y0), 15, U.INK_SOFT)
            for i in range(6):
                sh = s.shelves[i]
                r = pg.Rect(inner.x + 20 + (i % 2) * 520, y0 + 30 + (i // 2) * 136, 506, 124)
                pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=10)
                if not sh:
                    U.text(surf, f"{i + 1}번 자리 · 비어 있어요", (r.x + 16, r.y + 16), 16, U.INK_SOFT, True)
                    continue
                t = D.SHELF_TYPES[sh["type"]]
                tint = {"bath": (255, 165, 200), "goods": (255, 205, 110), "stone": (150, 185, 255), "magic": (190, 150, 255)}.get(t[1])
                surf.blit(A.image_or(t[4], "props/shelf_potion", 100, tint), (r.x + 10, r.y + 12))
                lv = sh.get("lv", 1)
                U.text(surf, f"{i + 1}번 · {t[0]}", (r.x + 110, r.y + 12), 17, U.INK, True, width=380)
                U.text(surf, "★" * lv + "☆" * (3 - lv) + f"  Lv.{lv} · {s.shelf_cap(i)}칸", (r.x + 110, r.y + 40), 15, U.LAV_DARK, True)
                if lv < 3:
                    cost, mats = D.SHELF_UP_COST[lv + 1]
                    need = f"{cost:,}원" + "".join(f" + {D.MATS[m][0]} {n}" for m, n in mats.items())
                    ok = s.gold >= cost and all(s.materials.get(m, 0) >= n for m, n in mats.items())
                    if g.ui.button(surf, (r.x + 110, r.bottom - 50, 380, 40), f"Lv.{lv + 1}로 강화 · {need}", ok, primary=True, size=14):
                        ok, msg = s.upgrade_shelf(i)
                        g.toast(msg)
                        if ok:
                            g.sfx("craft")
                            s.save()
                else:
                    U.text(surf, "최고 레벨!", (r.x + 110, r.bottom - 40), 15, U.INK_SOFT, True)
            if s.shelf_store:
                U.text(surf, f"창고에 진열장 {len(s.shelf_store)}개 — 가게 계산대 › [진열대 배치]에서 놓은 뒤 강화할 수 있어요.", (inner.x + 22, inner.bottom - 34), 14, U.INK_SOFT)
            return
        keys = next(ks for k, nm, ks in D.BRAM_TABS if k == BramMenu.tab)
        for j, k in enumerate(keys):
            name, price, ch, desc, pre = D.BRAM_SHOP[k]
            r = pg.Rect(inner.x + 20 + (j % 2) * 520, y0 + (j // 2) * 196, 506, 184)
            pg.draw.rect(surf, U.PAPER_DARK, r, border_radius=10)
            surf.blit(gear_art(k, 88), (r.x + 12, r.y + 14))
            U.text(surf, name, (r.x + 112, r.y + 12), 18, U.INK, True)
            U.text(surf, f"{price:,}원", (r.right - 16, r.y + 14), 16, U.LAV_DARK, True, right=True)
            U.text(surf, desc, (r.x + 112, r.y + 42), 13, U.INK_SOFT, width=380)
            status = ""
            if k == "trap":
                status = f"가진 통발 {s.gear['trap']}개 · 강에 놓인 통발 {sum(1 for t in s.traps if t)}개"
            elif k == "trap_iron":
                status = f"튼튼한 통발 {s.traps_owned()}/{D.TRAP_IRON_MAX}개"
            elif k in ("totem1", "totem2") and s.gear["totem"]:
                where = "아직 안 세움 (강가 토템 자리에서 E)" if s.totem_at is None else ("북쪽 낚시터" if s.totem_at == 0 else "남쪽 낚시터")
                status = f"토템 Lv.{s.gear['totem']} · {where}"
            elif k in ("board6", "board7"):
                status = f"지금 세공대 {s.board_n}×{s.board_n}"
            U.text(surf, status, (r.x + 112, r.y + 104), 13, U.LAV_DARK, True, width=380)
            can, why = s.bram_can(k)
            if k == "trap_iron":
                can = can and s.traps_owned() < D.TRAP_IRON_MAX
                why = why or ("최대 3개" if s.traps_owned() >= D.TRAP_IRON_MAX else "")
            label = "사기" if can else (why or "사기")
            if g.ui.button(surf, (r.x + 112, r.bottom - 50, 170, 40), label, can, primary=True, size=15):
                if k == "trap_iron" and s.traps_owned() >= D.TRAP_IRON_MAX:
                    g.toast("튼튼한 통발은 3개까지예요.")
                else:
                    ok, msg = s.buy_bram(k)
                    g.toast(msg)
                    if ok:
                        g.sfx("coin")
                        s.save()
            if k == "trap" and g.ui.button(surf, (r.x + 290, r.bottom - 50, 120, 40), "5개", can and s.gold >= price * 5, size=15):
                ok, msg = s.buy_bram(k, 5)
                g.toast(msg)
                if ok:
                    g.sfx("coin")


# ═══════════════════════ 계산대 · 진열대 배치 탭 ═══════════════════════
def draw_shelf_place(menu, g, surf, inner, y0):
    s = g.s
    sel = getattr(CounterMenu, "sel", None)
    swap = getattr(CounterMenu, "swap", False)
    if sel is not None and not (0 <= sel < 6):
        sel = CounterMenu.sel = None
    U.text(surf, "자리를 고른 뒤 회수하거나, 다른 자리와 바꾸거나, 창고의 진열장을 놓아요. 회수하면 올려 둔 제품은 창고로 돌아가요.",
           (inner.x + 22, y0), 15, U.INK_SOFT, width=inner.w - 44)
    names = ["왼쪽 위", "왼쪽 위 2", "오른쪽 위", "오른쪽 위 2", "왼쪽 아래", "오른쪽 아래"]
    for i in range(6):
        sh = s.shelves[i]
        r = pg.Rect(inner.x + 20 + (i % 3) * 214, y0 + 34 + (i // 3) * 200, 204, 188)
        on = sel == i
        pg.draw.rect(surf, (236, 224, 250) if on else U.PAPER_DARK, r, border_radius=10)
        pg.draw.rect(surf, U.LAV_DARK if on else U.LINE, r, 3 if on else 1, border_radius=10)
        U.text(surf, f"{i + 1}번 · {names[i]}", (r.x + 10, r.y + 8), 13, U.INK_SOFT, True)
        if sh:
            t = D.SHELF_TYPES[sh["type"]]
            tint = {"bath": (255, 165, 200), "goods": (255, 205, 110), "stone": (150, 185, 255), "magic": (190, 150, 255)}.get(t[1])
            img = A.image_or(t[4], "props/shelf_potion", 96, tint)
            surf.blit(img, (r.centerx - img.get_width() // 2, r.y + 30))
            U.text(surf, t[0], (r.centerx, r.y + 130), 14, U.INK, True, center=True)
            U.text(surf, f"Lv.{sh.get('lv', 1)} · {s.shelf_count(i)}/{s.shelf_cap(i)}", (r.centerx, r.y + 152), 13, U.LAV_DARK, True, center=True)
        else:
            U.text(surf, "빈 자리", (r.centerx, r.centery - 8), 16, U.INK_SOFT, True, center=True)
        if g.ui.hit(r):
            if swap and sel is not None and sel != i:
                ok, msg = s.swap_shelves(sel, i)
                g.toast(msg)
                CounterMenu.swap = False
                CounterMenu.sel = i
                s.save()
            else:
                CounterMenu.sel = None if on else i
                CounterMenu.swap = False
    # 오른쪽: 할 일 + 창고
    x = inner.x + 670
    w = inner.right - x - 20
    y = y0 + 34
    if sel is None:
        U.text(surf, "왼쪽에서 자리를 골라 주세요.", (x, y), 16, U.INK_SOFT)
    elif s.shelves[sel]:
        U.text(surf, f"{sel + 1}번 자리", (x, y), 18, U.INK, True)
        if g.ui.button(surf, (x, y + 34, w, 42), "회수하기 (창고로)", primary=True, size=15):
            ok, msg = s.pickup_shelf(sel)
            g.toast(msg)
            s.save()
        if g.ui.button(surf, (x, y + 84, w, 42), "다른 자리를 누르면 바꿔요…" if swap else "다른 자리와 바꾸기", primary=swap, size=15):
            CounterMenu.swap = not swap
    else:
        U.text(surf, f"{sel + 1}번 자리 · 비어 있어요", (x, y), 18, U.INK, True)
        U.text(surf, "아래 창고에서 [놓기]를 눌러요.", (x, y + 30), 14, U.INK_SOFT)
    y += 150
    U.text(surf, f"진열장 창고 ({len(s.shelf_store)})", (x, y), 17, U.INK, True)
    y += 30
    if not s.shelf_store:
        U.text(surf, "비어 있어요. 자리가 가득 찰 때 주문한 진열장이 여기로 와요.", (x, y), 13, U.INK_SOFT, width=w)
    for j, st in enumerate(s.shelf_store[:6]):
        t = D.SHELF_TYPES[st["type"]]
        rr = pg.Rect(x, y + j * 50, w, 44)
        pg.draw.rect(surf, U.PAPER_DARK, rr, border_radius=8)
        U.text(surf, f"{t[0]} Lv.{st.get('lv', 1)}", (rr.x + 10, rr.y + 12), 14, U.INK, True)
        can = sel is not None and s.shelves[sel] is None
        if g.ui.button(surf, (rr.right - 90, rr.y + 4, 84, 36), "놓기", can, primary=True, size=14):
            ok, msg = s.place_shelf(j, sel)
            g.toast(msg)
            s.save()
            break

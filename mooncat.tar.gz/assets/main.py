# -*- coding: utf-8 -*-
"""달빛 고양이 상점 — 리라의 유산 · 웹 버전 (pygbag)."""
import asyncio, os, sys
import pygame  # pygbag가 pygame-ce를 미리 받도록 맨 위에서 불러요
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "game"))


async def main():
    import game
    g = game.Game()
    await g.run_async()


asyncio.run(main())
